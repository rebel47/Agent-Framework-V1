"""
Dynamic Tools Registry
======================
Define your tools here using the @tool decorator.

Usage in agents.yaml:
    tool_imports:
      - "tools_registry.get_current_time"
      - "tools_registry.calculate"
      - "tms.tools_registry.tms_analyzer"

Import the decorator from framework:
    from main import tool
"""

from main import tool
from datetime import datetime


# ============================================================================
# Core Tools (Always Available)
# ============================================================================

@tool
def get_current_time() -> str:
    """Get the current time."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


@tool
def calculate(expression: str) -> str:
    """Evaluate a mathematical expression. Example: '2 + 2'"""
    try:
        result = eval(expression, {"__builtins__": {}}, {})
        return str(result)
    except Exception as e:
        return f"Error: {str(e)}"


# ============================================================================
# Custom Tools - Add Your Own Below!
# ============================================================================

@tool
def get_weather(city: str) -> str:
    """Get weather information for a city. (Stub - implement with real API)"""
    # TODO: Integrate with weather API
    return f"Weather for {city}: Sunny, 72°F (Placeholder)"


@tool
def search_documentation(query: str) -> str:
    """Search technical documentation. (Stub - implement with real search)"""
    # TODO: Integrate with documentation search
    return f"Documentation results for '{query}': [Placeholder]"


@tool
def send_notification(message: str, recipient: str = "admin") -> str:
    """Send a notification message. (Stub - implement with real notification service)"""
    # TODO: Integrate with notification service (email, Slack, etc.)
    return f"Notification sent to {recipient}: {message} (Placeholder)"


@tool
def create_file(filepath: str, content: str) -> str:
    """
    Create a file with the given content at the specified path.
    
    Args:
        filepath: Path to the file (e.g., 'output/main.py' or 'src/index.html')
        content: Content to write to the file
        
    Returns:
        Success or error message
        
    Example:
        create_file('hello.py', 'print("Hello World")')
    """
    from pathlib import Path
    
    try:
        file_path = Path(filepath)
        # Create parent directories if needed
        file_path.parent.mkdir(parents=True, exist_ok=True)
        # Write content
        file_path.write_text(content, encoding='utf-8')
        return f"✅ Successfully created file: {filepath}"
    except Exception as e:
        return f"❌ Error creating file {filepath}: {str(e)}"


@tool
def create_multiple_files(files: str) -> str:
    """
    Create multiple files from a JSON string.
    
    Args:
        files: JSON string with format: {"filepath1": "content1", "filepath2": "content2"}
        
    Returns:
        Summary of created files
        
    Example:
        create_multiple_files('{"main.py": "print(1)", "test.py": "import main"}')
    """
    import json
    from pathlib import Path
    
    try:
        file_dict = json.loads(files)
        created = []
        errors = []
        
        for filepath, content in file_dict.items():
            try:
                file_path = Path(filepath)
                file_path.parent.mkdir(parents=True, exist_ok=True)
                file_path.write_text(content, encoding='utf-8')
                created.append(filepath)
            except Exception as e:
                errors.append(f"{filepath}: {str(e)}")
        
        result = f"✅ Created {len(created)} file(s): {', '.join(created)}"
        if errors:
            result += f"\n❌ Errors: {'; '.join(errors)}"
        return result
    except json.JSONDecodeError as e:
        return f"❌ Invalid JSON format: {str(e)}"
    except Exception as e:
        return f"❌ Error: {str(e)}"


@tool
def read_file(filepath: str) -> str:
    """
    Read and return the contents of a file.
    
    Args:
        filepath: Path to the file to read
        
    Returns:
        File contents or error message
    """
    from pathlib import Path
    
    try:
        file_path = Path(filepath)
        if not file_path.exists():
            return f"❌ File not found: {filepath}"
        content = file_path.read_text(encoding='utf-8')
        return f"📄 Contents of {filepath}:\n\n{content}"
    except Exception as e:
        return f"❌ Error reading file {filepath}: {str(e)}"


@tool
def list_files(directory: str = ".") -> str:
    """
    List all files in a directory.
    
    Args:
        directory: Directory path (default: current directory)
        
    Returns:
        List of files
    """
    from pathlib import Path
    
    try:
        dir_path = Path(directory)
        if not dir_path.exists():
            return f"❌ Directory not found: {directory}"
        
        files = []
        for item in dir_path.iterdir():
            if item.is_file():
                files.append(f"📄 {item.name}")
            elif item.is_dir():
                files.append(f"📁 {item.name}/")
        
        if not files:
            return f"📂 Directory {directory} is empty"
        
        return f"📂 Contents of {directory}:\n" + "\n".join(sorted(files))
    except Exception as e:
        return f"❌ Error listing directory {directory}: {str(e)}"


# ============================================================================
# Weather Tools
# ============================================================================

@tool
def get_current_weather(location: str) -> str:
    """
    Get current weather information for a location.
    This is a mock implementation for testing.
    
    Args:
        location: City name or location to get weather for
        
    Returns:
        Current weather information
    """
    # Mock weather data for testing
    import random
    temperatures = [15, 18, 20, 22, 25, 28, 30]
    conditions = ["Sunny", "Partly cloudy", "Cloudy", "Rainy", "Windy"]
    
    temp = random.choice(temperatures)
    condition = random.choice(conditions)
    
    return f"🌤️ Current weather in {location}: {temp}°C, {condition}"


@tool
def get_weather_forecast(location: str, days: int = 3) -> str:
    """
    Get weather forecast for a location.
    This is a mock implementation for testing.
    
    Args:
        location: City name or location to get forecast for
        days: Number of days to forecast (default: 3)
        
    Returns:
        Weather forecast information
    """
    import random
    temperatures = [15, 18, 20, 22, 25, 28, 30]
    conditions = ["Sunny", "Partly cloudy", "Cloudy", "Rainy", "Windy"]
    
    forecast = [f"📅 {days}-day forecast for {location}:"]
    for i in range(min(days, 7)):
        temp = random.choice(temperatures)
        condition = random.choice(conditions)
        forecast.append(f"Day {i+1}: {temp}°C, {condition}")
    
    return "\n".join(forecast)


@tool
def get_weather_alerts(location: str) -> str:
    """
    Get weather alerts and warnings for a location.
    This is a mock implementation for testing.
    
    Args:
        location: City name or location to get alerts for
        
    Returns:
        Weather alerts or "No alerts" message
    """
    # Mock - usually no alerts
    import random
    if random.random() < 0.2:  # 20% chance of an alert
        alerts = ["High wind warning", "Heavy rain alert", "Heat advisory", "Fog warning"]
        return f"⚠️ Weather alert for {location}: {random.choice(alerts)}"
    return f"✅ No weather alerts for {location}"


# ============================================================================
# Extended Calculator Tools
# ============================================================================

@tool
def convert_units(value: float, from_unit: str, to_unit: str) -> str:
    """
    Convert between different units.
    Supports: temperature (C/F), length (m/ft/km/mi), weight (kg/lb).
    
    Args:
        value: The numeric value to convert
        from_unit: Source unit (C, F, m, ft, km, mi, kg, lb)
        to_unit: Target unit (C, F, m, ft, km, mi, kg, lb)
        
    Returns:
        Converted value with explanation
    """
    conversions = {
        # Temperature
        ('C', 'F'): lambda x: x * 9/5 + 32,
        ('F', 'C'): lambda x: (x - 32) * 5/9,
        # Length
        ('m', 'ft'): lambda x: x * 3.28084,
        ('ft', 'm'): lambda x: x / 3.28084,
        ('km', 'mi'): lambda x: x * 0.621371,
        ('mi', 'km'): lambda x: x / 0.621371,
        # Weight
        ('kg', 'lb'): lambda x: x * 2.20462,
        ('lb', 'kg'): lambda x: x / 2.20462,
    }
    
    key = (from_unit, to_unit)
    if key in conversions:
        result = conversions[key](value)
        return f"{value} {from_unit} = {result:.2f} {to_unit}"
    else:
        return f"❌ Conversion from {from_unit} to {to_unit} not supported"


@tool
def calculate_percentage(value: float, percentage: float) -> str:
    """
    Calculate percentage of a value or percentage increase/decrease.
    
    Args:
        value: The base value
        percentage: The percentage to calculate
        
    Returns:
        Calculation result with explanation
    """
    result = value * (percentage / 100)
    return f"{percentage}% of {value} = {result:.2f}"


@tool
def calculate_statistics(numbers: str) -> str:
    """
    Calculate statistical measures (mean, median, min, max, sum) for a list of numbers.
    
    Args:
        numbers: Comma-separated list of numbers (e.g., "1,2,3,4,5")
        
    Returns:
        Statistical summary
    """
    try:
        values = [float(x.strip()) for x in numbers.split(',')]
        if not values:
            return "❌ No numbers provided"
        
        mean = sum(values) / len(values)
        sorted_vals = sorted(values)
        n = len(sorted_vals)
        median = sorted_vals[n//2] if n % 2 else (sorted_vals[n//2-1] + sorted_vals[n//2]) / 2
        
        return f"""📊 Statistics for {numbers}:
• Count: {len(values)}
• Sum: {sum(values):.2f}
• Mean: {mean:.2f}
• Median: {median:.2f}
• Min: {min(values):.2f}
• Max: {max(values):.2f}"""
    except ValueError as e:
        return f"❌ Invalid number format: {str(e)}"


# ============================================================================
# TMS Tools - Imported from tms module
# ============================================================================
# These are imported here for backward compatibility only.
# In new code, import directly: "tms.tools_registry.tms_analyzer"

try:
    from tms.tools_registry import tms_analyzer, tms_email_sender, tms_get_config
    TMS_TOOLS_AVAILABLE = True
except ImportError:
    TMS_TOOLS_AVAILABLE = False
    print("[Warning] TMS tools not available - tms module not found")

