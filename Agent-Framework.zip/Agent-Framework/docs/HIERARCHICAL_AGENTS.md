# Hierarchical Agent System - Supervisor & Sub-Agents

The AgentFramework now supports **hierarchical multi-agent systems** with supervisor → sub-agent delegation patterns.

## Features

✅ **Supervisor Agents** - Coordinate and delegate to specialized sub-agents
✅ **Sub-Agent Delegation** - Supervisors can assign tasks to their subordinates
✅ **Automatic Delegation Tool** - Supervisors get a `delegate_to_sub_agent` tool automatically
✅ **Authority Validation** - Framework enforces delegation permissions
✅ **Context Hierarchy** - Sub-sessions maintain conversation context

---

## Configuration

### Define Agent Hierarchy in `agents.yaml`

```yaml
default_agent: supervisor

agents:
  # Supervisor Agent
  - name: supervisor
    description: Main coordinator that delegates to specialist agents
    enabled: true
    sub_agents:  # ← List of agents this supervisor can delegate to
      - researcher
      - writer
      - reviewer
    temperature: 0.7
    tool_imports:
      - "tools_registry.planning_tool"
      # Note: delegate_to_sub_agent tool is added automatically!

  # Sub-Agent 1: Researcher
  - name: researcher
    description: Research specialist - gathers information and data
    enabled: true
    parent: supervisor  # ← Optional: Mark parent relationship
    temperature: 0.3
    tool_imports:
      - "tools_registry.search_tool"
      - "tools_registry.web_scraper"

  # Sub-Agent 2: Writer
  - name: writer
    description: Content writer - creates articles and documents
    enabled: true
    parent: supervisor
    temperature: 0.8
    tool_imports:
      - "tools_registry.write_file"
      - "tools_registry.format_text"

  # Sub-Agent 3: Reviewer
  - name: reviewer
    description: Quality reviewer - checks and improves content
    enabled: true
    parent: supervisor
    temperature: 0.5
    tool_imports:
      - "tools_registry.grammar_check"
      - "tools_registry.fact_check"
```

---

## How It Works

### 1. Automatic Delegation Tool

When you define `sub_agents` for an agent, the framework **automatically creates** a `delegate_to_sub_agent` tool:

```python
@tool
def delegate_to_sub_agent(task: str, agent_name: str) -> str:
    """
    Delegate a task to a specialist sub-agent.
    
    Available sub-agents:
      - researcher: Research specialist - gathers information and data
      - writer: Content writer - creates articles and documents
      - reviewer: Quality reviewer - checks and improves content
    
    Args:
        task: Clear description of what the sub-agent should do
        agent_name: Name of sub-agent (researcher, writer, or reviewer)
    
    Returns:
        The sub-agent's response/result
    """
```

### 2. Supervisor Workflow

When a user talks to the supervisor:

```
User: "Write an article about AI trends"
                ↓
         [Supervisor Agent]
                ↓
    Analyzes request, decides to delegate
                ↓
    delegate_to_sub_agent(
        task="Research latest AI trends",
        agent_name="researcher"
    )
                ↓
         [Researcher Agent] ← Runs with its own tools
                ↓
    Returns: "Here are the top 5 AI trends..."
                ↓
         [Supervisor Agent] ← Receives result
                ↓
    delegate_to_sub_agent(
        task="Write an article about: [trends]",
        agent_name="writer"
    )
                ↓
         [Writer Agent] ← Creates article
                ↓
    Returns: "# AI Trends 2025..."
                ↓
         [Supervisor Agent] ← Receives draft
                ↓
    Returns to user: "I've created your article..."
```

### 3. Authority Validation

The framework enforces delegation rules:

```python
# ✅ Allowed: supervisor → researcher
await framework.delegate_to_agent(
    task="Research AI",
    target_agent="researcher",
    supervisor_agent="supervisor"
)

# ❌ Not Allowed: supervisor → random_agent
await framework.delegate_to_agent(
    task="Do something",
    target_agent="random_agent",  # Not in sub_agents list
    supervisor_agent="supervisor"
)
# Raises: ValueError: Agent 'supervisor' cannot delegate to 'random_agent'
```

---

## Example Use Cases

### Use Case 1: Content Creation Pipeline

```yaml
agents:
  - name: content_manager
    sub_agents: [topic_researcher, article_writer, seo_optimizer, publisher]
    
  - name: topic_researcher
    parent: content_manager
    
  - name: article_writer
    parent: content_manager
    
  - name: seo_optimizer
    parent: content_manager
    
  - name: publisher
    parent: content_manager
```

**Workflow:**
1. Content manager receives: "Create SEO article about Python"
2. Delegates to `topic_researcher` → Gets trending keywords
3. Delegates to `article_writer` → Creates draft
4. Delegates to `seo_optimizer` → Optimizes content
5. Delegates to `publisher` → Publishes to blog
6. Returns final URL to user

### Use Case 2: TMS Diagnostic System

```yaml
agents:
  - name: tms_coordinator
    description: Main TMS coordinator
    sub_agents: [tms_analyzer, tms_logger, tms_email_sender]
    
  - name: tms_analyzer
    parent: tms_coordinator
    tool_imports: ["tms.tools_registry.tms_analyzer"]
    
  - name: tms_logger
    parent: tms_coordinator
    tool_imports: ["tms.tools_registry.tms_log_analyzer_tool"]
    
  - name: tms_email_sender
    parent: tms_coordinator
    hitl: true  # Requires approval
    tool_imports: ["tms.tools_registry.tms_email_sender"]
```

**Workflow:**
1. User: "Analyze Bay 9 Preset 9 and email support"
2. Coordinator delegates to `tms_analyzer` → Gets diagnostic report
3. Coordinator delegates to `tms_logger` → Gets log analysis
4. Coordinator delegates to `tms_email_sender` → Sends email (with HITL approval)
5. Returns confirmation to user

### Use Case 3: Research & Development Team

```yaml
agents:
  - name: project_lead
    sub_agents: [requirements_analyst, architect, developer, tester]
    
  - name: requirements_analyst
    parent: project_lead
    
  - name: architect
    parent: project_lead
    
  - name: developer
    parent: project_lead
    sub_agents: [frontend_dev, backend_dev]  # ← Sub-agents can have sub-agents!
    
  - name: frontend_dev
    parent: developer
    
  - name: backend_dev
    parent: developer
    
  - name: tester
    parent: project_lead
```

**Multi-Level Hierarchy:**
- Project Lead → Developer → Frontend Dev
- Each level can delegate to the next

---

## API Usage

### Programmatic Delegation

```python
from agentframework import AgentFramework

framework = AgentFramework(agents_config_path="agents.yaml")
await framework.initialize_async()

# Direct delegation
result = await framework.delegate_to_agent(
    task="Research quantum computing",
    target_agent="researcher",
    session_id="my_session",
    supervisor_agent="supervisor"  # Optional: validates authority
)

# Check agent hierarchy
sub_agents = framework.get_sub_agents("supervisor")
print(f"Supervisor can delegate to: {sub_agents}")

parent = framework.get_parent_agent("researcher")
print(f"Researcher reports to: {parent}")
```

### Conversation Mode

The supervisor uses delegation automatically:

```python
# User talks to supervisor
response = await framework.run_conversation(
    user_message="Write a blog post about AI",
    agent_name="supervisor",
    session_id="user_123"
)

# Supervisor internally:
# 1. Delegates to researcher
# 2. Delegates to writer
# 3. Returns final result
```

---

## Benefits

1. **Clear Responsibility** - Each agent has a specific role
2. **Reusability** - Sub-agents can be used by multiple supervisors
3. **Scalability** - Easy to add new specialists
4. **Maintainability** - Changes to one agent don't affect others
5. **Debugging** - Clear task delegation trail in logs
6. **Testing** - Test each agent independently

---

## Logs Example

```
INFO - Creating 4 agent(s)...
INFO - Agent 'supervisor' loaded 1 tool(s)
INFO - Agent 'supervisor' can delegate to: researcher, writer, reviewer
INFO - ✓ Created 'supervisor' with 2 tools [SUPERVISOR: 3 sub-agents]
INFO - Agent 'researcher' loaded 2 tool(s)
INFO - ✓ Created 'researcher' with 2 tools [SUB-AGENT of supervisor]
INFO - Agent 'writer' loaded 2 tool(s)
INFO - ✓ Created 'writer' with 2 tools [SUB-AGENT of supervisor]
INFO - Agent 'reviewer' loaded 2 tool(s)
INFO - ✓ Created 'reviewer' with 2 tools [SUB-AGENT of supervisor]

INFO - 🔀 Delegating to sub-agent 'researcher': Research AI trends
INFO - [researcher] Processing...
INFO - ✅ Sub-agent 'researcher' completed task

INFO - 🔀 Delegating to sub-agent 'writer': Write article about: [trends]
INFO - [writer] Processing...
INFO - ✅ Sub-agent 'writer' completed task
```

---

## Best Practices

### 1. Keep Hierarchies Shallow
```yaml
✅ Good: Supervisor → Specialist (2 levels)
⚠️  Okay: Manager → Team Lead → Developer (3 levels)
❌ Avoid: Too many levels (4+)
```

### 2. Give Sub-Agents Clear Roles
```yaml
✅ Good:
  - name: researcher
    description: Research specialist - gathers information and data
    
❌ Bad:
  - name: helper
    description: Helps with stuff
```

### 3. Use Descriptive Task Instructions
```python
✅ Good:
delegate_task(
    "Research the top 5 AI trends in 2025, focusing on enterprise adoption",
    "researcher"
)

❌ Bad:
delegate_task("research AI", "researcher")
```

### 4. Combine with HITL for Critical Operations
```yaml
- name: email_sender
  parent: supervisor
  hitl: true  # ← Requires human approval before sending
```

---

## Migration from Flat Structure

### Before (Flat):
```yaml
agents:
  - name: ai_assistant
    tool_imports:
      - "tools_registry.search_tool"
      - "tools_registry.write_tool"
      - "tools_registry.email_tool"
```

### After (Hierarchical):
```yaml
agents:
  - name: ai_assistant
    sub_agents: [researcher, writer, emailer]
    
  - name: researcher
    parent: ai_assistant
    tool_imports: ["tools_registry.search_tool"]
    
  - name: writer
    parent: ai_assistant
    tool_imports: ["tools_registry.write_tool"]
    
  - name: emailer
    parent: ai_assistant
    tool_imports: ["tools_registry.email_tool"]
```

**Benefits:** Better separation of concerns, easier testing, clearer logs

---

## Troubleshooting

### Issue: "Agent cannot delegate"
```
ValueError: Agent 'supervisor' cannot delegate to 'unknown'. 
Allowed sub-agents: researcher, writer
```

**Solution:** Add the target agent to `sub_agents` list in YAML

### Issue: Sub-agent not found
```
ValueError: Target agent 'researcher' not found.
```

**Solution:** Ensure sub-agent is enabled in YAML:
```yaml
- name: researcher
  enabled: true  # ← Must be true
  parent: supervisor
```

### Issue: Circular delegation
```
supervisor → manager → supervisor (infinite loop)
```

**Solution:** Avoid circular references in `sub_agents` lists

---

## Summary

✅ **Add** `sub_agents: [list]` to supervisor agents
✅ **Add** `parent: name` to sub-agents (optional, for clarity)
✅ **Framework automatically** creates delegation tool
✅ **Framework enforces** delegation authority
✅ **Logs show** clear delegation chain
✅ **Works with** all existing features (HITL, MCP, tools, etc.)

Now you have true hierarchical multi-agent orchestration! 🚀
