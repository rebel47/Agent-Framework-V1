# Connecting to Open WebUI or Other OpenAI-Compatible UIs

The AgentFramework API includes built-in OpenAI-compatible endpoints, allowing you to use your agents with **Open WebUI**, **TypingMind**, **LibreChat**, and other OpenAI-compatible chat interfaces.

## Quick Setup (3 Steps)

### Step 1: Start Your Agent API

```bash
cd tms  # or any other agent directory
python agents_simple.py --api
```

This starts the API server on **http://localhost:8000** with OpenAI-compatible endpoints at `/v1/*`

### Step 2: Configure Open WebUI

1. Open your Open WebUI at **http://localhost:8080**
2. Go to **Settings** ⚙️ → **Connections** → **OpenAI API**
3. Configure:
   ```
   API URL: http://host.docker.internal:8000/v1
   API Key: sk-anything (not validated)
   ```
   > **Note:** Use `host.docker.internal` if Open WebUI is in Docker, or `localhost` if running natively
4. Click **Save** or **Verify Connection**

### Step 3: Chat with Your Agents

1. Start a new chat
2. Click the **model selector** dropdown
3. Select your agent (e.g., `tms_diagnostics`, `tms_email_send`)
4. Start chatting! 🎉

## Available Endpoints

### `/v1/models` - List Available Agents
Returns all your agents as "models" that can be selected in the UI.

```bash
curl http://localhost:8000/v1/models
```

### `/v1/chat/completions` - Chat with Agents
OpenAI-compatible chat endpoint that works with any OpenAI client.

```bash
curl http://localhost:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "tms_diagnostics",
    "messages": [{"role": "user", "content": "Analyze Bay 9"}],
    "stream": false
  }'
```

## Features

✅ **Automatic Agent Discovery** - All your agents appear as selectable models
✅ **Streaming Support** - Real-time word-by-word responses
✅ **Conversation Context** - Multi-turn conversations maintained
✅ **Tool Support** - All agent tools work (file ops, email, TMS analysis, etc.)
✅ **No Additional Setup** - Works with `--api` flag, no extra services needed

## Compatible UIs

- **Open WebUI** - Full-featured ChatGPT-like interface
- **TypingMind** - Clean, minimalist chat UI
- **LibreChat** - Open-source ChatGPT alternative
- **Any OpenAI-compatible client**

## Troubleshooting

### "Connection Failed"
- Verify API is running: `curl http://localhost:8000/health`
- Use `host.docker.internal` instead of `localhost` if UI is in Docker

### "No models available"
- Check models endpoint: `curl http://localhost:8000/v1/models`
- Verify agents.yaml is loaded correctly

### "Agent not responding"
- Check API logs in terminal
- Verify agent name matches one from `/v1/models`
- Test with regular `/chat` endpoint first: http://localhost:8000/docs

## Architecture

```
Open WebUI (port 8080)
    ↓ (OpenAI API format)
AgentFramework API (port 8000)
    ├── /v1/models (list agents)
    ├── /v1/chat/completions (chat with agents)
    ├── /chat (native format)
    └── /docs (Swagger UI)
```

No additional adapters or proxy services needed! 🚀
