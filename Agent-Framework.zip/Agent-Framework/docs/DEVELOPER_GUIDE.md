# 🚀 Developer Guide - Using the AI Runtime Framework

## Overview

This framework is designed as a **reusable library**. Developers can import and use it without modifying the core `main.py` file.

## Architecture

```
main.py              → Framework core (never modify this!)
├── create_cli()     → Factory function for CLI apps
├── create_api()     → Factory function for API servers
└── AgentFramework   → Core class for advanced use

your_app.py          → Your custom application (modify this!)
tools_registry.py    → Your custom tools (add tools here)
agents.yaml          → Your agent configurations (add agents here)
mcp_servers.yaml     → Your MCP server configs (add MCP servers here)
.env                 → Your credentials and settings
```

---

## Quick Start

### Method 1: Using Factory Functions (Recommended)

**CLI Mode:**
```python
# cli_app.py
from main import create_cli

# One line to create and run!
cli = create_cli("agents.yaml")
cli.run()
```

**API Mode:**
```python
# api_app.py
from main import create_api

# One line to create and run!
api = create_api("agents.yaml", host="0.0.0.0", port=8000)
api.run()
```

### Method 2: Direct Framework Use (Advanced)

```python
# custom_app.py
import asyncio
from main import AgentFramework

async def main():
    # Initialize framework
    framework = AgentFramework("agents.yaml")
    await framework.initialize()
    
    # Use it!
    response = await framework.run_conversation(
        user_message="Hello!",
        session_id="user_123",
        agent_name="main_agent"  # Optional
    )
    print(response)
    
    # Cleanup
    await framework.cleanup()

if __name__ == "__main__":
    asyncio.run(main())
```

### Run Your App

```bash
python cli_app.py      # CLI mode
python api_app.py      # API mode
python custom_app.py   # Advanced custom use
```

That's it! The framework automatically loads:
- ✅ Agents from `agents.yaml` (hierarchical support)
- ✅ Tools from `tools_registry.py`
- ✅ MCP servers from `mcp_servers.yaml`
- ✅ Settings from `.env`
- ✅ Smart routing (LLM-based, no hardcoded keywords)
- ✅ Per-agent HITL and debug settings

---

## Creating Hierarchical Agents

**Edit `agents.yaml`** (DO NOT touch `main.py`):

```yaml
default_agent: main_agent

agents:
  # Parent agent (orchestrator)
  - name: main_agent
    description: "Orchestrator that routes to specialist agents"
    enabled: true
    temperature: 0.7
    hitl: false           # No approval for orchestration
    debug: false          # Disable debug output
    sub_agents: [weather_agent, calculator_agent]  # Define sub-agents
    tools: [get_current_time]
    system_prompt: |
      You are an intelligent orchestrator. Route user requests to appropriate specialists.
  
  # Sub-agent 1
  - name: weather_agent
    description: "Weather specialist for forecasts and current conditions"
    enabled: true
    temperature: 0.5
    hitl: false
    tools: [get_current_weather, get_weather_forecast, get_weather_alerts]
  
  # Sub-agent 2
  - name: calculator_agent
    description: "Math specialist for calculations and conversions"
    enabled: true
    temperature: 0.3      # Low temp for deterministic math
    hitl: true            # Requires approval before processing
    tools: [calculate, convert_units, calculate_percentage, calculate_statistics]
```

**How smart routing works:**
1. LLM analyzes agent **descriptions** and **tools** (no hardcoded keywords)
2. Routes request to appropriate agent based on context
3. If sub-agent has `hitl: true`, asks for approval before processing
4. Each agent maintains its own conversation thread
agents:
  - name: my_custom_agent
    description: "My specialized agent"
    tools:
      - get_current_time
      - my_custom_tool
    temperature: 0.5
    enabled: true

default_agent: "my_custom_agent"
```

**Use it in your app:**

```python
await framework.run_conversation(
    user_message="Do something",
    session_id="session_1",
    agent_name="my_custom_agent"  # Use your custom agent
)
```

---

## Adding Custom Tools

**Edit `tools_registry.py`** (DO NOT touch `main.py`):

```python
from langchain_core.tools import tool

@tool
def my_custom_tool(query: str) -> str:
    """My custom tool description."""
    # Your logic here
    return f"Processed: {query}"

# The framework auto-discovers all @tool decorated functions!
```

**Reference it in `agents.yaml`:**

```yaml
agents:
  - name: my_agent
    tools:
      - my_custom_tool  # Add your tool here
```

---

## Adding MCP Servers

**Edit `mcp_servers.yaml`** (DO NOT touch `main.py`):

```yaml
mcp_servers:
  - name: my_mcp_server
    description: "My custom MCP server"
    type: stdio
    enabled: true
    config:
      command: "python"
      args: ["my_mcp_server.py"]
```

**Enable MCP in `.env`:**

```properties
MCP_ENABLED=true
```

---

## Configuration (.env)

```properties
# Azure OpenAI (required)
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_API_KEY=your-key-here
AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4o
AZURE_OPENAI_API_VERSION=2024-08-01-preview

# PostgreSQL (required)
POSTGRES_URL=postgresql://langchain:langchain_password@localhost:5432/langchain_db

# Feature flags
MCP_ENABLED=false   # Enable MCP integration
LOG_LEVEL=INFO      # Logging level

# Note: HITL is now configured per-agent in agents.yaml, not globally here
```

---

## Advanced Usage Examples

### Example 1: Multi-Agent System

```python
# app.py
import asyncio
from main import AgentFramework

async def main():
    framework = AgentFramework()
    await framework.initialize_async()
    
    # List all available agents
    print(f"Agents: {framework.list_agents()}")
    
    # Use different agents for different tasks
    await framework.run_conversation(
        "Write some code",
        session_id="dev_session",
        agent_name="code_analyzer"
    )
    
    await framework.run_conversation(
        "Research this topic",
        session_id="research_session",
        agent_name="researcher"
    )
    
    await framework.cleanup()

asyncio.run(main())
```

### Example 2: Interactive Chat Loop

```python
# app.py
import asyncio
from main import AgentFramework

async def main():
    framework = AgentFramework()
    await framework.initialize_async()
    
    print("💬 Chat with AI (type 'exit' to quit)")
    session_id = "interactive_session"
    
    while True:
        user_input = input("\nYou: ").strip()
        if user_input.lower() in ['exit', 'quit']:
            break
        
        await framework.run_conversation(
            user_message=user_input,
            session_id=session_id
        )
    
    await framework.cleanup()

asyncio.run(main())
```

### Example 3: Batch Processing

```python
# app.py
import asyncio
from main import AgentFramework

async def main():
    framework = AgentFramework()
    await framework.initialize_async()
    
    tasks = [
        "Analyze this log file",
        "Summarize this document",
        "Generate a report"
    ]
    
    for i, task in enumerate(tasks):
        print(f"\n[Task {i+1}/{len(tasks)}]")
        await framework.run_conversation(
            user_message=task,
            session_id=f"batch_job_{i}"
        )
    
    await framework.cleanup()

asyncio.run(main())
```

### Example 4: REST API Integration (FastAPI)

```python
# api.py
from fastapi import FastAPI
from pydantic import BaseModel
from main import AgentFramework
import asyncio

app = FastAPI()
framework = None

@app.on_event("startup")
async def startup():
    global framework
    framework = AgentFramework()
    await framework.initialize_async()

@app.on_event("shutdown")
async def shutdown():
    await framework.cleanup()

class ChatRequest(BaseModel):
    message: str
    session_id: str
    agent_name: str = None

@app.post("/chat")
async def chat(request: ChatRequest):
    await framework.run_conversation(
        user_message=request.message,
        session_id=request.session_id,
        agent_name=request.agent_name
    )
    return {"status": "success"}
```

---

## Framework API Reference

### `AgentFramework`

Main framework class with hierarchical agent support and smart routing.

**Methods:**

- `__init__(agents_config_path="agents.yaml")` - Initialize framework
- `await initialize()` - Setup async resources (database, agents, routing)
- `list_agents() -> List[str]` - Get all available agent names
- `get_agent(agent_name=None)` - Get specific agent or default
- `await run_conversation(user_message, session_id, agent_name=None)` - Run conversation with smart routing
- `await cleanup()` - Release resources

**Example:**

```python
framework = AgentFramework("agents.yaml")
await framework.initialize()
agents = framework.list_agents()
response = await framework.run_conversation("Hello", session_id="session_1")
await framework.cleanup()
```

### Factory Functions (Recommended)

**`create_cli(agents_config_path, **kwargs)`**

Creates a ready-to-use CLI interface.

```python
from main import create_cli

cli = create_cli("agents.yaml")
cli.run()
```

**`create_api(agents_config_path, host, port, **kwargs)`**

Creates a ready-to-use API server.

```python
from main import create_api

api = create_api("agents.yaml", host="0.0.0.0", port=8000)
api.run()
```

### `SmartRouter`

LLM-based intelligent agent routing (used internally by AgentFramework).

- Analyzes agent descriptions and available tools
- Routes requests based on context, not hardcoded keywords
- Handles hierarchical agent structures automatically

### `MCPContextProvider`

Manages MCP server connections (optional, advanced use).

**Methods:**

- `__init__(config_path="mcp_servers.yaml")` - Load MCP configs
- `await get_context(query: str) -> str` - Fetch context from MCP servers

### `HumanInTheLoopMiddleware`

Human approval system (used internally for per-agent HITL).

**Methods:**

- `__init__(require_approval=True)` - Initialize HITL
- `await should_proceed(action, tool_name) -> bool` - Ask for approval

---

## Best Practices

### ✅ DO:

- **Use factory functions** (`create_cli`, `create_api`) for quick setup
- Create your own `app.py` and import from `main`
- Add custom tools in `tools_registry.py`
- Configure agents in `agents.yaml` (with hierarchical structure)
- Set per-agent `hitl: true/false` for fine-grained control
- Set per-agent `debug: true/false` for troubleshooting
- Configure MCP servers in `mcp_servers.yaml`
- Store credentials in `.env`
- Write clear agent descriptions for better routing

### ❌ DON'T:

- Modify `main.py` (it's the framework core!)
- Use global HITL settings (configure per-agent instead)
- Hardcode agent names or keywords (use LLM-based routing)
- Hardcode credentials in code
- Forget to call `cleanup()` when done

---

## Project Structure

```
your-project/
├── main.py                 # Framework core (DO NOT MODIFY)
├── app.py                  # Your application (MODIFY THIS)
├── __init__.py             # Package initialization
├── tools_registry.py       # Your custom tools
├── agents_config.yaml      # Your agent configs
├── mcp_servers.yaml        # Your MCP configs
├── .env                    # Your credentials
├── docker-compose.yml      # PostgreSQL setup
├── requirements.txt        # Python dependencies
├── README.md               # User documentation
└── DEVELOPER_GUIDE.md      # This file
```

---

## Deployment

### Development:

```bash
# Start database
docker-compose up -d

# Run your app
python app.py
```

### Production:

```bash
# Use production database (update .env)
POSTGRES_URL=postgresql://user:pass@production-db:5432/db

# Run with process manager (e.g., supervisord, systemd)
python app.py
```

---

## Troubleshooting

### Import Error: `ModuleNotFoundError: No module named 'main'`

**Solution:** Run from the project root directory:

```bash
cd /path/to/your/project
python app.py
```

### Database Connection Error

**Solution:** Ensure PostgreSQL is running:

```bash
docker-compose up -d
docker ps  # Check container is running
```

### Agent Not Found

**Solution:** Check `agents_config.yaml` has the agent with `enabled: true`

---

## Need Help?

1. Check `README.md` for complete documentation
2. See `app.py` for example usage
3. Review error messages carefully
4. Ensure all dependencies are installed: `pip install -r requirements.txt`

---

## Contributing

To add framework features:

1. Modify `main.py` (framework core)
2. Update this guide with new API documentation
3. Add examples to `app.py`
4. Update `README.md` for users

---

**Happy Building! 🚀**
