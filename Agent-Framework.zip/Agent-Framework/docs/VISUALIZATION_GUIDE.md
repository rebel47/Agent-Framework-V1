# Agent System Visualization Guide

This guide explains how to visualize your multi-agent system architecture using the `visualize.py` script. It creates a diagram showing the hierarchical structure, agent relationships, tools, and properties.

## 📊 What Gets Visualized

The visualization creates a flowchart diagram showing:

- **User Request Flow** - How requests enter the system
- **Main Agent (Coordinator)** - The orchestrator agent with its properties and tools
- **Sub-Agents** - Specialized agents with their capabilities
- **Delegation Flow** - How tasks are delegated from coordinator to specialists
- **Response Flow** - How results flow back to the user
- **Agent Properties** - Debug mode, HITL (Human-in-the-Loop), parent relationships
- **Agent Tools** - All available tools for each agent

## 🎯 Example Use Cases

- **Documentation** - Generate architecture diagrams for your README
- **Presentations** - Explain your multi-agent system visually
- **Debugging** - Understand agent relationships and tool assignments
- **Onboarding** - Help new team members understand the system

## 📋 Prerequisites

### 1. Python Dependencies

Install the required Python packages:

```bash
pip install pyyaml graphviz
```

### 2. Graphviz Software (CRITICAL)

The `graphviz` Python package is just a wrapper - you MUST also install the actual Graphviz software:

#### Windows Installation

**Method 1: Using winget (Recommended)**

```powershell
winget install graphviz
```

If you get an error like `'winget' is not recognized`, use Method 2 instead.

**Method 2: Manual Download**

1. **Download**: Go to https://graphviz.org/download/
2. **Find Installer**: In the "Windows" section, download a stable release `.exe` installer (e.g., `graphviz-10.0.1 (64-bit) EXE installer`)
3. **Run Installer**: Run the downloaded `.exe` file
4. **⚠️ CRITICAL STEP**: During installation, CHECK the box that says:
   - ✅ **"Add Graphviz to the system PATH for all users"** (or "for current user")
   - This is ESSENTIAL - without it, the script won't find Graphviz!
5. **Restart Terminal**: After installation completes:
   - Close your current PowerShell/terminal
   - Open a NEW PowerShell/terminal window
6. **Verify Installation**:
   ```powershell
   dot -V
   ```
   You should see output like: `dot - graphviz version 10.0.1 (20240210.2158)`

#### Linux Installation

```bash
# Ubuntu/Debian
sudo apt-get install graphviz

# Fedora/RHEL
sudo dnf install graphviz

# Arch Linux
sudo pacman -S graphviz
```

#### macOS Installation

```bash
# Using Homebrew
brew install graphviz
```

## 🚀 Usage

### Basic Usage

1. **Navigate to your project directory**:
   ```bash
   cd methanol_factory
   # or
   cd multiagent
   ```

2. **Run the visualization script**:
   ```bash
   python visualize.py
   ```

3. **View the output**:
   - The script generates `agent_system_graph.png`
   - The image opens automatically in your default viewer
   - The diagram shows your complete agent hierarchy

### Custom Output Filename

You can specify a custom output filename in the script:

```python
if __name__ == "__main__":
    agent_config = load_agent_config("agents.yaml")
    if agent_config:
        visualize_agent_system(agent_config, output_filename="my_custom_diagram")
```

This will create `my_custom_diagram.png`.

### Different Config File

If your `agents.yaml` is in a different location:

```python
agent_config = load_agent_config("path/to/your/agents.yaml")
```

## 📖 Understanding the Diagram

### Node Colors

- **Purple/Pink** (`#fdf`) - Main coordinator agent
- **Light Blue** (`#e6f3ff`) - First sub-agent
- **Light Green** (`#e6ffe6`) - Second sub-agent
- **Light Pink** (`#ffebf0`) - Third sub-agent
- **Light Yellow** (`#fff9e6`) - Fourth sub-agent
- **White Circles** - Entry/exit points (User Request, Final Response)

### Edge Types

- **Solid Arrow** → Initial request and final response
- **Dashed Arrow** ⤏ Delegation from coordinator to sub-agent
- **Dotted Arrow** ⋯→ Result return from sub-agent to coordinator

### Node Information

Each agent node displays:

1. **Agent Name** - Unique identifier
2. **Description** - Brief explanation of agent's role
3. **Properties**:
   - `debug: true/false` - Debug mode status
   - `hitl: true/false` - Human-in-the-loop (approval required)
   - `parent: <name>` - Parent agent (for sub-agents)
4. **Tools** - List of all available tools

### Example Diagram Structure

```
User Request
    ↓
[coordinator_agent]
  ├─⤏ [roof_agent] ⋯→
  ├─⤏ [window_agent] ⋯→
  ├─⤏ [electrical_agent] ⋯→
  └─⤏ [automation_agent] ⋯→
    ↓
Final Response
```

## 🔧 Troubleshooting

### Error: "Graphviz not found in PATH"

**Problem**: Python can't find the Graphviz executables.

**Solution**:
1. Verify Graphviz is installed: `dot -V`
2. If not found, reinstall Graphviz and ENSURE you check "Add to PATH" during installation
3. Restart your terminal after installation
4. On Windows, you may need to manually add Graphviz to PATH:
   - Default install location: `C:\Program Files\Graphviz\bin`
   - Add this to your System PATH environment variable

### Error: "FileNotFoundError: agents.yaml"

**Problem**: The script can't find the configuration file.

**Solution**:
- Make sure you're running the script from the correct directory
- Ensure `agents.yaml` exists in the same folder as `visualize.py`
- Or specify the full path in the script

### Error: "ModuleNotFoundError: No module named 'graphviz'"

**Problem**: Python `graphviz` package not installed.

**Solution**:
```bash
pip install graphviz pyyaml
```

### Error: "ModuleNotFoundError: No module named 'yaml'"

**Problem**: PyYAML package not installed.

**Solution**:
```bash
pip install pyyaml
```

### Graph Doesn't Open Automatically

**Problem**: Image generated but doesn't open.

**Solution**:
- The PNG file is still created in the current directory
- Manually open `agent_system_graph.png`
- Or modify the script to disable auto-view:
  ```python
  dot.render(output_filename, view=False, format='png', cleanup=True)
  ```

### Poor Quality / Text Too Small

**Solution**: Modify the script to increase DPI:
```python
dot.attr(dpi='300')  # Add this line after creating the Digraph
```

## 💡 Customization Tips

### Change Output Format

Graphviz supports multiple formats:

```python
dot.render(output_filename, view=True, format='svg', cleanup=True)  # SVG (scalable)
dot.render(output_filename, view=True, format='pdf', cleanup=True)  # PDF
```

### Modify Colors

Edit the color arrays in the script:

```python
colors = ['#yourcolor1', '#yourcolor2', '#yourcolor3', '#yourcolor4']
```

### Adjust Layout

Change the layout direction:

```python
dot.attr(rankdir='LR')  # Left-to-right instead of top-to-bottom (TB)
```

### Add More Agent Properties

Edit the `format_properties()` function to display additional fields:

```python
def format_properties(agent):
    props = []
    if 'temperature' in agent:
        props.append(f"- temperature: {agent['temperature']}")
    # Add more properties as needed
    return "<BR/>".join(props)
```

## 📁 Example Projects

### Methanol Factory System

```bash
cd methanol_factory
python visualize.py
```

**Expected Output**: Shows coordinator agent with 4 sub-agents (roof, window, electrical, automation), each with 5 document processing tools.

### Multi-Agent System

```bash
cd multiagent
python visualize.py
```

**Expected Output**: Shows main agent with 2 sub-agents (weather, calculator), each with specialized tools.

## 📝 Notes

- The script automatically detects the main agent from `default_agent` in `agents.yaml`
- Sub-agents are identified from the `sub_agents` list in the main agent
- Tool names are cleaned up (removes the module path prefix)
- HITL-enabled agents are highlighted in bold
- The generated PNG can be used directly in documentation, presentations, or reports

## 🔗 Related Documentation

- [FRAMEWORK_OVERVIEW.md](FRAMEWORK_OVERVIEW.md) - Overall system architecture
- [DEVELOPER_GUIDE.md](DEVELOPER_GUIDE.md) - Agent development guide
- [Methanol Factory README](../methanol_factory/README.md) - Example project
- [Multi-Agent README](../multiagent/README.md) - Example project

## 🤝 Contributing

To improve the visualization script:
1. Enhance the `create_agent_label()` function for better formatting
2. Add support for more Graphviz layouts (neato, fdp, circo, etc.)
3. Include agent statistics (number of tools, token limits, etc.)
4. Add legend explaining colors and edge types

---

**Questions or issues?** Check the troubleshooting section or open an issue in the repository.
