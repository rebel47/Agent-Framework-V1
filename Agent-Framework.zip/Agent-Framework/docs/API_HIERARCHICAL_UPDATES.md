# API Server - Hierarchical Agent Updates

**Date:** January 2025  
**Status:** ✅ Completed and Tested

## Overview

Updated the API server to expose hierarchical agent information through REST endpoints. Consumers can now discover agent relationships, supervisor capabilities, and the complete organization structure.

## Changes Made

### 1. Enhanced `AgentInfo` Model

**New Fields Added:**
```python
class AgentInfo(BaseModel):
    name: str
    system_prompt: Optional[str]
    tools: List[str]
    temperature: float
    debug: bool
    sub_agents: Optional[List[str]]  # ← NEW: List of sub-agents if supervisor
    parent: Optional[str]             # ← NEW: Parent agent name if sub-agent
    role: str                         # ← NEW: "supervisor", "sub-agent", or "agent"
```

**Example Response:**
```json
{
  "name": "main_agent",
  "system_prompt": "You are an intelligent assistant...",
  "tools": ["delegate_to_sub_agent", "get_current_time"],
  "temperature": 0.5,
  "debug": false,
  "sub_agents": ["weather_agent", "calculator_agent"],
  "parent": null,
  "role": "supervisor"
}
```

### 2. Updated `/agents/{agent_name}` Endpoint

**Enhanced to include hierarchy:**
- Automatically determines agent role based on configuration
- Returns `sub_agents` list for supervisors
- Returns `parent` name for sub-agents
- Sets `role` field appropriately

**Logic:**
```python
if sub_agents and len(sub_agents) > 0:
    role = "supervisor"
elif parent:
    role = "sub-agent"
else:
    role = "agent"
```

### 3. New `/agents/hierarchy/tree` Endpoint

**Purpose:** Get the complete hierarchical structure of all agents

**URL:** `GET /agents/hierarchy/tree`

**Response Format:**
```json
{
  "supervisors": [
    {
      "name": "main_agent",
      "description": "Main orchestrator agent...",
      "sub_agents": ["weather_agent", "calculator_agent"],
      "role": "supervisor"
    }
  ],
  "standalone_agents": [
    {
      "name": "solo_agent",
      "description": "Independent agent...",
      "role": "agent"
    }
  ],
  "total_agents": 3,
  "supervisor_count": 1,
  "standalone_count": 1
}
```

**Use Cases:**
- Build UI hierarchy visualizations
- Understand agent organization at a glance
- Programmatically discover delegation capabilities
- Generate documentation from live config

## API Examples

### Get All Agents (Existing)
```bash
curl http://localhost:8000/agents
```

**Response:**
```json
{
  "agents": ["main_agent", "weather_agent", "calculator_agent"],
  "default_agent": "main_agent",
  "total_count": 3
}
```

### Get Specific Agent Info (Enhanced)
```bash
curl http://localhost:8000/agents/main_agent
```

**Response:**
```json
{
  "name": "main_agent",
  "system_prompt": "You are an intelligent assistant...",
  "tools": ["delegate_to_sub_agent", "get_current_time"],
  "temperature": 0.5,
  "debug": false,
  "sub_agents": ["weather_agent", "calculator_agent"],
  "parent": null,
  "role": "supervisor"
}
```

### Get Hierarchy Tree (New)
```bash
curl http://localhost:8000/agents/hierarchy/tree
```

**Response:**
```json
{
  "supervisors": [
    {
      "name": "main_agent",
      "description": "Main orchestrator agent that intelligently delegates tasks",
      "sub_agents": ["weather_agent", "calculator_agent"],
      "role": "supervisor"
    }
  ],
  "standalone_agents": [],
  "total_agents": 3,
  "supervisor_count": 1,
  "standalone_count": 0
}
```

## Integration Examples

### Python Client
```python
import requests

# Get all agents
response = requests.get("http://localhost:8000/agents")
agents = response.json()["agents"]

# Get hierarchy
hierarchy = requests.get("http://localhost:8000/agents/hierarchy/tree").json()

for supervisor in hierarchy["supervisors"]:
    print(f"Supervisor: {supervisor['name']}")
    print(f"  Can delegate to: {', '.join(supervisor['sub_agents'])}")
```

### JavaScript/TypeScript
```typescript
interface AgentInfo {
  name: string;
  system_prompt?: string;
  tools: string[];
  temperature: number;
  debug: boolean;
  sub_agents?: string[];
  parent?: string;
  role: 'supervisor' | 'sub-agent' | 'agent';
}

async function getAgentInfo(agentName: string): Promise<AgentInfo> {
  const response = await fetch(`http://localhost:8000/agents/${agentName}`);
  return await response.json();
}

async function getHierarchy() {
  const response = await fetch('http://localhost:8000/agents/hierarchy/tree');
  const data = await response.json();
  
  // Build tree visualization
  data.supervisors.forEach(supervisor => {
    console.log(`📋 ${supervisor.name}`);
    supervisor.sub_agents.forEach(sub => {
      console.log(`  └─ ${sub}`);
    });
  });
}
```

### cURL Examples
```bash
# List all agents
curl http://localhost:8000/agents

# Get specific agent with hierarchy info
curl http://localhost:8000/agents/main_agent | jq '.sub_agents'

# Get full hierarchy tree
curl http://localhost:8000/agents/hierarchy/tree | jq '.supervisors'

# Check if an agent is a supervisor
curl http://localhost:8000/agents/main_agent | jq '.role'
```

## OpenAPI/Swagger Documentation

The API server automatically generates interactive documentation at:
- **Swagger UI:** http://localhost:8000/docs
- **ReDoc:** http://localhost:8000/redoc

All new fields and endpoints are automatically documented with:
- Field descriptions
- Example values
- Request/response schemas
- Try-it-out functionality

## Backward Compatibility

✅ **Fully backward compatible:**
- Existing endpoints still work the same way
- New fields return `null` for agents without hierarchy
- Clients ignoring new fields continue to function
- No breaking changes to existing API contracts

## Use Cases

### 1. UI Building
```typescript
// Build agent selector with hierarchy grouping
const hierarchy = await getHierarchy();

hierarchy.supervisors.forEach(supervisor => {
  addSelectGroup(supervisor.name);
  supervisor.sub_agents.forEach(sub => {
    addSelectOption(sub, supervisor.name);
  });
});
```

### 2. Documentation Generation
```python
# Auto-generate agent documentation
hierarchy = get_hierarchy()

markdown = "# Agent Organization\n\n"
for supervisor in hierarchy['supervisors']:
    markdown += f"## {supervisor['name']}\n"
    markdown += f"{supervisor['description']}\n\n"
    markdown += "**Delegates to:**\n"
    for sub in supervisor['sub_agents']:
        markdown += f"- {sub}\n"
```

### 3. Dynamic Routing
```javascript
// Route user query to appropriate agent based on hierarchy
async function routeQuery(query) {
  const hierarchy = await getHierarchy();
  
  // Check if query needs delegation
  if (needsDelegation(query)) {
    const supervisor = hierarchy.supervisors[0];
    return chatWithAgent(supervisor.name, query);
  }
}
```

### 4. Monitoring & Analytics
```python
# Track delegation patterns
hierarchy = get_hierarchy()

for supervisor in hierarchy['supervisors']:
    metrics = get_delegation_metrics(supervisor['name'])
    print(f"{supervisor['name']}:")
    for sub in supervisor['sub_agents']:
        count = metrics.get(sub, 0)
        print(f"  → {sub}: {count} delegations")
```

## Testing

**Test Status:** ✅ All API tests passing

```bash
pytest tests/test_api.py -v
# Result: 1 passed
```

**Validation:**
- ✅ `AgentInfo` model includes new fields
- ✅ `/agents/{agent_name}` returns hierarchy info
- ✅ `/agents/hierarchy/tree` returns structure
- ✅ Backward compatibility maintained
- ✅ OpenAPI schema generates correctly

## Migration Guide

### For API Consumers

**No migration needed!** New fields are optional and null-safe.

**To use new features:**
```python
# Before
agent = get_agent_info("main_agent")
print(agent["name"])

# After - access new fields
agent = get_agent_info("main_agent")
if agent["role"] == "supervisor":
    print(f"Can delegate to: {agent['sub_agents']}")
```

### For UI Developers

**Update agent list display:**
```typescript
// Enhanced agent card
function AgentCard({ agent }: { agent: AgentInfo }) {
  return (
    <div>
      <h3>{agent.name}</h3>
      {agent.role === 'supervisor' && (
        <Badge>Supervisor</Badge>
      )}
      {agent.sub_agents && (
        <div>
          Delegates to: {agent.sub_agents.join(', ')}
        </div>
      )}
    </div>
  );
}
```

## Future Enhancements

Potential additions:
- [ ] `/agents/{name}/delegate` - Endpoint to trigger delegation
- [ ] `/agents/hierarchy/depth` - Calculate hierarchy depth
- [ ] `/agents/hierarchy/validate` - Validate configuration
- [ ] WebSocket support for delegation events
- [ ] Delegation history tracking API

## Conclusion

The API server now fully supports the hierarchical multi-agent system, providing complete visibility into agent relationships and enabling powerful integrations for UI builders, monitoring tools, and automation scripts.

**Status:** ✅ Production Ready  
**Breaking Changes:** None  
**New Endpoints:** 1 (`/agents/hierarchy/tree`)  
**Enhanced Endpoints:** 1 (`/agents/{agent_name}`)
