# 🤖 LLM Provider Guide

Your AI Runtime Framework supports **multiple LLM providers**! Choose the one that fits your needs.

---

## 📋 Supported Providers

| Provider | Model Examples | Best For | Cost |
|----------|---------------|----------|------|
| **Azure OpenAI** | GPT-4o, GPT-4, GPT-3.5 | Enterprise, Microsoft ecosystem | $$$ |
| **OpenAI** | GPT-4o, GPT-4, GPT-3.5 | General use, best quality | $$$ |
| **Anthropic** | Claude 3.5 Sonnet, Claude 3 Opus | Long context, safety | $$$ |
| **Google Gemini** | Gemini 1.5 Pro, Gemini 1.5 Flash | Multimodal, fast, cost-effective | $$ |
| **Ollama** | Llama 3.2, Mistral, Phi | Local, privacy, offline | FREE |
| **Local HF** | Llama 2, Mistral, any HuggingFace model | Custom models, full control | FREE |

---

## 🚀 Quick Setup

### 1️⃣ Azure OpenAI (Default)

**Use Case:** Enterprise applications, Microsoft Azure integration

**Setup:**

```bash
# Install dependencies (already included)
pip install langchain-openai openai
```

**Configure `.env`:**
```properties
LLM_PROVIDER=azure

AZURE_OPENAI_API_KEY=your-key-here
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_API_VERSION=2024-06-01
AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4o
```

**Get Credentials:**
1. Go to [Azure Portal](https://portal.azure.com)
2. Create Azure OpenAI resource
3. Deploy a model (e.g., GPT-4o)
4. Copy endpoint and API key

---

### 2️⃣ OpenAI (Direct)

**Use Case:** Quick setup, direct OpenAI access, no Azure account needed

**Setup:**

```bash
# Install dependencies
pip install langchain-openai openai
```

**Configure `.env`:**
```properties
LLM_PROVIDER=openai

OPENAI_API_KEY=sk-proj-...your-key-here
OPENAI_MODEL=gpt-4o
OPENAI_BASE_URL=https://api.openai.com/v1
```

**Get Credentials:**
1. Go to [OpenAI Platform](https://platform.openai.com)
2. Create API key in Settings → API Keys
3. Add billing information

**Available Models:**
- `gpt-4o` - Latest, most capable
- `gpt-4-turbo` - Fast, cost-effective
- `gpt-4` - Previous generation
- `gpt-3.5-turbo` - Cheapest, fastest

---

### 3️⃣ Anthropic Claude

**Use Case:** Long context (200K tokens), safety-focused, coding

**Setup:**

```bash
# Install Anthropic package
pip install langchain-anthropic
```

**Configure `.env`:**
```properties
LLM_PROVIDER=anthropic

ANTHROPIC_API_KEY=sk-ant-...your-key-here
ANTHROPIC_MODEL=claude-3-5-sonnet-20241022
```

**Get Credentials:**
1. Go to [Anthropic Console](https://console.anthropic.com)
2. Create API key
3. Add billing

**Available Models:**
- `claude-3-5-sonnet-20241022` - Best overall (recommended)
- `claude-3-opus-20240229` - Most capable, expensive
- `claude-3-sonnet-20240229` - Balanced
- `claude-3-haiku-20240307` - Fast, cheap

**Why Claude?**
- ✅ 200K token context window (vs 128K for GPT-4)
- ✅ Excellent coding abilities
- ✅ Strong safety guardrails
- ✅ Great for document analysis

---

### 4️⃣ Google Gemini

**Use Case:** Multimodal (vision/text), fast inference, Google ecosystem, cost-effective

**Setup:**

```bash
# Install Google Generative AI package
pip install langchain-google-genai
```

**Configure `.env`:**
```properties
LLM_PROVIDER=gemini

GOOGLE_API_KEY=AIzaSy...your-key-here
GEMINI_MODEL=gemini-1.5-pro
```

**Get Credentials:**
1. Go to [Google AI Studio](https://makersuite.google.com/app/apikey)
2. Create API key (free tier available!)
3. No billing required for free tier

**Available Models:**
- `gemini-1.5-pro` - Most capable, 2M token context (recommended)
- `gemini-1.5-flash` - Faster, cheaper, 1M context
- `gemini-pro` - Previous generation

**Why Gemini?**
- ✅ **2M token context** - Largest in the industry
- ✅ Multimodal (can process images, video, audio)
- ✅ Very fast inference
- ✅ Free tier with generous limits (60 requests/min)
- ✅ Cost-effective pricing

**Pricing (1M tokens):**
- Gemini 1.5 Pro: $1.25 input / $5 output
- Gemini 1.5 Flash: $0.075 input / $0.30 output (20x cheaper!)

---

### 5️⃣ Ollama (Local Models)

**Use Case:** Privacy, offline use, no API costs, local development

**Setup:**

```bash
# 1. Install Ollama
# Windows: Download from https://ollama.ai
# Mac: brew install ollama
# Linux: curl https://ollama.ai/install.sh | sh

# 2. Start Ollama server
ollama serve

# 3. Pull a model
ollama pull llama3.2
ollama pull mistral
ollama pull phi3

# 4. No additional Python packages needed (uses langchain-community)
```

**Configure `.env`:**
```properties
LLM_PROVIDER=ollama

OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=llama3.2
```

**Popular Models:**
- `llama3.2` (3B) - Fast, lightweight, good quality
- `llama3.2:70b` - Best quality, needs powerful GPU
- `mistral` - Fast, good for coding
- `phi3` - Microsoft's small model, efficient
- `codellama` - Specialized for code

**Advantages:**
- ✅ 100% free
- ✅ Runs locally (privacy)
- ✅ Works offline
- ✅ No rate limits
- ✅ No API costs

**Requirements:**
- Good GPU (NVIDIA recommended) for larger models
- 8GB+ RAM for small models (3B-7B)
- 16GB+ RAM for medium models (13B-34B)
- 32GB+ RAM for large models (70B+)

---

### 6️⃣ Local HuggingFace Models

**Use Case:** Custom models, fine-tuned models, research, full control

**Setup:**

```bash
# Install dependencies
pip install transformers torch accelerate
```

**Configure `.env`:**
```properties
LLM_PROVIDER=local

LOCAL_MODEL_PATH=meta-llama/Llama-2-7b-chat-hf
LOCAL_MODEL_DEVICE=cuda  # or 'cpu' for CPU-only
```

**Popular Models:**
- `meta-llama/Llama-2-7b-chat-hf` - Good general purpose
- `mistralai/Mistral-7B-Instruct-v0.2` - Fast, good quality
- `microsoft/phi-2` - Small but capable
- `tiiuae/falcon-7b-instruct` - Open source
- Any HuggingFace model that supports `AutoModelForCausalLM`

**Advantages:**
- ✅ Use ANY model from HuggingFace
- ✅ Fine-tune for your specific use case
- ✅ Complete control
- ✅ No API dependencies

**Requirements:**
- CUDA-capable GPU recommended
- Significant RAM (8GB+ for 7B models)
- Storage for model weights (several GB per model)

---

## ⚙️ Configuration Options

### Global LLM Settings

These apply to ALL providers:

```properties
# .env
LLM_PROVIDER=azure              # Which provider to use
LLM_MODEL_NAME=gpt-4o           # Model name (provider-specific)
LLM_TEMPERATURE=0.7             # Response randomness (0.0-1.0)
LLM_STREAMING=true              # Enable streaming responses
```

**Temperature Guide:**
- `0.0` - Deterministic, focused (good for code, math)
- `0.3-0.5` - Slightly creative (good for technical writing)
- `0.7-0.8` - Balanced (default, good for general use)
- `0.9-1.0` - Very creative (good for brainstorming, stories)

---

## 🔄 Switching Providers

**It's super easy!** Just change one line in `.env`:

```properties
# Switch to OpenAI
LLM_PROVIDER=openai

# Switch to Claude
LLM_PROVIDER=anthropic

# Switch to Gemini
LLM_PROVIDER=gemini

# Switch to Ollama
LLM_PROVIDER=ollama

# Switch to local model
LLM_PROVIDER=local
```

**That's it!** No code changes needed. The framework handles everything.

---

## 💰 Cost Comparison

### API-based (Pay per use)

| Provider | Model | Cost per 1M tokens (Input/Output) |
|----------|-------|-----------------------------------|
| OpenAI | GPT-4o | $2.50 / $10.00 |
| OpenAI | GPT-4 Turbo | $10.00 / $30.00 |
| OpenAI | GPT-3.5 Turbo | $0.50 / $1.50 |
| Anthropic | Claude 3.5 Sonnet | $3.00 / $15.00 |
| Anthropic | Claude 3 Opus | $15.00 / $75.00 |
| Google | Gemini 1.5 Pro | $1.25 / $5.00 |
| Google | Gemini 1.5 Flash | $0.075 / $0.30 |
| Azure OpenAI | Same as OpenAI | Same as OpenAI |

### Self-hosted (Free, but infrastructure costs)

| Option | Cost | Hardware Needed |
|--------|------|-----------------|
| Ollama (small 7B) | FREE | 8GB RAM, GPU optional |
| Ollama (large 70B) | FREE | 32GB+ RAM, powerful GPU |
| HuggingFace Local | FREE | Depends on model size |

**Cost Estimate for 1M tokens:**
- **OpenAI GPT-4o:** ~$12.50
- **Claude 3.5 Sonnet:** ~$18.00
- **Gemini 1.5 Pro:** ~$6.25 (50% cheaper than GPT-4o!)
- **Gemini 1.5 Flash:** ~$0.38 (97% cheaper!)
- **Ollama Llama 3.2:** FREE
- **Local HuggingFace:** FREE (electricity only)

---

## 🎯 Which Provider Should You Choose?

### Choose **Azure OpenAI** if:
- ✅ You're in an enterprise environment
- ✅ You already use Microsoft Azure
- ✅ You need compliance/security guarantees
- ✅ You want SLA guarantees

### Choose **OpenAI** if:
- ✅ You want the best quality AI
- ✅ You want quick setup (no Azure account)
- ✅ You're building a product prototype
- ✅ Budget is not a major constraint

### Choose **Anthropic Claude** if:
- ✅ You need very long context (200K tokens)
- ✅ You want strong safety/ethics
- ✅ You're doing document analysis
- ✅ You need excellent coding assistance

### Choose **Google Gemini** if:
- ✅ You want the **longest context** (2M tokens!)
- ✅ You need **multimodal** capabilities (vision, audio)
- ✅ You want **fast inference** and low latency
- ✅ You want **best price/performance** ratio
- ✅ You're on a **budget** (Flash model is 20x cheaper than GPT-4)
- ✅ You want a **generous free tier**

### Choose **Ollama** if:
- ✅ Privacy is critical (healthcare, legal, etc.)
- ✅ You need to work offline
- ✅ You want zero API costs
- ✅ You have decent hardware (GPU)
- ✅ You're in development/testing phase

### Choose **Local HuggingFace** if:
- ✅ You need a custom/fine-tuned model
- ✅ You're doing research
- ✅ You want complete control
- ✅ You have powerful hardware
- ✅ You want to avoid vendor lock-in

---

## 🔍 Testing Your Setup

After configuring, test with:

```bash
# Run the basic example
python app.py
```

You should see:
```
[LLM] Provider: azure  # (or whatever you chose)
[LLM] Using Azure OpenAI - gpt-4o
```

---

## 🐛 Troubleshooting

### Error: `ImportError: langchain-openai not installed`
**Solution:**
```bash
pip install langchain-openai
```

### Error: `ImportError: langchain-anthropic not installed`
**Solution:**
```bash
pip install langchain-anthropic
```

### Error: `ImportError: langchain-google-genai not installed`
**Solution:**
```bash
pip install langchain-google-genai
```

### Error: `Connection refused` (Ollama)
**Solution:**
```bash
# Start Ollama server
ollama serve

# In another terminal, verify it's running
curl http://localhost:11434
```

### Error: `Model not found` (Ollama)
**Solution:**
```bash
# Pull the model first
ollama pull llama3.2
```

### Error: `CUDA out of memory` (Local models)
**Solutions:**
1. Use a smaller model
2. Set `LOCAL_MODEL_DEVICE=cpu`
3. Use Ollama instead (better memory management)

---

## 📚 Learn More

- [OpenAI Pricing](https://openai.com/pricing)
- [Anthropic Pricing](https://www.anthropic.com/pricing)
- [Google AI Studio](https://makersuite.google.com)
- [Gemini API Docs](https://ai.google.dev/docs)
- [Ollama Models](https://ollama.ai/library)
- [HuggingFace Models](https://huggingface.co/models)

---

## 💡 Pro Tips

1. **Start with Ollama** for development (free, fast)
2. **Switch to OpenAI/Claude** for production (better quality)
3. **Use temperature=0.3** for technical tasks
4. **Use temperature=0.7-0.8** for creative tasks
5. **Enable streaming** for better user experience
6. **Monitor costs** with API-based providers

---

**Your framework is now LLM-agnostic! 🎉**

Choose what works best for your use case and switch anytime!
