# 🐛 Debug Mode Quick Reference

## Enable Debug Mode (3 Ways)

### 1. Global - All Agents
Edit `.env`:
```properties
DEBUG_MODE=true
```

### 2. Per Agent - Specific Agent
Edit `agents_config.yaml`:
```yaml
agents:
  - name: "general_assistant"
    debug: true  # Enable for this agent
    # ... other settings
```

### 3. Programmatically
```python
import os
os.environ['DEBUG_MODE'] = 'true'

from main import AgentFramework
framework = AgentFramework()
```

---

## What You'll See

### Without Debug Mode
```
[Agent: general_assistant] General purpose AI assistant
[Session: user_123] User: What time is it?

[general_assistant] Processing...

[general_assistant] Final response: The current time is 2:30 PM
```

### With Debug Mode
```
[Agent: general_assistant] General purpose AI assistant
[Session: user_123] User: What time is it?

[DEBUG] ===== Node: __start__ =====
[DEBUG] Starting execution

[DEBUG] ===== Node: model =====
[DEBUG] Invoking model with 1 message(s)
[DEBUG] System prompt: You are a helpful, friendly AI assistant...
[DEBUG] User message: What time is it?
[DEBUG] Model thinking...
[DEBUG] Model decision: Use tool 'get_current_time'

[DEBUG] ===== Node: tools =====
[DEBUG] Executing tool: get_current_time
[DEBUG] Tool input: {}
[DEBUG] Tool output: "2025-11-01 14:30:00"

[DEBUG] ===== Node: model =====
[DEBUG] Invoking model with 3 message(s) (including tool result)
[DEBUG] Model generating final response...
[DEBUG] Response: The current time is 2:30 PM

[DEBUG] ===== Node: __end__ =====
[DEBUG] Execution complete

[general_assistant] Final response: The current time is 2:30 PM
```

---

## Use Cases

### Development & Testing
```properties
# .env
DEBUG_MODE=true
HITL_ENABLED=true
```
See everything the agent does while developing.

### Production
```properties
# .env
DEBUG_MODE=false
HITL_ENABLED=false
```
Clean output for users.

### Debugging Specific Issue
```yaml
# agents_config.yaml
agents:
  - name: "problematic_agent"
    debug: true  # Debug only this one
    
  - name: "working_agent"
    debug: false  # Keep others quiet
```

---

## Debug Output Includes

✓ Node execution flow  
✓ Messages sent to LLM  
✓ LLM responses  
✓ Tool calls (what, when, why)  
✓ Tool inputs & outputs  
✓ State transitions  
✓ Error messages  

---

## Quick Test

```bash
# 1. Enable debug
echo "DEBUG_MODE=true" >> .env

# 2. Run test
python test_v1_migration.py

# 3. Try your app
python app.py
```

---

## Troubleshooting

**Not seeing debug output?**
1. Check `.env` file: `DEBUG_MODE=true`
2. Restart your application
3. Verify you're using updated `main.py`

**Too much output?**
1. Disable globally: `DEBUG_MODE=false`
2. Enable per-agent in `agents_config.yaml`
3. Redirect to file: `python app.py > debug.log 2>&1`

---

## Tips

💡 Use debug during development, disable in production  
💡 Debug specific agents, not all at once  
💡 Save debug output to analyze later  
💡 Combine with HITL for maximum control  

---

**That's it! Debug mode is now just one setting away. 🎉**
