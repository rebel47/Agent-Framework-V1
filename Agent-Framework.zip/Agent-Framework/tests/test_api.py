"""
Test FastAPI Integration
========================
Quick test script to verify the API server works correctly.

Usage:
    1. Start the API server: python api_server.py
    2. Run this test: python test_api.py
"""

import requests
import time

API_BASE_URL = "http://localhost:8000"

def test_api():
    """Test all API endpoints."""
    print("\n" + "="*80)
    print("🧪 Testing Agent Framework API")
    print("="*80 + "\n")
    
    # Wait for server to start
    print("⏳ Waiting for API server to be ready...")
    for i in range(10):
        try:
            response = requests.get(f"{API_BASE_URL}/health", timeout=2)
            if response.status_code == 200:
                print("✅ API server is ready!\n")
                break
        except requests.exceptions.RequestException:
            time.sleep(1)
    else:
        print("❌ API server is not responding. Please start it with: python api_server.py")
        return
    
    # Test 1: Root endpoint
    print("[Test 1] GET / - Root endpoint")
    response = requests.get(f"{API_BASE_URL}/")
    print(f"Status: {response.status_code}")
    print(f"Response: {response.json()}\n")
    assert response.status_code == 200
    
    # Test 2: Health check
    print("[Test 2] GET /health - Health check")
    response = requests.get(f"{API_BASE_URL}/health")
    print(f"Status: {response.status_code}")
    data = response.json()
    print(f"Status: {data['status']}")
    print(f"Framework initialized: {data['framework_initialized']}")
    print(f"Agents count: {data['agents_count']}")
    print(f"LLM provider: {data['llm_provider']}\n")
    assert response.status_code == 200
    assert data['status'] == 'healthy'
    
    # Test 3: List agents
    print("[Test 3] GET /agents - List all agents")
    response = requests.get(f"{API_BASE_URL}/agents")
    print(f"Status: {response.status_code}")
    data = response.json()
    print(f"Default agent: {data['default_agent']}")
    print(f"Total agents: {data['total_count']}")
    print(f"Agents: {', '.join(data['agents'])}")
    print(f"Expected agents: main_agent, weather_agent, calculator_agent (if using multiagent config)\n")
    assert response.status_code == 200
    assert len(data['agents']) > 0
    
    # Test 4: Get agent details
    print("[Test 4] GET /agents/{agent_name} - Get agent details")
    # Try to get main_agent first, fall back to first available
    agent_name = "main_agent" if "main_agent" in data['agents'] else data['agents'][0]
    response = requests.get(f"{API_BASE_URL}/agents/{agent_name}")
    print(f"Status: {response.status_code}")
    agent_info = response.json()
    print(f"Agent: {agent_info['name']}")
    print(f"Temperature: {agent_info['temperature']}")
    print(f"Tools: {len(agent_info['tools'])} tools")
    print(f"Debug: {agent_info.get('debug', False)}")
    print(f"HITL: {agent_info.get('hitl', False)}")
    if 'sub_agents' in agent_info:
        print(f"Sub-agents: {', '.join(agent_info['sub_agents'])}")
    print()
    assert response.status_code == 200
    
    # Test 5: Chat with agent (smart routing)
    print("[Test 5] POST /chat - Send message with smart routing")
    chat_request = {
        "message": "Hello, what can you help me with?",
        "thread_id": "test_api_001",
    }
    response = requests.post(
        f"{API_BASE_URL}/chat",
        json=chat_request,
    )
    print(f"Status: {response.status_code}")
    
    if response.status_code == 200:
        chat_response = response.json()
        print(f"Agent: {chat_response['agent_name']}")
        print(f"Thread ID: {chat_response['thread_id']}")
        print(f"Response: {chat_response['response'][:100]}...\n")
    else:
        print(f"Error: {response.text}\n")
    
    # Test 6: Chat with context (same thread)
    print("[Test 6] POST /chat - Continue conversation (same thread)")
    chat_request = {
        "message": "What was my previous question?",
        "thread_id": "test_api_001",  # Same thread ID
    }
    response = requests.post(
        f"{API_BASE_URL}/chat",
        json=chat_request,
    )
    print(f"Status: {response.status_code}")
    
    if response.status_code == 200:
        chat_response = response.json()
        print(f"Response: {chat_response['response'][:100]}...\n")
    else:
        print(f"Error: {response.text}\n")
    
    # Summary
    print("="*80)
    print("✅ All API tests completed!")
    print("="*80)
    print("\n📖 Visit http://localhost:8000/docs for interactive Swagger UI")
    print("📖 Visit http://localhost:8000/redoc for alternative documentation\n")


if __name__ == "__main__":
    try:
        test_api()
    except Exception as e:
        print(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
