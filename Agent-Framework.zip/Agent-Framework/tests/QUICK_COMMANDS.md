# Quick Test Commands

## Setup
```bash
# Install test dependencies
pip install pytest pytest-asyncio

# Ensure PostgreSQL is running
docker-compose up -d
```

## Run Tests

### All Tests
```bash
pytest tests/ -v
```

### Specific Test File
```bash
pytest tests/test_tools.py -v
pytest tests/test_framework_basic.py -v
pytest tests/test_conversations.py -v
pytest tests/test_multi_agent.py -v
```

### With Output (Shows print statements)
```bash
pytest tests/ -v -s
```

### Quick Tests (Skip slow multi-agent tests)
```bash
pytest tests/ -v -k "not multi_agent"
```

### Specific Test
```bash
pytest tests/test_tools.py::test_get_all_tools -v
```

### Stop on First Failure
```bash
pytest tests/ -v -x
```

### Show Test Coverage
```bash
pytest tests/ --cov=main --cov=tools_registry -v
```

## Run Examples

```bash
# Basic usage
python tests/examples/example_basic_usage.py

# Advanced features
python tests/examples/example_advanced.py

# Project generator
python tests/examples/example_project_generator.py
```

## Test Results
✅ **Tool Tests**: 4/4 PASSED (0.27s)

Run other tests to verify:
```bash
pytest tests/test_framework_basic.py -v -s
pytest tests/test_conversations.py -v -s
```
