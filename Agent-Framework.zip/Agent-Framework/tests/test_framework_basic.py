"""
Test basic agent functionality and framework initialization.
"""

import pytest
from main import AgentFramework


@pytest.mark.asyncio
async def test_framework_initialization():
    """Test that the framework initializes correctly."""
    # Use multiagent config for testing
    from pathlib import Path
    config_path = Path(__file__).parent.parent / "multiagent" / "agents.yaml"
    
    framework = AgentFramework(str(config_path))
    await framework.initialize_async()
    
    # Check that agents are loaded
    assert len(framework.agents) > 0, "No agents were loaded"
    
    # Check that default agent is set
    assert framework.default_agent_name is not None, "No default agent set"
    
    # Check that agents have tools loaded
    # In new system, all_tools is empty - tools are loaded per agent
    agent_with_tools = False
    for agent_name, agent_data in framework.agents.items():
        if len(agent_data['tools']) > 0:
            agent_with_tools = True
            print(f"\n✓ Agent '{agent_name}' has {len(agent_data['tools'])} tools")
            break
    
    assert agent_with_tools, "No agents have tools loaded"
    
    await framework.cleanup()


@pytest.mark.asyncio
async def test_list_agents(framework):
    """Test that we can list all available agents."""
    agents = framework.list_agents()
    
    assert len(agents) > 0, "No agents available"
    # Updated: Use current agent names
    assert "main_agent" in agents or "weather_agent" in agents, "Expected agents not found"
    
    print(f"\n✓ Found {len(agents)} agents: {', '.join(agents)}")


@pytest.mark.asyncio
async def test_get_specific_agent(framework):
    """Test retrieving a specific agent."""
    # Updated: Use current agent name
    agents = framework.list_agents()
    test_agent_name = agents[0] if agents else "main_agent"
    
    agent_data = framework.get_agent(test_agent_name)
    
    assert agent_data is not None, "Agent not found"
    assert "agent" in agent_data, "Agent object missing"
    assert "config" in agent_data, "Agent config missing"
    assert "tools" in agent_data, "Agent tools missing"
    
    print(f"\n✓ Agent '{test_agent_name}' has {len(agent_data['tools'])} tools")


@pytest.mark.asyncio
async def test_get_default_agent(framework):
    """Test retrieving the default agent."""
    agent_data = framework.get_agent()  # No name = default
    
    assert agent_data is not None, "Default agent not found"
    assert agent_data["config"]["name"] == framework.default_agent_name
    
    print(f"\n✓ Default agent is: {framework.default_agent_name}")


@pytest.mark.asyncio
async def test_invalid_agent_raises_error(framework):
    """Test that requesting an invalid agent raises ValueError."""
    with pytest.raises(ValueError, match="Agent 'nonexistent' not found"):
        framework.get_agent("nonexistent")
    
    print("\n✓ Correctly raises error for invalid agent")


@pytest.mark.asyncio
async def test_llm_configuration():
    """Test that LLM configuration loads correctly."""
    from pathlib import Path
    config_path = Path(__file__).parent.parent / "multiagent" / "agents.yaml"
    
    framework = AgentFramework(str(config_path))
    
    assert framework.llm_config is not None, "LLM config not loaded"
    assert framework.llm_config.provider is not None, "LLM provider not set"
    
    print(f"\n✓ LLM Provider: {framework.llm_config.provider.value}")
    print(f"✓ Temperature: {framework.llm_config.temperature}")
    
    await framework.cleanup()


@pytest.mark.asyncio
async def test_smart_router_initialization(framework):
    """Test that tools are properly loaded per agent."""
    # In new system, tools are loaded per agent via tool_imports
    # Check that at least one agent has tools
    total_tools = 0
    all_tool_names = set()
    
    for agent_name, agent_data in framework.agents.items():
        agent_tools = agent_data['tools']
        total_tools += len(agent_tools)
        for tool in agent_tools:
            all_tool_names.add(tool.name)
    
    assert total_tools > 0, "No tools loaded across any agents"
    
    # Check for essential tools
    assert "get_current_time" in all_tool_names, "get_current_time tool not found"
    
    print(f"\n✓ Found {total_tools} total tool assignments across {len(framework.agents)} agents")
    print(f"✓ Unique tools: {', '.join(sorted(all_tool_names))}")
    print("\n✓ Tools loaded successfully")

