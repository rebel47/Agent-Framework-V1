"""
Tests for the AI Agent Framework.

This package contains comprehensive tests for all framework features.
"""
