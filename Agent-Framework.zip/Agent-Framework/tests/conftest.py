"""
Pytest configuration and shared fixtures for testing the Agent Framework.
"""

import pytest
import asyncio
from pathlib import Path
import sys

# Add parent directory to path to import main module
sys.path.insert(0, str(Path(__file__).parent.parent))

from main import AgentFramework


@pytest.fixture(scope="session")
def event_loop():
    """Create an event loop for async tests."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest.fixture
async def framework():
    """
    Fixture that provides an initialized AgentFramework instance.
    Automatically cleans up after the test.
    Uses multiagent/agents.yaml for testing.
    """
    # Try multiagent config first, fall back to agents_config.yaml
    config_path = Path(__file__).parent.parent / "multiagent" / "agents.yaml"
    if not config_path.exists():
        config_path = "agents_config.yaml"
    
    # Framework auto-initializes in __init__, no need for separate initialize()
    fw = AgentFramework(str(config_path))
    await fw.initialize_async()  # Initialize checkpointer and agents
    yield fw
    await fw.cleanup()


@pytest.fixture
def test_session_id():
    """Provide a unique session ID for each test."""
    import uuid
    return f"test_session_{uuid.uuid4().hex[:8]}"
