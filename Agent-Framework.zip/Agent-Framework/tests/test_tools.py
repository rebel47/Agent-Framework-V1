"""
Test the tools registry and tool functionality with explicit imports.
"""

import pytest
import sys
from pathlib import Path

# Add parent to path to import main
sys.path.insert(0, str(Path(__file__).parent.parent))

from main import _load_tools_from_imports
import tools_registry


def test_tool_decorator_import():
    """Test that @tool decorator can be imported from main."""
    from main import tool
    
    # Create a test tool
    @tool
    def test_tool_func(query: str) -> str:
        """Test tool function."""
        return f"Test: {query}"
    
    assert hasattr(test_tool_func, 'name')
    assert hasattr(test_tool_func, 'description')
    assert test_tool_func.name == "test_tool_func"
    
    print("\n✓ Tool decorator import works correctly")


def test_explicit_tool_imports():
    """Test loading tools via explicit imports."""
    tool_imports = [
        "tools_registry.get_current_time",
        "tools_registry.calculate"
    ]
    
    tools = _load_tools_from_imports(tool_imports)
    
    assert len(tools) == 2, f"Expected 2 tools, got {len(tools)}"
    
    tool_names = [tool.name for tool in tools]
    assert "get_current_time" in tool_names
    assert "calculate" in tool_names
    
    print(f"\n✓ Successfully loaded tools via explicit imports: {tool_names}")


def test_invalid_tool_import():
    """Test that invalid imports are handled gracefully."""
    tool_imports = [
        "tools_registry.get_current_time",
        "tools_registry.nonexistent_tool"  # This should be skipped
    ]
    
    tools = _load_tools_from_imports(tool_imports)
    
    # Should only get the valid tool
    assert len(tools) == 1, "Should only return valid tools"
    assert tools[0].name == "get_current_time"
    
    print("\n✓ Correctly handles invalid tool imports")


def test_invalid_module_import():
    """Test that invalid module imports are handled gracefully."""
    tool_imports = [
        "nonexistent_module.some_tool"
    ]
    
    tools = _load_tools_from_imports(tool_imports)
    
    # Should return empty list
    assert len(tools) == 0, "Should return empty list for invalid module"
    
    print("\n✓ Correctly handles invalid module imports")


def test_tool_has_required_attributes():
    """Test that tools have required attributes."""
    # Test with known tools
    tool_imports = [
        "tools_registry.get_current_time",
        "tools_registry.calculate"
    ]
    tools = _load_tools_from_imports(tool_imports)
    
    for tool in tools:
        assert hasattr(tool, "name"), f"Tool missing 'name' attribute"
        assert hasattr(tool, "description"), f"Tool {tool.name} missing 'description'"
        assert tool.description, f"Tool {tool.name} has empty description"
        
    print(f"\n✓ All {len(tools)} tools have required attributes")


def test_tool_invocation():
    """Test that loaded tools can be invoked."""
    tool_imports = ["tools_registry.get_current_time"]
    tools = _load_tools_from_imports(tool_imports)
    
    assert len(tools) == 1
    time_tool = tools[0]
    
    # Invoke the tool
    result = time_tool.invoke({})
    
    assert result is not None
    assert isinstance(result, str)
    assert len(result) > 0  # Should return a timestamp string
    
    print(f"\n✓ Tool invocation successful: {result}")
