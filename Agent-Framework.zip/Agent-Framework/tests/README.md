# Agent Framework Tests

This directory contains comprehensive tests for the AI Agent Framework.

## Structure

```
tests/
├── conftest.py                    # Pytest configuration and fixtures
├── test_framework_basic.py        # Basic framework initialization tests
├── test_conversations.py          # Agent conversation and response tests
├── test_tools.py                  # Tool registry and functionality tests
├── test_multi_agent.py           # Multi-agent collaboration tests
└── examples/                      # Example usage scripts
    ├── example_basic_usage.py     # Basic framework usage
    ├── example_advanced.py        # Advanced features
    └── example_project_generator.py  # Multi-agent project generator
```

## Running Tests

### Install pytest

```bash
pip install pytest pytest-asyncio
```

### Run all tests

```bash
# From the project root directory
pytest tests/ -v
```

### Run specific test file

```bash
pytest tests/test_framework_basic.py -v
```

### Run specific test

```bash
pytest tests/test_framework_basic.py::test_framework_initialization -v
```

### Run with output

```bash
pytest tests/ -v -s  # -s shows print statements
```

### Run only quick tests (skip multi-agent tests)

```bash
pytest tests/ -v -k "not multi_agent"
```

## Test Categories

### 1. Framework Basic Tests (`test_framework_basic.py`)
- Framework initialization
- Agent loading and configuration
- LLM configuration
- Agent retrieval and validation
- Smart routing setup

**Example:**
```bash
pytest tests/test_framework_basic.py -v
```

### 2. Conversation Tests (`test_conversations.py`)
- Simple conversations
- Tool usage (calculator, weather, time)
- Conversation memory/context
- Multi-turn conversations
- Smart routing behavior

**Example:**
```bash
pytest tests/test_conversations.py -v -s
```

### 3. Tools Tests (`test_tools.py`)
- Tool registry functionality
- Tool retrieval by name
- Tool validation
- Calculator tools (4 tools)
- Weather tools (3 tools)
- Utility tools (1 tool)

**Example:**
```bash
pytest tests/test_tools.py -v
```

### 4. Multi-Agent Tests (`test_multi_agent.py`)
- Hierarchical agent structure (main_agent → sub_agents)
- Individual specialized agents (weather, calculator)
- Smart LLM-based routing
- Per-agent HITL configuration
- Agent collaboration workflows

**Example:**
```bash
pytest tests/test_multi_agent.py -v -s
```

## Test Fixtures

### `framework`
Provides an initialized AgentFramework instance with automatic cleanup.

```python
@pytest.mark.asyncio
async def test_example(framework):
    response = await framework.run_conversation("Hello", "session_1")
    assert response is not None
```

### `test_session_id`
Provides a unique session ID for each test.

```python
@pytest.mark.asyncio
async def test_example(framework, test_session_id):
    response = await framework.run_conversation("Hello", test_session_id)
```

## Environment Setup

Tests use the same `.env` configuration as the main application. Make sure:

1. **PostgreSQL is running:**
   ```bash
   docker-compose up -d
   ```

2. **Environment variables are set** in `.env`:
   - `AZURE_OPENAI_ENDPOINT`
   - `AZURE_OPENAI_API_KEY`
   - `AZURE_OPENAI_DEPLOYMENT_NAME`
   - `POSTGRES_URL`

3. **Debug mode** (optional):
   - Set per-agent in `agents.yaml`: `debug: true`
   - Or set `LOG_LEVEL=DEBUG` in `.env` for all logging

**Note:** `HITL_ENABLED` is no longer used. HITL is now configured per-agent in `agents.yaml` with `hitl: true/false`.

## Expected Results

All tests should pass when the framework is properly configured:

```
tests/test_framework_basic.py::test_framework_initialization PASSED
tests/test_framework_basic.py::test_list_agents PASSED
tests/test_framework_basic.py::test_get_specific_agent PASSED
tests/test_conversations.py::test_simple_conversation PASSED
tests/test_conversations.py::test_tool_usage PASSED
tests/test_tools.py::test_get_all_tools PASSED
tests/test_multi_agent.py::test_orchestrator_agent PASSED
...
```

## Running Examples

Examples in the `examples/` folder can be run directly:

```bash
# Basic usage example
python tests/examples/example_basic_usage.py

# Advanced features example
python tests/examples/example_advanced.py

# Multi-agent project generator
python tests/examples/example_project_generator.py
```

**Or use the working multiagent example:**
```bash
cd multiagent
python agents.py          # CLI mode
python agents.py --api    # API mode
```

## Troubleshooting

### Tests fail with "Connection refused"
- Make sure PostgreSQL is running: `docker ps`
- Start it with: `docker-compose up -d`

### Tests fail with "API key not found"
- Check your `.env` file has the correct Azure OpenAI credentials
- Ensure `AZURE_OPENAI_ENDPOINT` and `AZURE_OPENAI_API_KEY` are set

### Tests timeout
- Some tests involve AI generation and may take longer
- Check your network connection
- Verify API credentials are valid

### Import errors
- Make sure you're in the project root directory
- Install all dependencies: `pip install -r requirements.txt`

## Writing New Tests

When adding new tests:

1. Use the `@pytest.mark.asyncio` decorator for async tests
2. Use the `framework` fixture for initialized framework
3. Use the `test_session_id` fixture for unique sessions
4. Add descriptive docstrings
5. Include print statements for debugging (visible with `-s` flag)

Example:

```python
@pytest.mark.asyncio
async def test_my_feature(framework, test_session_id):
    """Test description here."""
    response = await framework.run_conversation(
        user_message="test message",
        session_id=test_session_id,
        agent_name="main_agent"  # Use current agent names
    )
    
    assert response is not None, "No response received"
    print(f"\n✓ Test passed: {response[:50]}...")
```

## CI/CD Integration

To integrate with CI/CD pipelines:

```yaml
# Example GitHub Actions
- name: Run tests
  run: |
    pip install pytest pytest-asyncio
    pytest tests/ -v --tb=short
```

## Performance Notes

- Basic tests: ~2-5 seconds each
- Conversation tests: ~5-15 seconds each (depends on LLM API)
- Multi-agent tests: ~30-60 seconds each (multiple LLM calls)

Use `-k` to filter tests for faster development cycles.
