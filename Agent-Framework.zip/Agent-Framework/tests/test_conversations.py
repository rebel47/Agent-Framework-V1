"""
Test agent conversation and response capabilities.
"""

import pytest


@pytest.mark.asyncio
async def test_simple_conversation(framework, test_session_id):
    """Test a simple conversation with an agent."""
    response = await framework.run_conversation(
        user_message="Hello!",
        session_id=test_session_id
        # agent_name is optional - uses default (main_agent)
    )
    
    assert response is not None, "No response received"
    assert len(response) > 0, "Empty response"
    
    print(f"\n✓ Response: {response[:100]}...")


@pytest.mark.asyncio
async def test_smart_routing_weather(framework, test_session_id):
    """Test that smart routing directs weather queries to weather agent."""
    response = await framework.run_conversation(
        user_message="What's the weather like?",
        session_id=test_session_id
    )
    
    assert response is not None, "No response received"
    # Smart routing should handle weather queries
    
    print(f"\n✓ Weather query response: {response[:150]}...")


@pytest.mark.asyncio
async def test_tool_usage(framework, test_session_id):
    """Test that an agent can use tools."""
    response = await framework.run_conversation(
        user_message="What time is it?",
        session_id=test_session_id
    )
    
    assert response is not None, "No response received"
    # The response should contain some time information
    
    print(f"\n✓ Tool usage response: {response[:150]}...")


@pytest.mark.asyncio
async def test_calculator_tool(framework, test_session_id):
    """Test the calculator tool with direct agent selection."""
    # Mock HITL approval to avoid stdin issues
    from unittest.mock import patch
    with patch('builtins.input', return_value='y'):
        # Use calculator_agent directly to avoid smart routing issues
        response = await framework.run_conversation(
            user_message="Calculate 123 * 456",
            session_id=test_session_id,
            agent_name="calculator_agent"
        )
    
    assert response is not None, "No response received"
    # Should contain the result 56088
    # Note: Calculator agent may require HITL approval in some configs
    
    print(f"\n✓ Calculator result: {response}")


@pytest.mark.asyncio
async def test_conversation_memory(framework, test_session_id):
    """Test that conversation memory persists across messages."""
    # First message
    response1 = await framework.run_conversation(
        user_message="My favorite color is blue.",
        session_id=test_session_id
    )
    
    assert response1 is not None
    
    # Second message - ask about previous message
    response2 = await framework.run_conversation(
        user_message="What did I just tell you about my favorite color?",
        session_id=test_session_id
    )
    
    assert response2 is not None
    assert "blue" in response2.lower(), "Agent didn't remember previous message"
    
    print(f"\n✓ Memory test passed - agent remembered: {response2[:150]}...")


@pytest.mark.asyncio
async def test_hierarchical_agents(framework, test_session_id):
    """Test hierarchical agent structure with main agent routing to sub-agents."""
    # Get list of agents
    agents = framework.list_agents()
    
    # Test with main agent (if it exists)
    if "main_agent" in agents:
        response = await framework.run_conversation(
            user_message="What can you help me with?",
            session_id=test_session_id,
            agent_name="main_agent"
        )
        
        assert response is not None
        assert len(response) > 0
        
        print(f"\n✓ Main agent response: {response[:150]}...")
    else:
        print("\n✓ Skipping hierarchical test - main_agent not in config")
