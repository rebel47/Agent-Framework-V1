"""
Test script to verify LangChain v1 migration is working correctly.
Run this to ensure the framework works with the new create_agent API.
"""

import asyncio
import os
from main import AgentFramework

async def test_basic_functionality():
    """Test basic agent creation and functionality."""
    print("="*70)
    print("Testing LangChain v1 Migration")
    print("="*70)
    
    # Test 1: Import check
    print("\n[Test 1] Checking imports...")
    try:
        from langchain.agents import create_agent
        print("✓ create_agent imported successfully")
    except ImportError as e:
        print(f"✗ Import failed: {e}")
        return False
    
    # Test 2: Framework initialization
    print("\n[Test 2] Initializing framework...")
    try:
        framework = AgentFramework()
        print("✓ Framework initialized")
    except Exception as e:
        print(f"✗ Initialization failed: {e}")
        return False
    
    # Test 3: Async setup
    print("\n[Test 3] Setting up async components...")
    try:
        await framework.initialize_async()
        print("✓ Async initialization complete")
    except Exception as e:
        print(f"✗ Async setup failed: {e}")
        return False
    
    # Test 4: List agents
    print("\n[Test 4] Listing available agents...")
    try:
        agents = framework.list_agents()
        print(f"✓ Found {len(agents)} agents: {', '.join(agents)}")
    except Exception as e:
        print(f"✗ Failed to list agents: {e}")
        return False
    
    # Test 5: Check debug mode
    print("\n[Test 5] Checking debug mode configuration...")
    try:
        debug_mode = os.getenv("DEBUG_MODE", "false").lower() == "true"
        print(f"✓ Global debug mode: {debug_mode}")
        
        # Check per-agent debug settings
        for agent_name in framework.list_agents():
            agent_data = framework.get_agent(agent_name)
            agent_debug = agent_data.get('debug', False)
            print(f"  - {agent_name}: debug={agent_debug}")
    except Exception as e:
        print(f"✗ Debug check failed: {e}")
        return False
    
    # Test 6: Simple conversation (optional - requires database)
    print("\n[Test 6] Testing conversation...")
    try:
        # Disable HITL for automated testing
        framework.hitl.require_approval = False
        
        print("  Running test conversation...")
        response = await framework.run_conversation(
            user_message="What is 2 + 2?",
            session_id="test_session",
            agent_name=framework.default_agent_name
        )
        print(f"✓ Conversation successful")
        if response:
            print(f"  Response: {response[:100]}...")
    except Exception as e:
        print(f"⚠ Conversation test skipped: {e}")
        print("  (This is OK if database is not running)")
    
    # Cleanup
    print("\n[Cleanup] Releasing resources...")
    try:
        await framework.cleanup()
        print("✓ Cleanup complete")
    except Exception as e:
        print(f"⚠ Cleanup warning: {e}")
    
    print("\n" + "="*70)
    print("✓ All tests passed! Migration successful!")
    print("="*70)
    print("\nNext steps:")
    print("1. Enable debug mode: Set DEBUG_MODE=true in .env")
    print("2. Run your app: python app.py")
    print("3. Watch the AI agent's thought process!")
    print("="*70)
    
    return True

if __name__ == "__main__":
    try:
        asyncio.run(test_basic_functionality())
    except KeyboardInterrupt:
        print("\n\nTest interrupted by user")
    except Exception as e:
        print(f"\n\n✗ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
