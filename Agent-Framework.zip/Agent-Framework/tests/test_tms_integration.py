"""
TMS Integration Test Suite
Tests for TMS agents, tools, and framework integration
"""

import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest

# Try to import TMS, skip all tests if not available
try:
    from tms import (
        TMSAgentManager,
        integrate_with_framework,
        get_tms_agents,
        get_tms_tools,
        validate_tms,
        tms_analyzer,
        tms_email_sender,
        tms_get_config,
        TMS,
        TMSKnowledge
    )
    TMS_AVAILABLE = True
except ImportError:
    TMS_AVAILABLE = False
    pytestmark = pytest.mark.skip(reason="TMS module not installed")


class TestTMSConfiguration:
    """Test TMS configuration and setup"""
    
    def test_tms_config_loads(self):
        """Test that TMS configuration loads successfully"""
        manager = TMSAgentManager()
        assert manager is not None
        assert manager.config is not None
    
    def test_agents_loaded(self):
        """Test that TMS agents are loaded"""
        manager = TMSAgentManager()
        agents = manager.get_agent_configs()
        
        # Should have at least 3 agents (diagnostics, log_analyzer, email)
        assert len(agents) >= 3
        
        # Check agent names
        agent_names = [agent['name'] for agent in agents]
        assert 'tms_diagnostics' in agent_names
        assert 'tms_log_analyzer' in agent_names
        assert 'tms_email' in agent_names
    
    def test_tools_loaded(self):
        """Test that TMS tools are loaded"""
        manager = TMSAgentManager()
        tools = manager.get_tools()
        
        # Should have 3 tools
        assert len(tools) == 3
        
        # Check tool names
        tool_names = manager.get_tool_names()
        assert 'tms_analyzer' in tool_names
        assert 'tms_email_sender' in tool_names
        assert 'tms_get_config' in tool_names
    
    def test_validation(self):
        """Test TMS validation"""
        validation = validate_tms()
        
        assert 'status' in validation
        assert 'agents' in validation
        assert 'tools' in validation
        assert 'issues' in validation
        
        # Status should be OK or WARNING (not ERROR)
        assert validation['status'] in ['OK', 'WARNING']


class TestTMSTools:
    """Test TMS tools functionality"""
    
    def test_tms_analyzer_tool(self):
        """Test tms_analyzer tool"""
        # Test with valid query
        result = tms_analyzer.invoke({"query": "preset 2 bay 3"})
        assert result is not None
        assert isinstance(result, str)
        assert len(result) > 0
        
        # Should contain some expected keywords
        # (channel info, or error message if files not found)
        assert any(keyword in result.lower() for keyword in 
                  ['channel', 'preset', 'bay', 'not found', 'configuration'])
    
    def test_tms_analyzer_invalid_query(self):
        """Test tms_analyzer with invalid query"""
        result = tms_analyzer.invoke({"query": "random text without preset or bay"})
        assert result is not None
        assert 'Could not parse' in result or 'provide' in result.lower()
    
    def test_tms_email_sender_draft_mode(self):
        """Test tms_email_sender in draft mode (default)"""
        result = tms_email_sender.invoke({
            "query": "draft email about bay 4 issue"
        })
        assert result is not None
        assert isinstance(result, str)
        
        # Should contain email elements
        assert any(keyword in result for keyword in 
                  ['EMAIL', 'Subject:', 'To:', 'Body:', 'generated'])
    
    def test_tms_get_config(self):
        """Test tms_get_config tool"""
        result = tms_get_config.invoke({})
        assert result is not None
        assert 'CONFIGURATION' in result or 'Platform' in result
        assert 'XML' in result or 'Log' in result


class TestTMSServices:
    """Test TMS service layer"""
    
    def test_tms_get_config_info(self):
        """Test TMS.get_config_info()"""
        config = TMS.get_config_info()
        
        assert 'platform' in config
        assert 'base_path' in config
        assert 'xml_path' in config
        assert 'log_path' in config
        assert 'xml_exists' in config
        assert 'log_exists' in config
    
    def test_tms_find_channel(self):
        """Test TMS.find_channel_by_preset()"""
        # This test requires XML file to exist
        config = TMS.get_config_info()
        
        if config['xml_exists']:
            # Test with known values (adjust based on your XML)
            channel = TMS.find_channel_by_preset("2", "3")
            # Should return channel or None
            assert channel is None or isinstance(channel, str)
        else:
            pytest.skip("XML config file not found - skipping channel lookup test")
    
    def test_tms_timestamp(self):
        """Test TMS.get_current_timestamp()"""
        timestamp = TMS.get_current_timestamp()
        assert timestamp is not None
        assert isinstance(timestamp, str)
        # Should be in format YYYY-MM-DD HH:MM:SS
        assert len(timestamp) >= 19


class TestTMSKnowledge:
    """Test TMS knowledge base"""
    
    def test_get_system_info(self):
        """Test TMSKnowledge.get_system_info()"""
        info = TMSKnowledge.get_system_info()
        
        assert 'name' in info
        assert 'purpose' in info
        assert 'components' in info
        assert 'Terminal Management System' in info['name']
    
    def test_get_alarm_info(self):
        """Test TMSKnowledge.get_alarm_info()"""
        # Test known alarm
        alarm = TMSKnowledge.get_alarm_info("1001")
        assert 'description' in alarm
        assert 'severity' in alarm
        assert 'action' in alarm
        
        # Test unknown alarm
        alarm_unknown = TMSKnowledge.get_alarm_info("9999")
        assert 'unknown' in alarm_unknown['description'].lower()
    
    def test_get_operational_procedure(self):
        """Test TMSKnowledge.get_operational_procedure()"""
        procedure = TMSKnowledge.get_operational_procedure("loading_sequence")
        assert procedure is not None
        assert isinstance(procedure, list)
        assert len(procedure) > 0
    
    def test_get_command_help(self):
        """Test TMSKnowledge.get_command_help()"""
        help_info = TMSKnowledge.get_command_help("trlist")
        assert 'purpose' in help_info
        assert 'syntax' in help_info


class TestTMSIntegration:
    """Test TMS framework integration"""
    
    def test_integrate_tms(self):
        """Test integrate_with_framework()"""
        integration = integrate_with_framework()
        
        assert 'agents' in integration
        assert 'tools' in integration
        assert 'tool_names' in integration
        assert 'validation' in integration
        
        # Check agents
        assert len(integration['agents']) >= 3
        
        # Check tools
        assert len(integration['tools']) == 3
        assert len(integration['tool_names']) == 3
    
    def test_get_tms_agent_configs(self):
        """Test get_tms_agents()"""
        configs = get_tms_agents()
        
        assert isinstance(configs, list)
        assert len(configs) >= 3
        
        # Each config should have required fields
        for config in configs:
            assert 'name' in config
            assert 'description' in config
            assert 'system_prompt' in config
            assert 'tools' in config
            assert 'enabled' in config
    
    def test_get_tms_tools_for_framework(self):
        """Test get_tms_tools()"""
        tools = get_tms_tools()
        
        assert isinstance(tools, list)
        assert len(tools) == 3
        
        # Each tool should have name and description
        for tool in tools:
            assert hasattr(tool, 'name')
            assert hasattr(tool, 'description')


class TestTMSAgentManager:
    """Test TMSAgentManager class"""
    
    def test_manager_initialization(self):
        """Test TMSAgentManager initialization"""
        manager = TMSAgentManager()
        
        assert manager.config is not None
        assert manager.tools is not None
        assert manager.agents is not None
    
    def test_get_agent_summary(self):
        """Test get_agent_summary()"""
        manager = TMSAgentManager()
        summary = manager.get_agent_summary()
        
        assert summary is not None
        assert isinstance(summary, str)
        assert 'TMS AGENTS' in summary
        assert 'tms_diagnostics' in summary
    
    def test_get_tools_summary(self):
        """Test get_tools_summary()"""
        manager = TMSAgentManager()
        summary = manager.get_tools_summary()
        
        assert summary is not None
        assert isinstance(summary, str)
        assert 'TMS TOOLS' in summary
        assert 'tms_analyzer' in summary
    
    def test_validate_configuration(self):
        """Test validate_configuration()"""
        manager = TMSAgentManager()
        validation = manager.validate_configuration()
        
        assert 'status' in validation
        assert 'agents' in validation
        assert 'tools' in validation
        assert validation['agents'] >= 3
        assert validation['tools'] == 3


# ============================================================================
# Test Runners
# ============================================================================

def run_all_tests():
    """Run all TMS tests"""
    print("🧪 Running TMS Integration Tests")
    print("=" * 70)
    
    pytest.main([__file__, '-v', '--tb=short'])


def run_quick_validation():
    """Quick validation test without pytest"""
    print("🔍 Quick TMS Validation")
    print("=" * 70)
    
    try:
        # Test 1: Manager initialization
        print("\n1. Testing TMSAgentManager initialization...")
        manager = TMSAgentManager()
        print(f"   ✅ Manager initialized: {len(manager.agents)} agents, {len(manager.tools)} tools")
        
        # Test 2: Validation
        print("\n2. Testing TMS validation...")
        validation = validate_tms()
        print(f"   Status: {validation['status']}")
        print(f"   Agents: {validation['agents']}")
        print(f"   Tools: {validation['tools']}")
        if validation['issues']:
            print("   ⚠️  Issues:")
            for issue in validation['issues']:
                print(f"      - {issue}")
        else:
            print("   ✅ No issues found")
        
        # Test 3: Configuration
        print("\n3. Testing TMS configuration...")
        config = TMS.get_config_info()
        print(f"   Platform: {config['platform']}")
        print(f"   XML Config: {'✅ Found' if config['xml_exists'] else '❌ Not Found'}")
        print(f"   Trace Log: {'✅ Found' if config['log_exists'] else '❌ Not Found'}")
        
        # Test 4: Tools
        print("\n4. Testing TMS tools...")
        result = tms_get_config.invoke({})
        print("   ✅ tms_get_config works")
        
        result = tms_analyzer.invoke({"query": "preset 2 bay 3"})
        print("   ✅ tms_analyzer works")
        
        result = tms_email_sender.invoke({"query": "draft email about test"})
        print("   ✅ tms_email_sender works")
        
        print("\n" + "=" * 70)
        print("✅ All quick validation tests passed!")
        
    except Exception as e:
        print(f"\n❌ Validation failed: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == '--quick':
        run_quick_validation()
    else:
        run_all_tests()
