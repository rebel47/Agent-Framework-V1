# Agent Framework Examples

This folder contains practical examples demonstrating how to use the AI Agent Framework.

## 🚀 Recommended: Start with the Working Example

**Best starting point:**
```bash
cd multiagent
python agents.py          # CLI mode with smart routing
python agents.py --api    # API mode
```

This demonstrates:
- ✅ Hierarchical agent structure (main_agent → weather_agent, calculator_agent)
- ✅ LLM-based smart routing (no hardcoded keywords)
- ✅ Per-agent HITL (calculator requires approval)
- ✅ Factory functions (create_cli, create_api)

---

## Examples in This Folder

### 1. Basic Usage (`example_basic_usage.py`)

**Purpose**: Demonstrates basic framework usage with factory functions.

**Features**:
- Using `create_cli()` factory function
- Simple conversations with agents
- Tool usage (calculator, weather, time)
- Smart routing demonstration

**Run**:
```bash
python tests/examples/example_basic_usage.py
```

**What it does**:
1. Uses `create_cli()` for instant setup
2. Asks "What time is it?" - demonstrates utility tool
3. Asks "What's the weather in Paris?" - routed to weather_agent
4. Asks "Calculate 123 * 456" - routed to calculator_agent (with HITL)
5. Shows smart routing in action

---

### 2. CLI with Factory Function (`example_cli.py`) [Recommended]

**Purpose**: Modern way to create a CLI using factory functions.

**Features**:
- ✅ One-line setup with `create_cli()`
- 🧠 Smart routing enabled by default
- 🔄 Hierarchical agent support
- 💬 Interactive chat interface
- 📋 Command system (help, agents, stats, clear, quit)

**Run**:
```bash
python tests/examples/example_cli.py
```

**What it does**:
1. Initializes framework with `create_cli()` factory function
2. Starts interactive CLI interface
3. Enables smart routing across all agents
4. Provides built-in commands for agent management

**Available commands**:
- `help` - Show available commands
- `agents` - List available agents
- `stats` - Show conversation statistics
- `clear` - Clear conversation history
- `quit` - Exit the application

---

### 3. Advanced Features (`example_advanced.py`)

**Purpose**: Shows advanced framework capabilities and direct framework use.

**Features**:
- Direct `AgentFramework` class usage (not factory functions)
- Multiple agent usage
- Conversation memory/context
- Custom agent selection
- Session management
- Hierarchical agent interaction

**Run**:
```bash
python tests/examples/example_advanced.py
```

**What it does**:
1. Uses `AgentFramework` class directly for advanced control
2. Interacts with main_agent for orchestration
3. Demonstrates smart routing to sub-agents
4. Shows conversation memory across messages
5. Demonstrates per-agent HITL behavior
6. Shows session isolation

---

### 4. API Server with Factory Function (`example_api_server.py`) [Recommended]

**Purpose**: Modern way to create an API server using factory functions.

**Features**:
- ✅ One-line setup with `create_api()`
- 🚀 FastAPI server with automatic Swagger UI
- 🧠 Smart routing enabled by default
- 🔄 Hierarchical agent support
- 📡 REST API for external integrations

**Run**:
```bash
python tests/examples/example_api_server.py
```

**What it does**:
1. Initializes framework with `create_api()` factory function
2. Starts FastAPI server on http://localhost:8000
3. Provides automatic Swagger UI at http://localhost:8000/docs
4. Enables REST API endpoints for external integrations

**Test with curl**:
```bash
# List available agents
curl http://localhost:8000/agents

# Send a chat message
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "What is 2 + 2?", "thread_id": "test_001"}'
```

**Visit in browser**:
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

---

### 5. Multi-Agent Project Generator (`example_project_generator.py`)

**Purpose**: Demonstrates multi-agent system for generating complete projects.

**Features**:
- Smart routing coordination
- Automatic project structure creation
- Code file generation
- Real-world project creation
- **Quick templates** for common project types:
  - 🌐 **Web API** - Agent Framework API server with smart routing (uses `create_api()`)
  - 🌍 **Website** - Static HTML/CSS/JS website
  - 🧮 **Calculator** - Calculator application
  - ✅ **Todo App** - Todo list application
  - 🎨 **Custom** - Describe your own project

**Run**:
```bash
python tests/examples/example_project_generator.py
```

**What it does**:
1. Shows quick template options (web-api, website, calculator, todo-app, custom)
2. Uses smart routing to analyze requirements
3. Generates project plan and structure
4. Creates code files
5. Saves complete project in `generated_projects/`

**Template Examples**:
- Choose `1` or type `web-api` for an Agent Framework API server with smart routing and hierarchical agents
- Choose `2` or type `website` for a responsive HTML/CSS/JS website
- Choose `5` or type `custom` to describe your own project

**Output**: Complete working projects in `generated_projects/` folder

---

### 6. API + CLI Together (`app_with_api.py`) [Legacy]

**Purpose**: Run FastAPI server and CLI simultaneously (older pattern).

**Note**: For current API patterns, use:
```python
from main import create_api
api = create_api("agents.yaml", host="0.0.0.0", port=8000)
api.run()
```

**Features**:
- FastAPI server in background
- Interactive CLI in foreground
- Dual-mode operation
- Perfect for development/testing

**Run**:
```bash
python tests/examples/app_with_api.py
```

**What it does**:
1. Starts FastAPI server on http://localhost:8000
2. Provides interactive CLI in terminal
3. Both modes use the same framework instance
4. Access Swagger UI at http://localhost:8000/docs while chatting in CLI

---

## Quick Start

### Prerequisites

1. **PostgreSQL running**:
   ```bash
   docker-compose up -d
   ```

2. **Environment configured**:
   - Copy `.env.example` to `.env`
   - Set your LLM provider credentials
   - Configure other settings

3. **Dependencies installed**:
   ```bash
   pip install -r requirements.txt
   ```

### Run Any Example

```bash
# From project root

# Recommended: Factory function examples
python tests/examples/example_basic_usage.py      # Basic CLI usage
python tests/examples/example_cli.py              # Modern CLI pattern
python tests/examples/example_api_server.py       # Modern API pattern

# Advanced examples
python tests/examples/example_advanced.py          # Direct framework usage
python tests/examples/example_project_generator.py # Multi-agent project gen

# Legacy examples
python tests/examples/app_with_api.py             # Old API+CLI pattern
```

## Customization

All examples use configuration files:
- `.env` - LLM provider, credentials, debug settings
- `multiagent/agents.yaml` - Hierarchical agent definitions (recommended)
- `agents_config.yaml` - Flat agent definitions (legacy)
- `tools_registry.py` - Available tools

Modify these files to customize behavior!

## Debug Mode

Enable debug mode to see the agent's thought process:

**In `.env`**:
```properties
DEBUG_MODE=true
```

**Or per-agent in `multiagent/agents.yaml` or `agents_config.yaml`**:
```yaml
agents:
  - name: "main_agent"
    debug: true  # Enable for this agent only
```

## Expected Output

### Basic Usage Example
```
🚀 My Custom AI Application - Starting...
✅ Framework initialized!

📋 Available agents: main_agent, weather_agent, calculator_agent
🧠 Smart routing enabled

[Smart routing → weather_agent: "The temperature in Paris is 15°C"]
[Smart routing → calculator_agent: "The result is 56,088"]

🚀 My Custom AI Application - Shutdown complete
```

### CLI Example
```
🚀 Agent Framework CLI (Factory Function Pattern)
================================================================================

📄 Config: multiagent/agents.yaml
🧠 Smart routing: Enabled
💡 Type 'help' for available commands

You: What's the weather in London?
🤖: [Routing to weather_agent...]
The current weather in London is 12°C with partly cloudy skies.

You: Calculate 15 * 23
🤖: [Routing to calculator_agent...]
⚠️ HITL Approval Required for calculator_agent
The result is 345.
```

### API Server Example
```
🚀 Agent Framework API Server (Factory Function Pattern)
================================================================================

📄 Config: multiagent/agents.yaml
🌐 Starting API server...
📖 Swagger UI: http://localhost:8000/docs
📖 ReDoc: http://localhost:8000/redoc

INFO:     Started server process [12345]
INFO:     Uvicorn running on http://0.0.0.0:8000
```

### Project Generator Example
```
🔧 Initializing Multi-Agent Project Generator...
📄 Config: multiagent/agents.yaml

✅ Available agents: main_agent, weather_agent, calculator_agent
🧠 Smart routing enabled: Queries automatically routed to best agent

================================================================================
💡 PROJECT GENERATOR
================================================================================

📋 Quick Templates (or describe your own):
   1. web-api      - Agent Framework API server with smart routing
   2. website      - Static HTML/CSS/JS website
   3. calculator   - Calculator application
   4. todo-app     - Todo list application
   5. custom       - Describe your own project
   q. quit         - Exit

🎯 Choose (1-5 or q): 1

============================================================
🎯 REQUEST: Create a web API server using the Agent Framework...
============================================================

🧠 Processing with smart routing...
   (The main_agent will coordinate specialized agents as needed)

📊 STEP 1: Analyzing requirements and planning...
✓ Plan created (1234 chars)

💻 STEP 2: Generating code files...
✓ Code generated (5678 chars)

📝 STEP 3: Creating files...
  ✓ api_server.py
  ✓ agents.yaml
  ✓ requirements.txt
  ✓ README.md
  ✓ test_api.sh

✅ Created 5 file(s)

✅ Done! Location: generated_projects/Create-a-web-API-server
```
```
� Initializing Multi-Agent Project Generator...
📄 Config: multiagent/agents.yaml

✅ Available agents: main_agent, weather_agent, calculator_agent
🧠 Smart routing enabled: Queries automatically routed to best agent

================================================================================
💡 PROJECT GENERATOR
================================================================================

📋 Quick Templates (or describe your own):
   1. web-api      - FastAPI REST API with database
   2. website      - Static HTML/CSS/JS website
   3. calculator   - Calculator application
   4. todo-app     - Todo list application
   5. custom       - Describe your own project
   q. quit         - Exit

🎯 Choose (1-5 or q): 1

============================================================
🎯 REQUEST: Create a FastAPI REST API with CRUD endpoints...
============================================================

🧠 Processing with smart routing...
   (The main_agent will coordinate specialized agents as needed)

📊 STEP 1: Analyzing requirements and planning...
✓ Plan created (1234 chars)

💻 STEP 2: Generating code files...
✓ Code generated (5678 chars)

📝 STEP 3: Creating files...
  ✓ main.py
  ✓ models.py
  ✓ database.py
  ✓ requirements.txt
  ✓ README.md

✅ Created 5 file(s)

✅ Done! Location: generated_projects/Create-a-FastAPI-REST-API
```

## Learning Path

**Recommended order**:
1. Start with `example_basic_usage.py` - Learn the basics
2. Try `example_cli.py` - Experience modern CLI pattern with factory functions
3. Try `example_api_server.py` - Experience modern API pattern with factory functions
4. Run `example_advanced.py` - Explore direct framework usage for advanced control
5. Run `example_project_generator.py` - See multi-agent coordination
6. Experiment with `app_with_api.py` - See legacy dual-mode operation

## Troubleshooting

### "Connection refused" error
- Make sure PostgreSQL is running: `docker ps`
- Start it: `docker-compose up -d`

### "API key not found" error
- Check `.env` file has correct credentials
- Verify `LLM_PROVIDER` matches your setup

### Examples don't import main module
- Run from project root directory
- Check Python path includes project root

### No response from agents
- Check internet connection
- Verify API credentials are valid
- Enable debug mode to see what's happening

## Extending Examples

### Option 1: Use Factory Functions (Recommended)

For CLI applications:
```python
from main import create_cli

def main():
    """My custom CLI application."""
    cli = create_cli(
        agents_config_path="multiagent/agents.yaml",
        default_session_id="my_app"
    )
    cli.run()

if __name__ == "__main__":
    main()
```

For API servers:
```python
from main import create_api

def main():
    """My custom API server."""
    api = create_api(
        agents_config_path="multiagent/agents.yaml",
        host="0.0.0.0",
        port=8000
    )
    api.run()

if __name__ == "__main__":
    main()
```

### Option 2: Use AgentFramework Directly (Advanced)

For custom integrations and advanced control:
```python
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from main import AgentFramework

def my_custom_example():
    """My custom example with direct framework access."""
    framework = AgentFramework("multiagent/agents.yaml")
    framework.initialize()
    
    # Your custom logic here
    response = framework.run_conversation(
        user_message="Your message",
        session_id="my_session"
        # agent_name optional - uses smart routing by default
    )
    
    print(f"Response: {response}")
    
    framework.cleanup()

if __name__ == "__main__":
    my_custom_example()
```

Save as `tests/examples/example_custom.py` and run!

## More Information

- **Framework Documentation**: See root `README.md`
- **API Documentation**: See `API_GUIDE.md`
- **Developer Guide**: See `DEVELOPER_GUIDE.md`
- **Test Suite**: See `tests/README.md`
