"""
🚀 Multi-Agent Project Generator Example
=========================================
Demonstrates multi-agent project generation with smart routing.

Users only need 4 files:
1. example_project_generator.py (this file) - Entry point
2. agents.yaml - Agent definitions (orchestrator, planner, architect, coder)
3. tools_registry.py - Custom tools
4. .env - API keys

Commands:
    python example_project_generator.py         → CLI mode (generate projects interactively)
    python example_project_generator.py --api   → Web API server

Features:
- 🧠 Smart LLM-based routing (no hardcoded keywords)
- 🔄 Multi-agent coordination (orchestrator → planner → architect → coder)
- 📁 Automatic file generation from code blocks
- 💾 Organized output directory structure
"""

import sys
import re
import asyncio
from pathlib import Path

# Add parent directories to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from main import create_cli, create_api, AgentFramework


class ProjectGenerator:
    """
    Multi-Agent Project Generator using smart routing.
    
    The main_agent coordinates the project generation workflow,
    delegating specific tasks to specialized agents as needed.
    """
    
    def __init__(self):
        # Use local agents.yaml in examples folder
        self.config_path = Path(__file__).parent / "agents.yaml"
        
        print("🔧 Initializing Multi-Agent Project Generator...")
        print(f"📄 Config: {self.config_path}\n")
        
        self.framework = AgentFramework(str(self.config_path))
        self.output_dir = Path("generated_projects")
        self.output_dir.mkdir(exist_ok=True)
        self.initialized = False
        
    async def initialize(self):
        """Initialize the framework asynchronously."""
        if not self.initialized:
            await self.framework.initialize_async()
            self.initialized = True
            print(f"✅ Framework initialized with {len(self.framework.agents)} agents")
            print(f"🧠 Smart routing enabled\n")
    
    def cleanup(self):
        """Cleanup resources."""
        if self.framework:
            self.framework.cleanup()
    
    async def generate_project(self, request: str):
        """
        Generate project using smart routing.
        
        The framework's smart router will automatically:
        1. Understand the project requirements
        2. Coordinate multiple agents if needed
        3. Generate appropriate code structure
        """
        session = f"project_{request[:20].replace(' ', '_')}"
        
        print(f"\n{'='*60}\n🎯 REQUEST: {request}\n{'='*60}\n")
        
        # Use smart routing - let the framework decide which agents to use
        print("🧠 Processing with smart routing...")
        print("   (The main_agent will coordinate specialized agents as needed)\n")
        
        # Generate project plan and structure
        print("📊 STEP 1: Analyzing requirements and planning...")
        planning_prompt = f"""Create a project plan for: {request}

Please provide:
1. Project overview and goals
2. Required files and directory structure  
3. Technology stack and dependencies
4. Step-by-step implementation plan"""
        
        plan = await self.framework.run_conversation(
            planning_prompt, 
            f"{session}_plan",
            agent_name="orchestrator"  # Use orchestrator agent for planning
        )
        print(f"\n✓ Plan created ({len(plan)} chars)\n")
        
        # Generate code files
        print("💻 STEP 2: Generating code files...")
        code_prompt = f"""Based on this project plan:

{plan}

Generate all necessary code files in this format:
### File: `filename.ext`
```language
code content here
```

Generate complete, working code for: {request}"""
        
        code = await self.framework.run_conversation(
            code_prompt,
            f"{session}_code",
            agent_name="coder"  # Use coder agent for generating files
        )
        print(f"\n✓ Code generated ({len(code)} chars)\n")
        
        # Create files
        print("📝 STEP 3: Creating files...")
        project_path = self.output_dir / request[:30].replace(' ', '-')
        self._create_files(project_path, code)
        
        print(f"\n✅ Done! Location: {project_path.absolute()}\n")
        return project_path
    
    def _create_files(self, path: Path, response: str):
        """Parse markdown code blocks and create files."""
        path.mkdir(parents=True, exist_ok=True)
        count = 0
        
        # Find all: ### File: `filename` followed by ```code```
        pattern = r'###?\s+(?:File:\s*)?`([^`]+)`\s*\n```\w*\n(.*?)```'
        for match in re.finditer(pattern, response, re.DOTALL):
            filename, code = match.groups()
            file_path = path / filename.strip()
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_text(code.strip(), encoding='utf-8')
            print(f"  ✓ {filename}")
            count += 1
        
        if count == 0:
            print("  ⚠️ No code blocks found, creating README...")
            (path / "README.md").write_text(f"# Generated Project\n\n{response}")
            count = 1
        
        print(f"\n✅ Created {count} file(s)")
    
    async def run(self):
        """Main entry point."""
        # Initialize framework first
        await self.initialize()
        
        print("\n" + "="*80)
        print("💡 PROJECT GENERATOR")
        print("="*80)
        print("\n💭 Describe the project you want to generate:")
        print("   Examples:")
        print("   - 'Agent Framework API server with data and analysis agents'")
        print("   - 'Simple todo list website with HTML/CSS/JS'")
        print("   - 'Calculator app'")
        print("   - 'REST API for a blog'\n")
        
        request = input("🎯 ").strip()
        
        if not request or request.lower() in ['quit', 'exit', 'q']:
            print("👋 Goodbye!")
            return
        
        await self.generate_project(request)
        self.framework.cleanup()


def main():
    """Main entry point - Choose CLI or API mode."""
    
    config_path = Path(__file__).parent / "agents.yaml"
    
    # Check command line arguments
    if '--api' in sys.argv:
        # API mode - expose agents via REST API
        print("\n🌐 Starting Project Generator API Server...")
        api = create_api(agents_config_path=str(config_path))
        api.run()
    else:
        # CLI mode - interactive project generation
        generator = ProjectGenerator()
        asyncio.run(generator.run())


if __name__ == "__main__":
    main()
