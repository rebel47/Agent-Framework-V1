"""
Example Application using the AI Runtime Framework with Factory Functions
==========================================================================
This file shows how developers can use the framework without modifying main.py.

Recommended: Use factory functions (create_cli or create_api) for quick setup.

Usage:
    python example_basic_usage.py

Configuration:
    - Edit agents.yaml to add/modify agents (hierarchical structure supported)
    - Edit tools_registry.py to add custom tools
    - Edit mcp_servers.yaml to add MCP servers
    - Edit .env for credentials and settings
"""

import asyncio
from pathlib import Path
import sys

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from main import AgentFramework


async def main():
    """
    Example using direct AgentFramework class.
    For simpler setup, consider using create_cli() or create_api() factory functions.
    """
    print("\n" + "="*80)
    print("🚀 Basic Framework Usage Example")
    print("="*80 + "\n")
    
    # Step 1: Initialize the framework
    # The framework automatically loads configuration from:
    #   - agents.yaml (your agents with hierarchical structure)
    #   - tools_registry.py (your tools)
    #   - mcp_servers.yaml (your MCP servers)
    #   - .env (credentials and settings)
    
    # Use local agents.yaml in examples folder
    config_path = Path(__file__).parent / "agents.yaml"
    
    framework = AgentFramework(str(config_path))
    await framework.initialize_async()
    
    print("\n✅ Framework initialized!\n")
    print(f"📋 Available agents: {', '.join(framework.list_agents())}")
    print(f"🎯 Default agent: {framework.default_agent_name}\n")
    
    # Step 2: Use the framework with smart routing
    session_id = "example_session_001"
    
    try:
        # Example 1: Simple query (routed automatically)
        print("Example 1: Tool usage query")
        await framework.run_conversation(
            user_message="What time is it?",
            session_id=session_id
        )
        
        # Example 2: Weather query (smart routing to weather_agent if available)
        print("\nExample 2: Weather query (smart routing)")
        await framework.run_conversation(
            user_message="What's the weather like?",
            session_id=session_id
        )
        
        # Example 3: Math query (smart routing to calculator_agent if available)
        print("\nExample 3: Math query (smart routing)")
        await framework.run_conversation(
            user_message="Calculate 123 * 456",
            session_id=session_id
        )
        
        # Example 4: Use a specific agent directly
        agents = framework.list_agents()
        if "main_agent" in agents:
            print("\nExample 4: Direct main_agent usage")
            await framework.run_conversation(
                user_message="What can you help me with?",
                session_id=session_id,
                agent_name="main_agent"  # Specify which agent
            )
        
        # Example 5: Interactive chat loop (uncomment to use)
        # print("\n💬 Interactive mode (type 'exit' to quit):")
        # while True:
        #     user_input = input("\nYou: ").strip()
        #     if user_input.lower() in ['exit', 'quit', 'bye']:
        #         print("Goodbye!")
        #         break
        #     
        #     await framework.run_conversation(
        #         user_message=user_input,
        #         session_id=session_id
        #     )
        
        # Example 6: Programmatic API-style usage
        # for i, task in enumerate(["task 1", "task 2", "task 3"]):
        #     await framework.run_conversation(
        #         user_message=task,
        #         session_id=f"batch_job_{i}"
        #     )
        
    except KeyboardInterrupt:
        print("\n\n[System] Application interrupted by user")
    except Exception as e:
        print(f"\n[Error] {type(e).__name__}: {str(e)}")
        import traceback
        traceback.print_exc()
    finally:
        # Always cleanup resources
        await framework.cleanup()
    
    print("\n" + "="*80)
    print("🚀 My Custom AI Application - Shutdown complete")
    print("="*80 + "\n")


if __name__ == "__main__":
    asyncio.run(main())
