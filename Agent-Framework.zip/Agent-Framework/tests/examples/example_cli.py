"""
Modern CLI Example using Factory Functions
===========================================
This example shows the recommended way to create a CLI using create_cli().

Features:
- ✅ One-line setup with create_cli()
- 🧠 Smart routing enabled by default
- 🔄 Hierarchical agent support
- 💬 Interactive chat interface
- 📋 Command system (help, agents, stats, clear, quit)

Usage:
    python example_cli.py
    
Commands:
    help    - Show available commands
    agents  - List available agents
    stats   - Show conversation statistics
    clear   - Clear conversation history
    quit    - Exit the application
"""

import sys
from pathlib import Path

# Add parent directories to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from main import create_cli


def main():
    """
    Create and run CLI using factory function.
    This is the recommended modern approach!
    """
    print("\n" + "="*80)
    print("🚀 Agent Framework CLI (Factory Function Pattern)")
    print("="*80 + "\n")
    
    # Use local agents.yaml in examples folder
    config_path = Path(__file__).parent / "agents.yaml"
    
    print(f"📄 Config: {config_path}")
    print(f"🧠 Smart routing: Enabled")
    print(f"💡 Type 'help' for available commands\n")
    print("="*80 + "\n")
    
    # One-line setup! This is all you need.
    cli = create_cli(
        agents_config_path=str(config_path),
        default_session_id="cli_session"
    )
    
    # Run the CLI
    cli.run()


if __name__ == "__main__":
    main()
