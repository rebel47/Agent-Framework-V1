"""
Enhanced Application with CLI and FastAPI Server (Legacy Pattern)
==================================================================
This example shows how to run both CLI interactions AND a FastAPI server simultaneously.

NOTE: This is a legacy pattern. For modern approach, use:
    - create_cli() for CLI apps
    - create_api() for API servers
    - See multiagent/agents.py for current patterns

Features:
- 🚀 FastAPI server with Swagger UI (/docs)
- 💬 Interactive CLI chat
- 🔄 Both run simultaneously
- 📡 REST API for external integrations

Usage:
    python app_with_api.py
    
    Then visit: http://localhost:8000/docs

Configuration:
    Set in .env:
    - API_HOST=0.0.0.0
    - API_PORT=8000
    - API_RELOAD=false
"""

import os
import asyncio
import threading
import sys
from pathlib import Path

# Add parent directories to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from main import AgentFramework


def run_fastapi_server():
    """Run FastAPI server in a separate thread."""
    from api_server import run_api_server
    
    api_host = os.getenv("API_HOST", "0.0.0.0")
    api_port = int(os.getenv("API_PORT", "8000"))
    api_reload = os.getenv("API_RELOAD", "false").lower() == "true"
    
    print(f"\n🌐 Starting API Server on http://{api_host}:{api_port}")
    print(f"📖 Swagger UI: http://localhost:{api_port}/docs")
    print(f"📖 ReDoc: http://localhost:{api_port}/redoc\n")
    
    run_api_server(host=api_host, port=api_port, reload=api_reload)


async def run_cli_interface():
    """Run interactive CLI interface with smart routing."""
    print("\n" + "="*80)
    print("🤖 Agent Framework - CLI + API Mode (Smart Routing)")
    print("="*80 + "\n")
    
    # Use local agents.yaml in examples folder
    config_path = Path(__file__).parent / "agents.yaml"
    
    # Initialize framework for CLI
    framework = AgentFramework(str(config_path))
    await framework.initialize_async()
    
    print("\n✅ Framework initialized!\n")
    print(f"📋 Available agents: {', '.join(framework.list_agents())}")
    print(f"🎯 Default agent: {framework.default_agent_name}\n")
    print("="*80)
    print("💬 Interactive CLI Mode (type 'exit' to quit)")
    print("   Smart routing enabled - queries auto-routed to appropriate agents")
    print("="*80 + "\n")
    
    session_id = "cli_session"
    
    try:
        while True:
            user_input = input("\n🧑 You: ").strip()
            
            if user_input.lower() in ['exit', 'quit', 'bye']:
                print("\n👋 Goodbye! (API server will continue running)")
                break
            
            if not user_input:
                continue
            
            # Run conversation with smart routing
            print("\n🤖 Agent: ", end="", flush=True)
            response = await framework.run_conversation(
                user_message=user_input,
                session_id=session_id,
                # No agent_name - let smart routing decide!
            )
            
            if response:
                print(response)
            
    except KeyboardInterrupt:
        print("\n\n[System] CLI interrupted by user")
    except Exception as e:
        print(f"\n[Error] {type(e).__name__}: {str(e)}")
    finally:
        await framework.cleanup()
    
    print("\n" + "="*80)
    print("🤖 CLI Mode - Shutdown complete")
    print("="*80 + "\n")


async def main():
    """Main entry point - runs both API server and CLI."""
    
    # Start FastAPI server in background thread
    api_thread = threading.Thread(target=run_fastapi_server, daemon=True)
    api_thread.start()
    
    # Give the API server time to start
    await asyncio.sleep(2)
    
    # Run CLI interface in main thread
    await run_cli_interface()
    
    print("\n💡 Tip: API server is still running in the background!")
    print("   Press Ctrl+C again to stop everything\n")
    
    # Keep running to allow API server to continue
    try:
        while True:
            await asyncio.sleep(1)
    except KeyboardInterrupt:
        print("\n\n[System] Shutting down everything...")


if __name__ == "__main__":
    asyncio.run(main())
