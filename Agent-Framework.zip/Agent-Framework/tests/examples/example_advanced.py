"""
Advanced Example: Building a Custom AI Application with Smart Routing
======================================================================
This shows how to build complex applications using the framework.

Example: Customer Support Bot with hierarchical agents and smart routing
"""

import asyncio
import sys
from pathlib import Path

# Add parent directories to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from main import AgentFramework


class CustomerSupportBot:
    """
    Custom application built on top of the AI Runtime Framework.
    
    This bot uses smart routing to delegate to specialized agents:
    - Weather queries → weather_agent
    - Math/calculation queries → calculator_agent
    - General queries → main_agent (orchestrator)
    """
    
    def __init__(self):
        self.framework = None
        self.conversation_history = {}
    
    async def initialize(self):
        """Initialize the framework."""
        # Use local agents.yaml in examples folder
        config_path = Path(__file__).parent / "agents.yaml"
        self.framework = AgentFramework(str(config_path))
        await self.framework.initialize_async()
    
    async def cleanup(self):
        """Cleanup resources."""
        if self.framework:
            await self.framework.cleanup()
    
    async def route_query(self, customer_id: str, message: str):
        """
        Smart routing: Let the framework's LLM-based router select the right agent.
        
        The framework analyzes agent descriptions and tools to route intelligently.
        No hardcoded keywords needed!
        """
        # Let framework handle smart routing
        session_id = f"customer_{customer_id}"
        
        print(f"� Sending to framework (smart routing enabled)...")
        
        response = await self.framework.run_conversation(
            user_message=message,
            session_id=session_id
            # No agent_name - let smart routing decide!
        )
        
        # Track conversation
        if customer_id not in self.conversation_history:
            self.conversation_history[customer_id] = []
        self.conversation_history[customer_id].append({
            'message': message,
            'response_length': len(response) if response else 0
        })
        
        return response
    
    async def get_customer_stats(self, customer_id: str):
        """Get conversation statistics for a customer."""
        history = self.conversation_history.get(customer_id, [])
        return {
            'total_conversations': len(history),
            'total_response_chars': sum(h['response_length'] for h in history)
        }


async def main():
    """
    Demo of the custom customer support bot with smart routing.
    """
    print("\n" + "="*80)
    print("🎯 Customer Support Bot - Demo (Smart Routing)")
    print("="*80 + "\n")
    
    # Initialize our custom bot
    bot = CustomerSupportBot()
    await bot.initialize()
    
    try:
        # Simulate different customer queries
        customer_id = "CUST_12345"
        
        # Query 1: Weather question (routed to weather_agent)
        print("\n" + "-"*80)
        print("📞 Customer Query 1: Weather Question")
        print("-"*80)
        await bot.route_query(
            customer_id=customer_id,
            message="What's the weather like today?"
        )
        
        # Query 2: Math question (routed to calculator_agent)
        print("\n" + "-"*80)
        print("📞 Customer Query 2: Math Question")
        print("-"*80)
        await bot.route_query(
            customer_id=customer_id,
            message="What is 25% of 200?"
        )
        
        # Query 3: General question (handled by main_agent)
        print("\n" + "-"*80)
        print("📞 Customer Query 3: General Question")
        print("-"*80)
        await bot.route_query(
            customer_id=customer_id,
            message="Hello, what can you help me with?"
        )
        
        # Get customer stats
        stats = await bot.get_customer_stats(customer_id)
        print("\n" + "="*80)
        print(f"📊 Customer {customer_id} Stats:")
        print(f"   Total Conversations: {stats['total_conversations']}")
        print(f"   Total Response Characters: {stats['total_response_chars']}")
        print("="*80)
        
    except KeyboardInterrupt:
        print("\n\n[System] Interrupted by user")
    except Exception as e:
        print(f"\n[Error] {type(e).__name__}: {str(e)}")
        import traceback
        traceback.print_exc()
    finally:
        await bot.cleanup()
    
    print("\n✅ Demo complete!\n")


async def interactive_mode():
    """
    Interactive customer support bot with smart routing.
    Type queries and the framework routes them to the right agent automatically.
    """
    print("\n" + "="*80)
    print("🎯 Customer Support Bot - Interactive Mode (Smart Routing)")
    print("="*80)
    print("\nCommands:")
    print("  - Type your question (automatically routed to the right agent)")
    print("  - Type 'stats' to see conversation stats")
    print("  - Type 'agents' to see available agents")
    print("  - Type 'exit' to quit\n")
    
    bot = CustomerSupportBot()
    await bot.initialize()
    
    customer_id = input("Enter your customer ID: ").strip() or "GUEST"
    
    try:
        while True:
            message = input(f"\n[{customer_id}] You: ").strip()
            
            if message.lower() in ['exit', 'quit', 'bye']:
                print("Goodbye!")
                break
            
            if message.lower() == 'stats':
                stats = await bot.get_customer_stats(customer_id)
                print(f"\n📊 Your Stats:")
                print(f"   Conversations: {stats['total_conversations']}")
                print(f"   Response Characters: {stats['total_response_chars']}")
                continue
            
            if message.lower() == 'agents':
                agents = bot.framework.list_agents()
                print(f"\n🤖 Available Agents: {', '.join(agents)}")
                print(f"   Default: {bot.framework.default_agent_name}")
                continue
            
            if not message:
                continue
            
            await bot.route_query(customer_id, message)
    
    except KeyboardInterrupt:
        print("\n\nGoodbye!")
    finally:
        await bot.cleanup()


if __name__ == "__main__":
    import sys
    
    # Choose mode
    if len(sys.argv) > 1 and sys.argv[1] == "--interactive":
        asyncio.run(interactive_mode())
    else:
        print("[INFO] Running in demo mode.")
        print("[INFO] For interactive mode, run: python example_advanced.py --interactive\n")
        asyncio.run(main())
