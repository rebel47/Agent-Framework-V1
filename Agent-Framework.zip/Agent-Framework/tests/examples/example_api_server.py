"""
Modern API Server Example using Factory Functions
==================================================
This example shows the recommended way to create an API server using create_api().

Features:
- ✅ One-line setup with create_api()
- 🚀 FastAPI server with automatic Swagger UI
- 🧠 Smart routing enabled by default
- 🔄 Hierarchical agent support
- 📡 REST API for external integrations

Usage:
    python example_api_server.py
    
    Then visit: http://localhost:8000/docs

Test with curl:
    curl http://localhost:8000/agents
    curl -X POST http://localhost:8000/chat -H "Content-Type: application/json" \
         -d '{"message": "What is 2 + 2?", "thread_id": "test_001"}'
"""

import sys
from pathlib import Path

# Add parent directories to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from main import create_api


def main():
    """
    Create and run API server using factory function.
    This is the recommended modern approach!
    """
    print("\n" + "="*80)
    print("🚀 Agent Framework API Server (Factory Function Pattern)")
    print("="*80 + "\n")
    
    # Use local agents.yaml in examples folder
    config_path = Path(__file__).parent / "agents.yaml"
    
    print(f"📄 Config: {config_path}")
    print(f"🌐 Starting API server...")
    print(f"📖 Swagger UI: http://localhost:8000/docs")
    print(f"📖 ReDoc: http://localhost:8000/redoc")
    print("\n" + "="*80 + "\n")
    
    # One-line setup! This is all you need.
    api = create_api(
        agents_config_path=str(config_path),
        host="0.0.0.0",
        port=8000
    )
    
    # Run the server
    api.run()


if __name__ == "__main__":
    main()
