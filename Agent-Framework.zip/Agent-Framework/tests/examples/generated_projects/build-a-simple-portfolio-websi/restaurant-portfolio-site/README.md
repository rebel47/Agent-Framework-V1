# Restaurant Portfolio Website

## Project Overview
This is a simple portfolio website for a restaurant. The website showcases the restaurant's branding, menu, and contact information. It is designed to be visually appealing, user-friendly, and responsive to ensure accessibility across devices.

## Features
- **Home Page**: Introduction to the restaurant and its branding.
- **Menu Page**: Displays food items with descriptions and prices.
- **Contact Page**: Includes a contact form, location map, and social media links.
- **Responsive Design**: Optimized for mobile, tablet, and desktop users.

## Technology Stack
- HTML
- CSS
- JavaScript
- Google Fonts (Roboto)
- Font Awesome (optional)

## Directory Structure