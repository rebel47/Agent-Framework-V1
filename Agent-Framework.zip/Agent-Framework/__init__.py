"""
AI Runtime Framework
====================
A minimal, production-ready AI runtime framework built with Langgraph + Langchain.

Features:
- Dynamic multi-agent system (configure via YAML)
- PostgreSQL conversation persistence
- Human-in-the-Loop supervision
- Model Context Protocol (MCP) integration
- Azure OpenAI GPT-4o support
- Extensible tool registry

Usage:
    from main import AgentFramework
    
    framework = AgentFramework()
    await framework.initialize_async()
    await framework.run_conversation("Hello!", session_id="user_123")

Documentation:
    See README.md for complete documentation.
"""

__version__ = "1.0.0"
__author__ = "Your Name"

# Import main classes for easier access
from main import (
    AgentFramework,
    MCPContextProvider,
    HumanInTheLoopMiddleware,
)

__all__ = [
    'AgentFramework',
    'MCPContextProvider',
    'HumanInTheLoopMiddleware',
]
