"""
Tools Registry for Multi-Agent System
======================================
Defines all tools available to weather and calculator agents.

Usage in agents.yaml:
    tool_imports:
      - "multiagent.tools_registry.get_current_weather"
      - "multiagent.tools_registry.calculate_advanced"

Import the decorator from main:
    from main import tool
"""

from main import tool
from typing import Optional, List, Dict, Any
from datetime import datetime
import math
import random


# ============================================================================
# Weather Tools
# ============================================================================

@tool
def get_current_weather(location: str, units: str = "celsius") -> str:
    """
    Get the current weather for a specific location.
    
    Args:
        location: City name or location (e.g., "London", "New York", "Tokyo")
        units: Temperature units - "celsius" or "fahrenheit" (default: celsius)
    
    Returns:
        Current weather information including temperature, conditions, humidity, and wind
    
    Example:
        get_current_weather("London", "celsius")
        get_current_weather("New York", "fahrenheit")
    """
    # Simulate weather data (in production, this would call a real weather API)
    weather_conditions = ["Sunny", "Partly Cloudy", "Cloudy", "Rainy", "Stormy", "Snowy", "Foggy"]
    condition = random.choice(weather_conditions)
    
    if units.lower() == "fahrenheit":
        temp = random.randint(32, 95)
        temp_str = f"{temp}°F"
    else:
        temp = random.randint(0, 35)
        temp_str = f"{temp}°C"
    
    humidity = random.randint(30, 90)
    wind_speed = random.randint(5, 30)
    
    return f"""Current weather in {location}:
- Conditions: {condition}
- Temperature: {temp_str}
- Humidity: {humidity}%
- Wind Speed: {wind_speed} km/h
- Last Updated: {datetime.now().strftime('%Y-%m-%d %H:%M')}

Note: This is simulated weather data. In production, this would connect to a real weather API."""


@tool
def get_weather_forecast(location: str, days: int = 3) -> str:
    """
    Get weather forecast for upcoming days.
    
    Args:
        location: City name or location (e.g., "Paris", "Berlin")
        days: Number of days to forecast (1-7, default: 3)
    
    Returns:
        Multi-day weather forecast
    
    Example:
        get_weather_forecast("Paris", 5)
    """
    if days < 1:
        days = 1
    if days > 7:
        days = 7
    
    weather_conditions = ["Sunny", "Partly Cloudy", "Cloudy", "Rainy", "Stormy"]
    
    forecast = f"{days}-Day Weather Forecast for {location}:\n\n"
    
    for i in range(1, days + 1):
        condition = random.choice(weather_conditions)
        high = random.randint(15, 30)
        low = random.randint(5, 15)
        rain_chance = random.randint(0, 80)
        
        day_name = (datetime.now().replace(hour=0, minute=0, second=0, microsecond=0).timestamp() + i * 86400)
        day = datetime.fromtimestamp(day_name).strftime('%A, %B %d')
        
        forecast += f"Day {i} - {day}:\n"
        forecast += f"  Conditions: {condition}\n"
        forecast += f"  High: {high}°C, Low: {low}°C\n"
        forecast += f"  Rain Chance: {rain_chance}%\n\n"
    
    forecast += "Note: This is simulated forecast data. In production, this would connect to a real weather API."
    return forecast


@tool
def get_weather_alerts(location: str) -> str:
    """
    Get weather alerts and warnings for a location.
    
    Args:
        location: City name or location
    
    Returns:
        Active weather alerts and warnings, or "No active alerts" if none
    
    Example:
        get_weather_alerts("Miami")
    """
    # Simulate alerts (in production, would query real alert systems)
    has_alert = random.random() < 0.3  # 30% chance of having an alert
    
    if not has_alert:
        return f"No active weather alerts for {location}."
    
    alert_types = [
        "Heavy Rain Warning",
        "Strong Wind Advisory", 
        "Heat Warning",
        "Fog Advisory",
        "Storm Watch"
    ]
    
    alert = random.choice(alert_types)
    severity = random.choice(["Low", "Moderate", "High"])
    
    return f"""Weather Alert for {location}:
⚠️ {alert}
Severity: {severity}
Issued: {datetime.now().strftime('%Y-%m-%d %H:%M')}

Please take appropriate precautions and stay informed.

Note: This is simulated alert data. In production, this would connect to a real weather alert system."""


# ============================================================================
# Calculator Tools
# ============================================================================

@tool
def calculate(expression: str) -> str:
    """
    Evaluate a mathematical expression.
    
    Args:
        expression: Math expression to evaluate (e.g., "2 + 2", "15 * 8", "100 / 4")
                   Supports: +, -, *, /, **, (), sqrt, sin, cos, tan, log, etc.
    
    Returns:
        Result of the calculation
    
    Example:
        calculate("25 * 48")
        calculate("sqrt(144)")
        calculate("2 ** 8")
    """
    try:
        # Safe evaluation with math functions
        safe_dict = {
            'sqrt': math.sqrt,
            'sin': math.sin,
            'cos': math.cos,
            'tan': math.tan,
            'log': math.log,
            'log10': math.log10,
            'exp': math.exp,
            'pow': math.pow,
            'abs': abs,
            'round': round,
            'pi': math.pi,
            'e': math.e,
        }
        
        # Evaluate the expression
        result = eval(expression, {"__builtins__": {}}, safe_dict)
        
        # Format result nicely
        if isinstance(result, float):
            if result.is_integer():
                result = int(result)
            else:
                result = round(result, 6)  # Round to 6 decimal places
        
        return f"Result: {result}"
    
    except Exception as e:
        return f"Error calculating '{expression}': {str(e)}"


@tool
def convert_units(value: float, from_unit: str, to_unit: str) -> str:
    """
    Convert between different units of measurement.
    
    Args:
        value: Numeric value to convert
        from_unit: Source unit (e.g., "km", "miles", "kg", "pounds", "celsius", "fahrenheit")
        to_unit: Target unit
    
    Returns:
        Converted value with unit
    
    Supported conversions:
        Distance: km, miles, meters, feet
        Weight: kg, pounds, grams, ounces
        Temperature: celsius, fahrenheit, kelvin
    
    Example:
        convert_units(100, "km", "miles")
        convert_units(32, "fahrenheit", "celsius")
    """
    # Conversion factors
    conversions = {
        # Distance
        ('km', 'miles'): 0.621371,
        ('miles', 'km'): 1.60934,
        ('meters', 'feet'): 3.28084,
        ('feet', 'meters'): 0.3048,
        ('km', 'meters'): 1000,
        ('meters', 'km'): 0.001,
        
        # Weight
        ('kg', 'pounds'): 2.20462,
        ('pounds', 'kg'): 0.453592,
        ('grams', 'ounces'): 0.035274,
        ('ounces', 'grams'): 28.3495,
        ('kg', 'grams'): 1000,
        ('grams', 'kg'): 0.001,
    }
    
    from_unit = from_unit.lower()
    to_unit = to_unit.lower()
    
    # Temperature conversions (special case)
    if from_unit == 'celsius' and to_unit == 'fahrenheit':
        result = (value * 9/5) + 32
        return f"{value}°C = {result:.2f}°F"
    elif from_unit == 'fahrenheit' and to_unit == 'celsius':
        result = (value - 32) * 5/9
        return f"{value}°F = {result:.2f}°C"
    elif from_unit == 'celsius' and to_unit == 'kelvin':
        result = value + 273.15
        return f"{value}°C = {result:.2f}K"
    elif from_unit == 'kelvin' and to_unit == 'celsius':
        result = value - 273.15
        return f"{value}K = {result:.2f}°C"
    
    # Standard conversions
    conversion_key = (from_unit, to_unit)
    if conversion_key in conversions:
        result = value * conversions[conversion_key]
        return f"{value} {from_unit} = {result:.4f} {to_unit}"
    else:
        return f"Conversion from '{from_unit}' to '{to_unit}' not supported. Supported units: km, miles, meters, feet, kg, pounds, grams, ounces, celsius, fahrenheit, kelvin"


@tool
def calculate_percentage(value: float, percentage: float, operation: str = "of") -> str:
    """
    Calculate percentages.
    
    Args:
        value: The base value
        percentage: The percentage value
        operation: Type of calculation - "of" (percentage of value), 
                   "increase" (value + percentage), "decrease" (value - percentage)
    
    Returns:
        Calculated result with explanation
    
    Example:
        calculate_percentage(200, 15, "of")  # 15% of 200
        calculate_percentage(100, 20, "increase")  # 100 + 20%
        calculate_percentage(80, 10, "decrease")  # 80 - 10%
    """
    try:
        if operation == "of":
            result = (value * percentage) / 100
            return f"{percentage}% of {value} = {result}"
        
        elif operation == "increase":
            increase = (value * percentage) / 100
            result = value + increase
            return f"{value} + {percentage}% = {result} (increased by {increase})"
        
        elif operation == "decrease":
            decrease = (value * percentage) / 100
            result = value - decrease
            return f"{value} - {percentage}% = {result} (decreased by {decrease})"
        
        else:
            return f"Unknown operation: {operation}. Use 'of', 'increase', or 'decrease'"
    
    except Exception as e:
        return f"Error calculating percentage: {str(e)}"


@tool
def calculate_statistics(numbers: List[float]) -> str:
    """
    Calculate statistical measures for a list of numbers.
    
    Args:
        numbers: List of numbers to analyze
    
    Returns:
        Statistical summary including mean, median, mode, min, max, and standard deviation
    
    Example:
        calculate_statistics([10, 20, 30, 40, 50])
    """
    try:
        if not numbers:
            return "Error: Empty list provided"
        
        numbers = sorted(numbers)
        n = len(numbers)
        
        # Mean
        mean = sum(numbers) / n
        
        # Median
        if n % 2 == 0:
            median = (numbers[n//2 - 1] + numbers[n//2]) / 2
        else:
            median = numbers[n//2]
        
        # Min and Max
        min_val = min(numbers)
        max_val = max(numbers)
        
        # Standard Deviation
        variance = sum((x - mean) ** 2 for x in numbers) / n
        std_dev = math.sqrt(variance)
        
        # Range
        range_val = max_val - min_val
        
        return f"""Statistical Analysis:
- Count: {n}
- Mean (Average): {mean:.2f}
- Median: {median:.2f}
- Min: {min_val}
- Max: {max_val}
- Range: {range_val}
- Standard Deviation: {std_dev:.2f}
- Sum: {sum(numbers)}"""
    
    except Exception as e:
        return f"Error calculating statistics: {str(e)}"


# ============================================================================
# Utility Tool (Used by both agents)
# ============================================================================

@tool
def get_current_time() -> str:
    """
    Get the current date and time.
    
    Returns:
        Current date and time in a readable format
    
    Example:
        get_current_time()
    """
    now = datetime.now()
    return f"Current date and time: {now.strftime('%A, %B %d, %Y at %I:%M:%S %p')}"




if __name__ == "__main__":
    # Test tools
    print("Testing Weather Tools:")
    print(get_current_weather("London"))
    print("\n" + "="*60 + "\n")
    print(get_weather_forecast("Paris", 3))
    print("\n" + "="*60 + "\n")
    
    print("Testing Calculator Tools:")
    print(calculate("25 * 48"))
    print(calculate("sqrt(144)"))
    print(convert_units(100, "km", "miles"))
    print(calculate_percentage(200, 15, "of"))
    print(calculate_statistics([10, 20, 30, 40, 50]))
