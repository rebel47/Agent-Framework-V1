# Multi-Agent System - Hierarchical Smart Routing

A hierarchical multi-agent system with smart LLM-based routing. The **Main Agent** orchestrates two specialized sub-agents using intelligent routing instead of hardcoded keywords.

## 🤖 How It Works

**Hierarchical Architecture:**
```
main_agent (Orchestrator)
├── weather_agent (Weather specialist)
└── calculator_agent (Math specialist with HITL approval)
```

**Smart LLM-Based Routing:**
- 🧠 **No hardcoded keywords** - Uses LLM to analyze your request
- 🎯 **Context-aware** - Understands intent and routes to the right specialist
- 🌤️ **Weather questions** → Weather Agent (forecasts, temperature, alerts)
- 🔢 **Math questions** → Calculator Agent (calculations, conversions, statistics)
- 🛡️ **Per-Agent HITL** - Calculator agent requires approval before processing

## 🚀 Quick Start

### Prerequisites

Make sure you have:
1. Completed the main framework setup (parent directory)
2. PostgreSQL running: `docker-compose up -d` (in parent directory)
3. Azure OpenAI credentials in `.env` file

### Run Chat

```powershell
cd multiagent
python agents.py
```

That's it! Start chatting!

## 💬 Example Conversations

### Greeting (Main Agent)
```
👤 You: hi
🤖 Main Agent: Hello! I can help you with weather information or mathematical calculations.
```

### Weather Questions (Auto-routed to Weather Agent)
```
👤 You: What's the weather in New York?
🌤️ Weather Agent: [Provides current weather with temperature, conditions, etc.]

👤 You: Will it rain in London tomorrow?
🌤️ Weather Agent: [Checks forecast and provides rain prediction]

👤 You: Give me a 5-day forecast for Tokyo
🌤️ Weather Agent: [Provides multi-day forecast]
```

### Math Questions (Auto-routed to Calculator Agent with HITL)
```
👤 You: Calculate 2 + 2

⚠️  Calculator Agent requires approval
⚠️  Request: 'Calculate 2 + 2'
[HITL] Approve? (y/n): y

✅ Approved
🔢 Calculator Agent: The result is 4

👤 You: What is 15% of 250?

⚠️  Calculator Agent requires approval
⚠️  Request: 'What is 15% of 250?'
[HITL] Approve? (y/n): y

✅ Approved
🔢 Calculator Agent: 15% of 250 is 37.5
```

### Mixed Conversation (Smart Routing)
```
👤 You: What's the temperature in Paris?
🌤️ Weather Agent: [Provides Paris weather]

👤 You: Calculate 25 * 48

⚠️  Calculator Agent requires approval
[HITL] Approve? (y/n): y

✅ Approved
🔢 Calculator Agent: The result is 1,200

👤 You: Is it going to snow in Berlin?
🌤️ Weather Agent: [Checks Berlin forecast]
```

## 📖 Commands

- **Type your question** - Auto-routed by LLM to the right agent
- **`help`** - Show help information
- **`quit`** or **`exit`** - Exit the chat

## 🧠 Smart Features

### 1. LLM-Based Smart Routing
The Main Agent uses an LLM to analyze your request and route to the appropriate specialist:
- **Analyzes agent descriptions and available tools**
- **Understands context and intent** (not just keywords)
- **No hardcoded patterns** - fully flexible and extensible
- **Handles edge cases** - can route ambiguous requests intelligently

Example routing logic:
```yaml
main_agent:
  description: "Orchestrator that routes to weather or calculator specialists"
  sub_agents: [weather_agent, calculator_agent]
  
weather_agent:
  description: "Weather specialist - forecasts, current conditions, alerts"
  tools: [get_current_weather, get_weather_forecast, get_weather_alerts]
  
calculator_agent:
  description: "Math specialist - calculations, conversions, statistics"
  tools: [calculate, convert_units, calculate_percentage, calculate_statistics]
  hitl: true  # Requires approval before processing
```

### 2. Hierarchical Agent Structure
Parent agents can delegate to specialized sub-agents:
- **main_agent** (orchestrator) → routes to specialists
- **weather_agent** (sub-agent) → handles weather queries
- **calculator_agent** (sub-agent) → handles math with HITL approval

### 3. Per-Agent Human-in-the-Loop (HITL)
Each agent can have its own HITL setting:
```yaml
calculator_agent:
  hitl: true   # Requires approval before processing
  
weather_agent:
  hitl: false  # No approval needed
```

### 4. Conversation Memory
Both agents remember your conversation:
```
👤 You: Calculate 100 + 250
🔢 Calculator Agent: Result: 350

👤 You: Multiply that by 3
🔢 Calculator Agent: 350 × 3 = 1,050  [Remembers previous result!]
```

### 3. Tool Integration
Each agent has specialized tools:
- **Main Agent**: `get_current_time` (utility tool)
- **Weather Agent**: `get_current_weather`, `get_weather_forecast`, `get_weather_alerts`
- **Calculator Agent**: `calculate`, `convert_units`, `calculate_percentage`, `calculate_statistics`

### 5. Per-Agent Configuration
Each agent can be configured independently in `agents.yaml`:
```yaml
- name: calculator_agent
  description: "Math specialist"
  hitl: true           # This agent requires approval
  debug: false         # Disable LangChain debug output
  temperature: 0.3     # Lower temperature for deterministic math
  tools: [calculate, convert_units, calculate_percentage, calculate_statistics]
```

## 🛡️ Human-in-the-Loop (Per-Agent)

HITL is configured **per-agent** in `agents.yaml`, not globally:

**Configuration in agents.yaml:**
```yaml
agents:
  - name: main_agent
    hitl: false        # No approval needed for orchestration
    sub_agents: [weather_agent, calculator_agent]
  
  - name: weather_agent
    hitl: false        # No approval for weather queries
  
  - name: calculator_agent
    hitl: true         # Requires approval for calculations
```

**Example with Calculator Agent (HITL enabled):**
```
👤 You: Calculate 999 * 888

⚠️  Calculator Agent requires approval
⚠️  Request: 'Calculate 999 * 888'
[HITL] Approve? (y/n): y

✅ Approved
🔢 Calculator Agent: The result is 887,112
```

**Rejecting a request:**
```
👤 You: Calculate 999 * 888

⚠️  Calculator Agent requires approval
⚠️  Request: 'Calculate 999 * 888'
[HITL] Approve? (y/n): n

⚠️ Rejected
⚠️ Request rejected by human supervisor
```

**Use cases for per-agent HITL:**
- **Sensitive agents**: Require approval for specific agents (database, external APIs)
- **Learning mode**: See what specific agents are doing
- **Selective control**: Some agents need approval, others don't
- **Cost control**: Prevent expensive operations on specific agents

## 🔧 Customization

### Creating a Hierarchical Agent System

Edit `agents.yaml` to define parent/sub-agent relationships:

```yaml
default_agent: main_agent

agents:
  - name: main_agent
    description: "Orchestrator that routes to specialists"
    enabled: true
    temperature: 0.7
    hitl: false
    debug: false
    sub_agents: [specialist_1, specialist_2]  # Define sub-agents
    tools: [get_current_time]
    system_prompt: |
      You are an orchestrator. Route requests to appropriate specialists.
  
  - name: specialist_1
    description: "Specialist for X tasks"
    enabled: true
    temperature: 0.5
    hitl: true   # This specialist requires approval
    tools: [tool_1, tool_2]
    system_prompt: |
      You are a specialist for X tasks...
  
  - name: specialist_2
    description: "Specialist for Y tasks"
    enabled: true
    temperature: 0.5
    hitl: false  # This specialist doesn't need approval
    tools: [tool_3, tool_4]
    system_prompt: |
      You are a specialist for Y tasks...
```

### Adding New Tools

Edit `tools_registry.py`:

```python
from langchain_core.tools import tool

@tool
def your_new_tool(param: str) -> str:
    """
    Tool description - this is used by the LLM to understand when to call this tool.
    
    Args:
        param: Parameter description
    
    Returns:
        Result description
    """
    # Your implementation
    return "result"
```

Then add the tool to an agent in `agents.yaml`:
```yaml
- name: your_agent
  tools:
    - your_new_tool  # Add your tool here
```

### Using Factory Functions

The framework provides two factory functions for easy setup:

**CLI Mode:**
```python
from main import create_cli

# Create CLI interface
cli = create_cli("agents.yaml")
cli.run()
```

**API Mode:**
```python
from main import create_api

# Create API server
api = create_api("agents.yaml", host="0.0.0.0", port=8000)
api.run()
```

### Direct Framework Use (Advanced)

For more control, use the framework directly:

### Direct Framework Use (Advanced)

For more control, use the framework directly:

```python
from main import AgentFramework
import asyncio

async def main():
    framework = AgentFramework("agents.yaml")
    await framework.initialize()
    
    response = await framework.run_conversation(
        "Your message",
        session_id="session_123",
        agent_name="calculator_agent"  # Optional: specify agent
    )
    print(response)
```

## 🛠️ Tools Reference

### Weather Tools

**get_current_weather(location, units="celsius")**
- Get current weather conditions
- Example: `get_current_weather("London", "celsius")`

**get_weather_forecast(location, days=3)**
- Get multi-day forecast (1-7 days)
- Example: `get_weather_forecast("Paris", 5)`

**get_weather_alerts(location)**
- Check for weather warnings
- Example: `get_weather_alerts("Miami")`

### Calculator Tools

**calculate(expression)**
- Evaluate math expressions
- Supports: +, -, *, /, **, sqrt, sin, cos, tan, log
- Example: `calculate("sqrt(144) + 2**8")`

**convert_units(value, from_unit, to_unit)**
- Convert between units
- Distance: km, miles, meters, feet
- Weight: kg, pounds, grams, ounces
- Temperature: celsius, fahrenheit, kelvin
- Example: `convert_units(100, "km", "miles")`

**calculate_percentage(value, percentage, operation)**
- Percentage calculations
- Operations: "of", "increase", "decrease"
- Example: `calculate_percentage(200, 15, "of")`

**calculate_statistics(numbers)**
- Statistical analysis
- Returns: mean, median, min, max, std dev, range
- Example: `calculate_statistics([10, 20, 30, 40, 50])`

## 💡 Tips

1. **Smart Routing**: The LLM analyzes agent descriptions and tools to route requests
   - Write clear, descriptive agent descriptions
   - Include keywords about what the agent does
   - List relevant tools for better routing decisions

2. **Per-Agent HITL**: Configure approval requirements per agent
   ```yaml
   - name: safe_agent
     hitl: false    # No approval needed
   
   - name: sensitive_agent
     hitl: true     # Requires approval
   ```

3. **Hierarchical Design**: Use parent/sub-agent structure
   - Parent agent (orchestrator) routes to specialists
   - Sub-agents handle specific domains
   - Keeps system organized and maintainable

4. **Session Management**: Use consistent session_ids to maintain conversation history
   ```python
   session_id = "user_123"  # Same user, same session
   ```

5. **Temperature Settings**: 
   - Lower (0.0-0.3) for factual/deterministic tasks (math, data lookup)
   - Higher (0.7-1.0) for creative tasks (content generation)
   - Medium (0.4-0.6) for orchestration/routing

6. **Debug Mode**: Enable per-agent for troubleshooting
   ```yaml
   - name: problematic_agent
     debug: true    # See detailed LangChain logs
   ```

## 🐛 Troubleshooting

**Import Error**: Make sure parent directory is in Python path
```python
sys.path.insert(0, str(Path(__file__).parent.parent))
```

**PostgreSQL Connection**: Ensure Docker container is running
```powershell
docker-compose up -d
docker-compose ps  # Check status
```

**Tool Not Found**: Verify tool name in `agents.yaml` matches function name in `tools_registry.py`

**Agent Not Found**: Check agent name spelling and that `enabled: true` in `agents.yaml`

## 📚 Learn More

- Main Framework Documentation: `../README.md`
- API Guide: `../docs/API_GUIDE.md`
- Developer Guide: `../docs/DEVELOPER_GUIDE.md`
- Framework Overview: `../docs/FRAMEWORK_OVERVIEW.md`

## 🎯 Next Steps

1. ✅ Run the example: `python agents.py`
2. ✅ Try different queries to see smart routing in action
3. ✅ Edit `agents.yaml` to customize agent behavior
4. ✅ Add your own tools in `tools_registry.py`
5. ✅ Create hierarchical structures for complex systems
6. ✅ Use `create_cli()` or `create_api()` for your own projects

**Key Learning Points:**
- LLM-based routing (no hardcoded keywords)
- Hierarchical agent architecture (parent → sub-agents)
- Per-agent HITL configuration (fine-grained control)
- Factory functions for easy setup (create_cli, create_api)

Happy building! 🚀
