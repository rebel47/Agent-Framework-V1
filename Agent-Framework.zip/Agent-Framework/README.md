# 🤖 AI Agent Framework# 🤖 AI Agent Framework - Complete Guide for Everyone



> **A production-ready, extensible multi-agent AI framework** with hierarchical agent support, REST API, OpenAI compatibility, and comprehensive tooling.> **A production-ready, extensible AI agent system** that lets developers build powerful multi-agent applications with ease!



Built with **LangChain** + **LangGraph**, **Multi-LLM Support**, **PostgreSQL** (conversation memory), **FastAPI** (REST API), and full **OpenAI API compatibility** for integration with Open WebUI, TypingMind, and other OpenAI-compatible clients.Built with **LangChain v1** + **LangGraph** (agent framework), **Multi-LLM Support** (Azure OpenAI, OpenAI, Anthropic, Ollama, Local), **PostgreSQL** (memory storage), **FastAPI** (REST API + Swagger UI), and **pytest** (comprehensive testing).



---> **🆕 Now with LangChain v1!** Easy debug mode to see your AI agent's thought process. [See Migration Guide](MIGRATION_V1.md)

>

## ✨ Key Features> **🚀 FastAPI Integration!** Access your agents via REST API with automatic Swagger UI. [See API Guide](API_GUIDE.md)

>

### 🎯 Core Capabilities> **✅ Complete Test Suite!** 22+ tests covering all framework features. [See Testing Guide](tests/README.md)

- **Multi-Agent System** - Multiple specialized agents working together

- **Hierarchical Agents** - Supervisor agents can delegate to sub-agents---

- **Smart Agent Routing** - LLM-based intelligent routing between agents

- **Conversation Memory** - Persistent PostgreSQL checkpointing## 📚 Table of Contents

- **Multi-LLM Support** - Azure OpenAI, OpenAI, Anthropic, Ollama, local models

1. [What Is This?](#-what-is-this)

### 🔌 Integration & APIs2. [Key Features](#-key-features)

- **REST API** - Full FastAPI server with Swagger UI at `/docs`3. [Quick Start](#-quick-start)

- **OpenAI Compatible** - `/v1/chat/completions` endpoint for Open WebUI, TypingMind4. [Project Structure](#-project-structure)

- **Streaming Support** - Real-time response streaming5. [Understanding the Code](#-understanding-the-code---explained-for-everyone)

- **Thread Management** - Persistent conversation threads6. [How Everything Works Together](#-how-everything-works-together)

7. [Working with Agents](#-working-with-agents)

### 🛠️ Developer Experience8. [Working with Tools](#-working-with-tools)

- **YAML Configuration** - Define agents without coding9. [Testing Your Code](#-testing-your-code)

- **Per-Agent Settings** - Individual temperature, debug, HITL controls10. [REST API & Swagger UI](#-rest-api--swagger-ui)

- **Extensible Tools** - Easy-to-add custom tool system11. [Advanced Features](#-advanced-features)

- **Debug Mode** - See agent reasoning and tool calls12. [Troubleshooting](#-troubleshooting)

- **Human-in-the-Loop** - Optional approval before agent actions13. [FAQ](#-faq)

- **Comprehensive Testing** - 27+ tests covering all features

---

---

## 🎯 What Is This?

## 🚀 Quick Start

This is a **production-ready, importable AI framework** that developers can use to build sophisticated multi-agent AI applications!

### 1. Installation

### Three Ways to Use It:

```bash

# Clone the repository**1. CLI Mode** - Build interactive chat applications:

git clone <repository-url>```python

cd Agent-Framework# your_agents.py

from main import create_cli

# Install dependencies

pip install -r requirements.txtif __name__ == "__main__":

    cli = create_cli("agents.yaml")  # Your custom agents config

# Configure environment    cli.run()  # Starts interactive chat with smart routing

cp .env.example .env```

# Edit .env with your API keys

```**2. API Mode** - REST API with Swagger UI:

```python

### 2. Configure PostgreSQL# your_api.py

from main import create_api

```bash

# Start PostgreSQL with Dockerif __name__ == "__main__":

docker-compose up -d    api = create_api("agents.yaml", host="0.0.0.0", port=8000)

    api.run()  # Starts FastAPI server at http://localhost:8000/docs

# Or use existing PostgreSQL```

# Update DATABASE_URL in .env

```**3. Direct Framework Use** - For advanced customization:

```python

### 3. Run Your First Agent# your_custom_app.py

from main import AgentFramework

```bashimport asyncio

# Interactive CLI mode

python main.pyasync def main():

    framework = AgentFramework("agents.yaml")

# API mode with Swagger UI    await framework.initialize_async()

python api_server.py    response = await framework.run_conversation("Hello!", "session_1")

# Visit http://localhost:8000/docs    await framework.cleanup()



# Try the example projectsasyncio.run(main())

cd multiagent```

python agents.py  # Multi-agent with weather & calculator

```**4. Working Example** - See it in action:

```bash

---cd multiagent  # Example project with 3 agents

python agents.py  # CLI mode with smart routing

## 📁 Project Structurepython agents.py --api  # API mode with Swagger UI

```

```

Agent-Framework/### Why Use This Framework?

├── main.py                    # Core framework

├── api_server.py              # FastAPI REST API server- ✅ **Framework-first design** - Import `create_cli()` or `create_api()`, configure via YAML

├── tools_registry.py          # Built-in tools (time, calculator, weather)- ✅ **Smart agent routing** - LLM-based routing, no hardcoded keywords

├── agents_config.yaml         # Agent definitions- ✅ **Hierarchical agents** - Support parent/sub-agent structures

├── .env                       # Environment configuration- ✅ **Per-agent configuration** - Individual HITL, debug, temperature settings

│- ✅ **8+ built-in tools** - Time, calculator (4 tools), weather (3 tools), utility

├── multiagent/               # Example: Multi-agent system- ✅ **Multi-agent collaboration** - Agents work together via smart routing

│   ├── agents.yaml           # 3 agents with hierarchy- ✅ **Conversation memory** - Persisted in PostgreSQL with per-agent threads

│   ├── agents.py             # CLI + API launcher- ✅ **Debug mode** - Per-agent debug flag to see AI reasoning

│   └── tools_registry.py     # Custom tools- ✅ **Human-in-the-Loop** - Per-agent approval before processing

│- ✅ **Multi-LLM support** - Azure OpenAI, OpenAI, Anthropic, Ollama, local models

├── tms/                      # Example: TMS diagnostics system- ✅ **Production-ready** - Clean logging, proper error handling, async-first

│   ├── agents.yaml           # Supervisor + 4 sub-agents

│   ├── agents_simple.py      # CLI + API launcher### Real-World Example:

│   └── tools_registry.py     # TMS-specific tools```python

│# Working multiagent example included!

├── tests/                    # Comprehensive test suitecd multiagent

│   ├── test_framework_basic.pypython agents.py

│   ├── test_multi_agent.py

│   ├── test_conversations.py# Ask anything - smart routing picks the right agent:

│   ├── test_api.py👤 You: hi

│   └── examples/             # Example implementations🤖 [main_agent]: Hello! How can I assist you today?

│

└── docs/                     # Complete documentation👤 You: what is 2+2

    ├── HIERARCHICAL_AGENTS.md🤖 [calculator_agent]: The result is 4

    ├── API_HIERARCHICAL_UPDATES.md

    ├── OPENWEBUI_INTEGRATION.md👤 You: weather in Paris

    └── ... (more guides)🤖 [weather_agent]: The current weather in Paris is 15°C, partly cloudy...

``````



---### Hierarchical Agent Structure:

```yaml

## 🤝 Hierarchical Multi-Agent System# agents.yaml - Define parent/sub-agent relationships

agents:

### Define Supervisor → Sub-Agent Relationships  - name: main_agent

    description: "Orchestrator that delegates to specialists"

```yaml    sub_agents:

# agents.yaml      - weather_agent

agents:      - calculator_agent

  # Supervisor agent    

  - name: main_agent  - name: weather_agent

    description: "Orchestrates specialized sub-agents"    description: "Weather specialist"

    sub_agents:    tool_imports:

      - weather_agent      - "multiagent.tools_registry.get_current_weather"

      - calculator_agent      - "multiagent.tools_registry.get_weather_forecast"

    temperature: 0.5    

  - name: calculator_agent  

  # Sub-agent 1    description: "Math specialist"

  - name: weather_agent    tool_imports:

    description: "Weather information specialist"      - "multiagent.tools_registry.calculate"

    parent: main_agent      - "multiagent.tools_registry.convert_units"

    tools:    hitl: true  # Requires approval

      - get_weather_current```

      - get_weather_forecast# → Creates complete project with HTML, CSS, JS

    temperature: 0.7```



  # Sub-agent 2---

  - name: calculator_agent

    description: "Mathematical computation specialist"## ✨ Key Features

    parent: main_agent

    tools:### 🎯 Framework-First Design

      - calculator_add- **Factory Functions**: Use `create_cli()` and `create_api()` for instant setup

      - calculator_multiply- **Never Modify Core**: All customization via YAML config files

    temperature: 0.3- **Production-Ready**: Battle-tested, async-first architecture  

```- **Clean Architecture**: Framework core + user projects (like `multiagent/`)



### Automatic Delegation### 🧠 Smart Agent Routing

- **LLM-Based Selection**: Automatically picks the best agent for each query

The framework automatically:- **No Hardcoded Keywords**: Analyzes agent descriptions and available tools

- ✅ Creates `delegate_to_sub_agent` tool for supervisors- **Versatile**: Works with any agent configuration you define

- ✅ Validates delegation authority- **Example**: "2+2" → calculator_agent, "weather" → weather_agent, "hi" → main_agent

- ✅ Manages sub-sessions

- ✅ Logs hierarchy relationships### 🏗️ Hierarchical Agent Support

- **Parent/Sub-Agent Structure**: Define relationships in YAML (`sub_agents` field)

**See:** [docs/HIERARCHICAL_AGENTS.md](docs/HIERARCHICAL_AGENTS.md) for complete guide- **Flexible Routing**: Smart router handles delegation intelligently

- **Documentation**: `sub_agents` serves as metadata for architecture clarity

---- **Scalable**: Add unlimited agents, routing adapts automatically



## 🔌 REST API & OpenAI Compatibility### 🐛 Debug Mode (Per-Agent)

- **See AI's thought process**: Enable `debug: true` per agent in YAML

### Standard Endpoints- **Track tool calls**: Watch agent reasoning and tool execution

- **Per-agent control**: Debug only specific agents, not all

```bash- See **[docs/DEBUG_GUIDE.md](docs/DEBUG_GUIDE.md)** for complete guide

# List all agents

GET /agents### 📝 Professional Logging

- **Configurable log levels**: DEBUG, INFO, WARNING, ERROR, CRITICAL via `.env`

# Get agent details (includes hierarchy info)- **Multiple formats**: Standard, detailed (timestamps), JSON

GET /agents/{agent_name}- **Per-component logging**: Framework uses proper `logging.getLogger()`

- **Production-ready**: Control verbosity without code changes

# Get hierarchy tree- See **[docs/LOGGING_GUIDE.md](docs/LOGGING_GUIDE.md)** for complete guide

GET /agents/hierarchy/tree

### 🤖 Flexible Multi-Agent System

# Chat with agent- **Define your own agents** via `agents.yaml` - unlimited agents supported

POST /chat- **Example project included**: `multiagent/` with 3 agents (main, weather, calculator)

{- **Per-agent configuration**: Individual tools, temperature, HITL, debug settings

  "message": "Hello!",- **Custom system prompts**: Give each agent a unique personality/role

  "agent_name": "main_agent"  # Optional - uses default if omitted- **Smart routing**: Framework picks the right agent automatically

}- See **[docs/SYSTEM_PROMPTS.md](docs/SYSTEM_PROMPTS.md)** for prompt examples



# Stream response### 🤖 Multiple LLM Providers

POST /chat/stream- **Choose your AI**: Azure OpenAI, OpenAI, Anthropic Claude, Google Gemini, Ollama, Local HuggingFace

{- **Switch anytime**: Just change `.env` - no code changes!

  "message": "Tell me a story"- **Cost flexibility**: From enterprise APIs to free local models

}- See **[docs/LLM_PROVIDERS.md](docs/LLM_PROVIDERS.md)** for complete guide

```

### 🧠 Conversation Memory (PostgreSQL)

### OpenAI-Compatible Endpoints- **Per-agent threads**: Each agent maintains separate conversation history

- **Session-based**: Multiple users with unique `session_id` support

```bash- **Persistent**: Conversations survive restarts

# List models (agents)- **Powered by**: `langgraph-checkpoint-postgres` async checkpointer

GET /v1/models

### 🛠️ Extensible Tool System (8+ Built-in Tools)

# Chat completion (OpenAI format)**Calculator Tools (4):**

POST /v1/chat/completions- `calculate` - Math expression evaluator

{- `convert_units` - Unit conversion

  "model": "main_agent",  # Optional - uses default if omitted- `calculate_percentage` - Percentage calculations

  "messages": [- `calculate_statistics` - Statistical operations

    {"role": "user", "content": "Hello!"}

  ],**Weather Tools (3):**

  "stream": false- `get_current_weather` - Current conditions

}- `get_weather_forecast` - Future predictions

```- `get_weather_alerts` - Weather warnings



**Works with:** Open WebUI, TypingMind, LibreChat, and any OpenAI-compatible client**Utility Tools (1):**

- `get_current_time` - Date/time information

**See:** [docs/OPENWEBUI_INTEGRATION.md](docs/OPENWEBUI_INTEGRATION.md)

**Add custom tools** with explicit imports in `agents.yaml` - Clean and predictable!

---

### 👤 Human-in-the-Loop (HITL) - Per-Agent

## 🛠️ Creating Custom Tools- **Per-agent approval**: Set `hitl: true/false` for each agent in YAML

- **Simple approach**: Approval prompt before processing message

### 1. Define Your Tool- **Safety layer**: Require human approval for sensitive agents

- **Example**: Payment agent with `hitl: true`, search agent with `hitl: false`

```python```yaml

# tools_registry.pyagents:

from langchain_core.tools import tool  - name: payment_agent

    hitl: true  # Requires approval

@tool  - name: search_agent

def my_custom_tool(query: str) -> str:    hitl: false  # Autonomous

    """```

    Brief description of what your tool does.

    ### 🔌 Model Context Protocol (MCP)

    Args:- **Connect to external data sources** via MCP servers

        query: Description of the parameter- **Configure** via `mcp_servers.yaml`

    - **Multi-server support**: Framework manages multiple connections

    Returns:- **Extensible**: Stub implementation ready for your MCP integrations

        Description of what the tool returns

    """### ⚡ REST API with Swagger UI

    # Your tool logic here- **FastAPI server** with automatic documentation

    result = do_something(query)- **Swagger UI** at http://localhost:8000/docs

    return result- **5 endpoints**: health, agents list, agent details, chat, streaming chat

```- **Easy integration** with web/mobile apps

- See **[docs/API_GUIDE.md](API_GUIDE.md)** for complete API reference

### 2. Register in Agent Config

### � Comprehensive Documentation

```yaml- **README.md** (this file) - Complete user guide

# agents.yaml- **DEVELOPER_GUIDE.md** - API reference for developers

agents:- **FRAMEWORK_OVERVIEW.md** - Quick reference

  - name: my_agent- **DEBUG_GUIDE.md** - Debug mode setup

    tools:- **LOGGING_GUIDE.md** - Logging configuration

      - my_custom_tool  # Must match function name- **LLM_PROVIDERS.md** - Multi-LLM setup

```- **API_GUIDE.md** - REST API documentation

- **tests/README.md** - Testing guide

That's it! The framework handles the rest.

---

---

## 🚀 Quick Start

## 🎨 Working Examples

### Prerequisites

### Example 1: Multi-Agent System

- **Python 3.10+** installed

```bash- **Docker Desktop** running

cd multiagent- **Azure OpenAI** account with GPT-4o access (or alternative LLM provider)

python agents.py

---

# Try these:

# "What's the weather in Paris?"  → Routes to weather_agent### Setup (5 Minutes)

# "Calculate 25 * 4"              → Routes to calculator_agent

# "Hello!"                        → Handled by main_agent**Step 1: Install Dependencies**

``````powershell

pip install -r requirements.txt

### Example 2: TMS Diagnostics (Hierarchical)```



```bash**Step 2: Configure Environment**

cd tms

python agents_simple.pyCopy `.env-example` to `.env` and add your credentials:



# Try:```bash

# "Analyze bay 9 preset 9"  → tms_diagnostics delegates to analyzers# Copy the example file

# "Draft an email"          → Delegates to email_draft sub-agentcp .env-example .env

```

# Edit .env and add your API keys

### Example 3: API Mode```



```bash**Quick configuration for Azure OpenAI:**

python api_server.py```properties

# Visit http://localhost:8000/docs# Azure OpenAI Configuration

AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/

# Or from project foldersAZURE_OPENAI_API_KEY=your-api-key-here

cd multiagentAZURE_OPENAI_DEPLOYMENT_NAME=gpt-4o

python agents.py --apiAZURE_OPENAI_API_VERSION=2024-06-01

```

# PostgreSQL Configuration (Docker defaults)

---POSTGRES_URL=postgresql://langchain:langchain_password@localhost:5432/langchain_db



## 🧪 Testing# Feature Flags  

MCP_ENABLED=false     # Model Context Protocol (set true to enable)

```bashDEBUG_MODE=false      # Debug logging (set true for detailed logs)

# Run all testsLOG_LEVEL=INFO        # Logging level: DEBUG, INFO, WARNING, ERROR, CRITICAL

pytest tests/ -v

# Note: HITL is now per-agent in agents.yaml, not global

# Run specific test suite```

pytest tests/test_multi_agent.py -v

💡 **Where to find Azure credentials:**

# Run with coverage- Log into [Azure Portal](https://portal.azure.com)

pytest tests/ --cov=main --cov-report=html- Go to your Azure OpenAI resource

- Click "Keys and Endpoint"

# Results: 27 passed, 22 skipped (TMS-specific)- Copy the values

```

📖 **Need help with other LLM providers?** See [.env.README.md](.env.README.md) for complete setup guide including:

**See:** [tests/README.md](tests/README.md) for testing guide- Azure OpenAI, OpenAI, Anthropic Claude, Google Gemini, Ollama (local), HuggingFace (local)

- All configuration options explained

---- Security best practices

- Cost estimates

## ⚙️ Configuration

**Step 3: Start Database**

### Environment Variables (.env)```powershell

docker-compose up -d

```bash```

# LLM Configuration

LLM_PROVIDER=azure  # azure, openai, anthropic, ollama, localVerify it's running:

AZURE_OPENAI_ENDPOINT=https://your-instance.openai.azure.com/```powershell

AZURE_OPENAI_API_KEY=your-keydocker-compose ps

AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4o# Should show: agent-framework-postgres-1 running

```

# Database

DATABASE_URL=postgresql://user:password@localhost:5432/agentdb**Step 4: Run the Multiagent Example**



# Framework SettingsTry the included working example:

DEFAULT_AGENT_NAME=main_agent```powershell

DEFAULT_TEMPERATURE=0.7cd multiagent

LOG_LEVEL=INFOpython agents.py

```

# Human-in-the-Loop

HITL_ENABLED=falseYou should see:

HITL_REQUIRE_APPROVAL=true```

======================================================================

# Debug🤖 AgentFramework - Smart Multi-Agent Chat

DEBUG_ENABLED=false  # Global debug (can be overridden per-agent)======================================================================

```

Initializing...

### Agent Configuration (agents.yaml)INFO - main.MCPContextProvider - Initialized (enabled=False, servers=0)

INFO - main.HumanInTheLoopMiddleware - Initialized (require_approval=True)

```yamlINFO - main.AgentFramework - LLM Provider: azure

agents:INFO - main.AgentFramework - Loaded 3 agent configurations

  - name: agent_nameINFO - main.AgentFramework - Loaded 8 tools from registry

    description: "Brief description"INFO - main.AgentFramework - Initializing PostgreSQL checkpointer...

    system_prompt: "Your custom personality..."INFO - main.AgentFramework - ✓ PostgreSQL checkpointer ready

    INFO - main.AgentFramework - Creating 3 agent(s)...

    # Hierarchy (optional)INFO - main.AgentFramework - ✓ Created 'main_agent' with 1 tools

    sub_agents:          # For supervisorsINFO - main.AgentFramework - ✓ Created 'weather_agent' with 4 tools

      - sub_agent_1INFO - main.AgentFramework - ✓ Created 'calculator_agent' with 4 tools [HITL ENABLED]

      - sub_agent_2INFO - main.AgentFramework - ✓ Default agent: main_agent

    parent: supervisor   # For sub-agents

    ✅ Ready! Loaded 3 agent(s): main_agent, weather_agent, calculator_agent

    # Tools======================================================================

    tools:

      - tool_name_1💬 Chat - Ask me anything! (type 'quit' to exit, 'help' for commands)

      - tool_name_2

    👤 You: what is 2+2

    # Settings# Smart router selects calculator_agent automatically!

    temperature: 0.7     # LLM creativity (0.0-2.0)# If calculator_agent has hitl: true, you'll see approval prompt

    debug: false         # Per-agent debug mode🤖 [calculator_agent]: The result is 4

    hitl: false          # Per-agent human approval

    enabled: true        # Enable/disable agent👤 You: weather in London

```# Smart router selects weather_agent automatically!

🤖 [weather_agent]: The current weather in London is...

---```



## 📚 Documentation**Test Smart Routing:**

```bash

### Core Guides👤 You: hi

- **[HIERARCHICAL_AGENTS.md](docs/HIERARCHICAL_AGENTS.md)** - Complete hierarchical agent guide🤖 [main_agent]: Hello! How can I assist you today?

- **[API_HIERARCHICAL_UPDATES.md](docs/API_HIERARCHICAL_UPDATES.md)** - API hierarchy features

- **[OPENWEBUI_INTEGRATION.md](docs/OPENWEBUI_INTEGRATION.md)** - Open WebUI setup👤 You: what is 50 + 25

- **[DEVELOPER_GUIDE.md](docs/DEVELOPER_GUIDE.md)** - Advanced development🤖 [calculator_agent]: The result is 75

- **[LLM_PROVIDERS.md](docs/LLM_PROVIDERS.md)** - Multi-LLM configuration

👤 You: weather in Paris  

### Reference🤖 [weather_agent]: The current weather in Paris is 15°C...

- **[API_GUIDE.md](docs/API_GUIDE.md)** - REST API reference```

- **[DEBUG_GUIDE.md](docs/DEBUG_GUIDE.md)** - Debug mode usage

- **[LOGGING_GUIDE.md](docs/LOGGING_GUIDE.md)** - Logging configuration---

- **[SYSTEM_PROMPTS.md](docs/SYSTEM_PROMPTS.md)** - Agent personality examples

### Quick Examples

---

**Example 1: CLI Mode (Recommended)**

## 🔧 Advanced Features```python

# your_app.py - Simple CLI chat application

### 1. Per-Agent Debug Modefrom main import create_cli



```yamlif __name__ == "__main__":

agents:    cli = create_cli("agents.yaml")  # Your custom config

  - name: my_agent    cli.run()  # Starts interactive chat with smart routing

    debug: true  # See this agent's reasoning```

```

**Example 2: API Mode (Recommended)**

### 2. Human-in-the-Loop```python

# your_api.py - REST API server

```yamlfrom main import create_api

agents:

  - name: sensitive_agentif __name__ == "__main__":

    hitl: true  # Require approval before actions    api = create_api("agents.yaml", host="0.0.0.0", port=8000)

```    api.run()  # Starts FastAPI server with Swagger UI

```

### 3. Multi-LLM Support

**Example 3: Direct Framework Use**

```bash```python

# Use different providers# advanced_usage.py - Custom integration

LLM_PROVIDER=anthropicimport asyncio

ANTHROPIC_API_KEY=your-keyfrom main import AgentFramework



# Or local modelsasync def main():

LLM_PROVIDER=ollama    # Initialize framework

OLLAMA_BASE_URL=http://localhost:11434    framework = AgentFramework("agents.yaml")

OLLAMA_MODEL=llama2    await framework.initialize_async()

```    

    # Simple conversation

### 4. Custom System Prompts    response = await framework.run_conversation(

        "What time is it?",

```yaml        session_id="user_123"

agents:    )

  - name: shakespeare    

    system_prompt: |    # Use specific agent

      You are William Shakespeare. Respond in poetic verse    response = await framework.run_conversation(

      with eloquent Elizabethan English. Be creative and        "Calculate 25 * 48",

      theatrical in all responses.        session_id="user_123",

```        agent_name="calculator_agent"

    )

---    

    # Memory test - agent remembers previous messages

## 🎯 Use Cases    response = await framework.run_conversation(

        "What did I just ask you?",

### ✅ Customer Support System        session_id="user_123"

- Supervisor routes to: sales, technical, billing agents    )

- Each sub-agent has specialized knowledge    

- Escalation handled via hierarchy    await framework.cleanup()



### ✅ Research Assistantif __name__ == "__main__":

- Coordinator delegates to: search, analyze, summarize agents    asyncio.run(main())

- Multi-step research workflows```

- Parallel information gathering

**Example 2: Multi-Agent System**

### ✅ Data Analysis Pipeline```python

- Orchestrator manages: collector, analyzer, visualizer agents# tests/examples/example_advanced.py

- Sequential processing with validation# Run orchestrator + planner + architect + coder for project generation

- Error handling at each stagepython tests/examples/example_project_generator.py

```

### ✅ Content Creation

- Editor delegates to: writer, reviewer, formatter agents**Example 3: REST API Server**

- Quality control through sub-agent review```powershell

- Version tracking and iteration# Start FastAPI server

python api_server.py

---

# Visit Swagger UI

## 🐛 Troubleshooting# http://localhost:8000/docs

```

### Issue: Agent not responding

```bash**Example 4: CLI + API Together**

# Check logs```powershell

tail -f logs/agent_framework.log# Run both CLI and API server simultaneously

python tests/examples/app_with_api.py

# Enable debug mode```

DEBUG_ENABLED=true

# Or per-agent: debug: true in agents.yaml---

```

### Run Tests

### Issue: Database connection failed

```bash```powershell

# Verify PostgreSQL is running# Run all tests (22+ tests)

docker-compose pspytest tests/ -v



# Check connection# Run specific test categories

psql postgresql://user:password@localhost:5432/agentdbpytest tests/test_framework_basic.py -v    # Framework initialization tests

pytest tests/test_tools.py -v              # Tool registry tests

# Reset databasepytest tests/test_conversations.py -v      # Conversation & memory tests

docker-compose down -vpytest tests/test_multi_agent.py -v        # Multi-agent collaboration tests

docker-compose up -d

```# Run with coverage

pytest tests/ --cov=. --cov-report=html

### Issue: OpenAI API errors```

```bash

# Verify API keysSee **[tests/README.md](tests/README.md)** for complete testing guide.

echo $AZURE_OPENAI_API_KEY

---

# Check endpoint

curl $AZURE_OPENAI_ENDPOINT/openai/deployments?api-version=2023-05-15## 📁 Project Structure



# Test with simple request```

pytest tests/test_framework_basic.py -vAgent-Framework/

```│

├── 🔷 FRAMEWORK CORE (Import from here - Don't modify!)

### Issue: Tools not working│   ├── main.py                          # Core framework - AgentFramework class

```bash│   ├── api_server.py                    # FastAPI REST API server

# Verify tool is imported│   ├── tools_registry.py                # Tool definitions (add your tools here)

python -c "from tools_registry import tool_name; print('OK')"│   └── __init__.py                      # Package initialization

│

# Check tool name matches in agents.yaml├── ⚙️ CONFIGURATION (Customize these!)

# Tool name must exactly match function name│   ├── agents_config.yaml               # Define agents (6 pre-configured)

```│   ├── mcp_servers.yaml                 # Configure MCP servers

│   ├── .env                             # Your credentials & settings

---│   └── .env.example                     # Template for .env file

│

## 🚀 What's New├── ✅ TESTS & EXAMPLES

│   ├── tests/                           # Test suite (pytest)

### Version 2.1 (November 2025)│   │   ├── conftest.py                  # Pytest fixtures

- ✅ Hierarchical multi-agent system with supervisor/sub-agent relationships│   │   ├── test_framework_basic.py      # Framework initialization tests (7 tests)

- ✅ OpenAI-compatible API endpoints (`/v1/chat/completions`, `/v1/models`)│   │   ├── test_conversations.py        # Conversation & memory tests (6 tests)

- ✅ Open WebUI, TypingMind, LibreChat integration│   │   ├── test_tools.py                # Tool registry tests (4 tests)

- ✅ Agent hierarchy API endpoints (`/agents/hierarchy/tree`)│   │   ├── test_multi_agent.py          # Multi-agent collaboration tests (5 tests)

- ✅ Dynamic Swagger UI examples with actual agent names│   │   ├── test_api.py                  # API endpoint tests

- ✅ Enhanced API models with `sub_agents`, `parent`, `role` fields│   │   ├── test_v1_migration.py         # LangChain v1 migration tests

- ✅ Automatic delegation tool creation for supervisors│   │   ├── README.md                    # Complete testing guide

- ✅ Authority validation for delegations│   │   ├── TEST_SUMMARY.md              # Test structure summary

- ✅ Comprehensive hierarchical agent documentation│   │   ├── QUICK_COMMANDS.md            # Quick pytest commands

│   │   └── examples/                    # Example applications

### Version 2.0 (November 2025)│   │       ├── example_basic_usage.py   # Basic framework usage

- ✅ LangChain v1 + LangGraph migration│   │       ├── example_advanced.py      # Multi-agent customer support

- ✅ FastAPI REST API with Swagger UI│   │       ├── example_project_generator.py  # 4-agent project generation

- ✅ Comprehensive test suite (27+ tests)│   │       ├── app_with_api.py          # CLI + API server together

- ✅ Per-agent debug and HITL settings│   │       └── README.md                # Examples documentation

- ✅ Multi-LLM support (6 providers)│   └── pytest.ini                       # Pytest configuration

- ✅ PostgreSQL conversation memory│

- ✅ Complete documentation overhaul├── 📚 DOCUMENTATION (Learn from these!)

│   ├── README.md                        # This file (complete user guide)

---│   └── docs/                            # All documentation

│       ├── README.md                    # Documentation index

## 📊 Framework Statistics│       ├── API_GUIDE.md                 # REST API documentation

│       ├── DEBUG_GUIDE.md               # Debug mode setup

- **Agents**: Unlimited (YAML-configured)│       ├── DEVELOPER_GUIDE.md           # API reference for developers

- **Built-in Tools**: 8+ (time, calculator, weather, file, utility)│       ├── LOGGING_GUIDE.md             # Logging configuration

- **Test Coverage**: 27 tests passing│       ├── LLM_PROVIDERS.md             # Multi-LLM setup guide

- **LLM Providers**: 6 (Azure OpenAI, OpenAI, Anthropic, Ollama, Local, HuggingFace)│       ├── CONFIGURATION.md             # Configuration reference

- **API Endpoints**: 10+ (REST + OpenAI-compatible)│       ├── EXTENSIBILITY.md             # Extensibility guide

- **Documentation**: 15+ comprehensive guides│       ├── FRAMEWORK_OVERVIEW.md        # Quick reference cheatsheet

│       ├── MIGRATION_V1.md              # LangChain v1 migration

---│       ├── SYSTEM_PROMPTS.md            # Agent personality examples

│       ├── EXAMPLE_PROJECT_GENERATOR.md # Multi-agent example guide

## 🤝 Contributing│       ├── reference/                   # Official LangChain/LangGraph docs

│       │   ├── langchain.md             # LangChain v1 reference

This is a thesis project. Contributions, bug reports, and feature requests are welcome:│       │   └── langgraph.md             # LangGraph v1 reference

│       └── archive/                     # Design docs & future features

1. **Bug Reports**: Include steps to reproduce with error logs│           └── PIPELINE_DESIGN.md       # Pipeline feature design

2. **Feature Requests**: Describe use case and desired behavior│

3. **Pull Requests**: Follow existing code style, add tests, update docs├── 🐳 INFRASTRUCTURE

│   ├── docker-compose.yml               # PostgreSQL database setup

---│   ├── requirements.txt                 # Python dependencies

│   └── req.txt                          # Additional requirements

## 📜 License│

└── 📦 GENERATED OUTPUT

See LICENSE file. This is an educational/research project.    └── generated_projects/              # Output from project generator

        ├── build-a-basic/

---        └── make-calculator-app/

```

## 🙏 Acknowledgments

### Key Files Explained:

Built with:

- **LangChain & LangGraph** - Agent framework| File | Purpose | When to Edit |

- **FastAPI** - REST API server|------|---------|--------------|

- **PostgreSQL** - Conversation persistence| **main.py** | Framework core (699 lines) | Never - import from it |

- **Azure OpenAI** - Primary LLM provider| **api_server.py** | FastAPI REST API (464 lines) | Never - configure via .env |

- **Docker** - Database containerization| **tools_registry.py** | Tool definitions (9 tools) | ✅ Add custom tools here |

| **agents_config.yaml** | Agent configurations (6 agents) | ✅ Add/configure agents |

---| **.env** | Credentials & settings | ✅ Your API keys & flags |

| **tests/** | Test suite (22+ tests) | ✅ Add tests for your features |

**Built with ❤️ for advanced multi-agent AI applications**| **tests/examples/** | Example apps (4 examples) | ✅ Learn from these |



*Last updated: November 5, 2025*  ### Documentation Structure:

*Version: 2.1 - Hierarchical Agents + OpenAI Compatibility*

| Category | Files | Audience |
|----------|-------|----------|
| **Getting Started** | README.md, docs/FRAMEWORK_OVERVIEW.md | Everyone |
| **Development** | docs/DEVELOPER_GUIDE.md, docs/EXTENSIBILITY.md | Developers |
| **Configuration** | docs/CONFIGURATION.md, docs/LLM_PROVIDERS.md | System admins |
| **Features** | docs/DEBUG_GUIDE.md, docs/LOGGING_GUIDE.md, docs/API_GUIDE.md | Feature users |
| **Migration** | docs/MIGRATION_V1.md | Upgraders |
| **Testing** | tests/README.md, tests/TEST_SUMMARY.md | QA engineers |
| **Reference** | docs/reference/ | LangChain/LangGraph docs |

**📖 Complete documentation index:** See [docs/README.md](docs/README.md)

---

## 📖 Understanding the Code - Explained for Everyone

Let's understand what each file does and how they work together.

### 🗂️ Project Structure

```
Your Folder/
│
├── 📄 main.py                  # The brain - orchestrates everything
├── 📄 tools_registry.py        # The toolbox - defines what agents can do
├── 📄 agents_config.yaml       # Agent directory - who your agents are
├── 📄 mcp_servers.yaml         # External connections - what systems to connect
├── 📄 .env                     # Secrets & settings - your API keys
├── 📄 docker-compose.yml       # Database setup - memory system
├── 📄 requirements.txt         # Shopping list - what libraries to install
└── 📄 README.md               # This guide!
```

---

### 📄 File 1: `main.py` - The Orchestrator

**What it does:** This is the "conductor" that coordinates everything.

#### **Main Components:**

#### 1️⃣ **MCPContextProvider Class**
```python
class MCPContextProvider:
    """Connects to external systems like files, databases, APIs"""
```

**What it does:**
- Reads `mcp_servers.yaml` to find which external systems to connect to
- When an agent needs information, it asks all MCP servers
- Returns combined context from all sources

**Example:**
```python
# When you enable MCP and ask: "What files are in my project?"
# MCPContextProvider queries the filesystem MCP server
# Returns: "Files: main.py, tools_registry.py, agents_config.yaml..."
```

**Current Status:** ⚠️ **Stub Implementation** (placeholder)
- Right now, it just returns `[MCP Context for: your_query]`
- To make it work: Replace the `get_context()` method with actual MCP client code
- See [MCP Setup Section](#-setting-up-mcp-servers---step-by-step) for details

---

#### 2️⃣ **HumanInTheLoopMiddleware Class**
```python
class HumanInTheLoopMiddleware:
    """Asks for your approval before the agent does anything"""
```

**What it does:**
- Before the agent takes any action, it asks: "Should I proceed?"
- You type 'y' (yes) or 'n' (no)
- If you say no, the agent stops

**Example:**
```
[HITL] Agent wants to: Process message: 'Calculate 5 * 5'
[HITL] Using tool: Agent: general_assistant
[HITL] Approve? (y/n): y
[HITL] Decision: APPROVED
```

**How to disable it:**
- Open `.env` file
- Change `HITL_ENABLED=true` to `HITL_ENABLED=false`
- Restart the program

---

#### 3️⃣ **AgentFramework Class** (The Main Class)

This is the heart of the system. Let's break down what it does:

```python
class AgentFramework:
    """Main framework that creates and manages all agents"""
    
    def __init__(self, agents_config_path="agents_config.yaml"):
        # Loads settings from .env file
        self.azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
        self.azure_api_key = os.getenv("AZURE_OPENAI_API_KEY")
        
        # Initialize components
        self.mcp = MCPContextProvider()        # External connections
        self.hitl = HumanInTheLoopMiddleware() # Human approval system
        
        # Load agent configurations
        self.agent_configs = self._load_agent_configs(agents_config_path)
        
        # Storage for all created agents
        self.agents = {}  # Will hold: {'general_assistant': agent_object, ...}
        
        # Load all available tools
        self.all_tools = get_all_tools()  # From tools_registry.py
```

**Key Methods Explained:**

**a) `_load_agent_configs()`**
```python
def _load_agent_configs(self, config_path):
    """Reads agents_config.yaml and returns list of agents to create"""
```
- Opens `agents_config.yaml`
- Reads all agent definitions
- Filters to only enabled agents
- Returns a list like:
  ```python
  [
    {'name': 'general_assistant', 'tools': ['get_current_time', 'calculate'], ...},
    {'name': 'code_reviewer', 'tools': ['analyze_code'], ...}
  ]
  ```

**b) `_initialize_llm(temperature)`**
```python
def _initialize_llm(self, temperature=0.7):
    """Creates a connection to Azure OpenAI GPT-4o"""
```
- Creates an AI model instance with specific settings
- **Temperature** controls creativity:
  - `0.0-0.3` = Very focused, precise (good for coding, math)
  - `0.5-0.7` = Balanced (good for general conversation)
  - `0.8-1.0` = Very creative (good for writing, brainstorming)

**c) `initialize_async()`**
```python
async def initialize_async(self):
    """Sets up database and creates all agents"""
```
- Connects to PostgreSQL database
- Creates database tables for storing conversations
- For each agent in config:
  1. Creates an LLM instance with its temperature
  2. Gets its specific tools from tools_registry
  3. Creates a Langgraph agent with those tools
  4. Stores it in `self.agents` dictionary

**d) `get_agent(agent_name)`**
```python
def get_agent(self, agent_name=None):
    """Retrieves a specific agent by name"""
```
- If no name given, returns the default agent
- Otherwise, looks up agent in `self.agents` dictionary
- Returns: `{'agent': agent_object, 'config': {...}, 'tools': [...]}`

**e) `run_conversation()`**
```python
async def run_conversation(self, user_message, session_id="default", agent_name=None):
    """Processes one message and returns agent's response"""
```

**Step-by-step what happens:**

1. **Get the right agent**
   ```python
   agent_data = self.get_agent(agent_name)  # Get agent by name or default
   agent = agent_data['agent']
   ```

2. **Get MCP context** (if enabled)
   ```python
   mcp_context = await self.mcp.get_context(user_message)
   # Queries external systems for relevant information
   ```

3. **Ask for human approval** (if HITL enabled)
   ```python
   if not await self.hitl.should_proceed(...):
       return  # Stop if human says no
   ```

4. **Prepare conversation config**
   ```python
   config = {
       "configurable": {
           "thread_id": f"{session_id}_{agent_name}"
       }
   }
   ```
   - `thread_id` is like a conversation room ID
   - Agent remembers all messages in the same thread
   - Different sessions = different memory threads

5. **Stream agent response**
   ```python
   async for event in agent.astream_events(...):
       # Prints agent's response word-by-word as it thinks
   ```

6. **Save to database**
   - Automatically handled by Langgraph's checkpointer
   - All messages saved to PostgreSQL
   - Agent can recall them in future turns

**f) `list_agents()`**
```python
def list_agents(self):
    """Returns names of all available agents"""
```
- Returns: `['general_assistant', 'code_reviewer', ...]`

---

### 📄 File 2: `tools_registry.py` - The Toolbox

**What it does:** Defines "tools" (special abilities) that agents can use.

#### **How It Works:**

```python
from langchain_core.tools import tool

@tool
def get_current_time() -> str:
    """Get the current time."""
    from datetime import datetime
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
```

**Breaking it down:**
- `@tool` = Decorator that tells the system "this is a tool"
- Function name = Tool name (used in config)
- Docstring ("""...""") = Description the AI reads to understand what the tool does
- Return value = Must be a string (what the AI receives)

**Current Tools:**

1. **`get_current_time()`** - Returns current date and time
   ```python
   @tool
   def get_current_time() -> str:
       """Get the current time."""
       return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
   ```

2. **`calculate(expression)`** - Evaluates math expressions
   ```python
   @tool
   def calculate(expression: str) -> str:
       """Evaluate a mathematical expression. Example: '2 + 2'"""
       result = eval(expression, {"__builtins__": {}}, {})
       return str(result)
   ```

3. **`get_weather(city)`** - Weather lookup (placeholder)
   ```python
   @tool
   def get_weather(city: str) -> str:
       """Get weather information for a city."""
       # TODO: Add real weather API
       return f"Weather for {city}: Sunny, 72°F (Placeholder)"
   ```

4. **`search_documentation(query)`** - Doc search (placeholder)
   ```python
   @tool
   def search_documentation(query: str) -> str:
       """Search technical documentation."""
       # TODO: Add real doc search
       return f"Documentation results for '{query}': [Placeholder]"
   ```

5. **`send_notification(message, recipient)`** - Notifications (placeholder)
   ```python
   @tool
   def send_notification(message: str, recipient: str = "admin") -> str:
       """Send a notification message."""
       # TODO: Add real notification service
       return f"Notification sent to {recipient}: {message}"
   ```

#### **Explicit Tool Loading:**

```python
# agents.yaml - No magic, just explicit imports
agents:
  - name: my_agent
    tool_imports:
      - "tools_registry.get_current_time"
      - "tools_registry.calculate"
      - "my_custom_tools.my_function"
```

**You don't need to register tools manually!** Just add `@tool` and they're automatically discovered.

---

### 📄 File 3: `agents_config.yaml` - Agent Directory

**What it does:** Defines which agents exist and their personalities.

```yaml
agents:
  # Agent 1: General purpose assistant
  - name: "general_assistant"
    description: "General purpose AI assistant"
    tools:
      - "get_current_time"
      - "calculate"
    enabled: true
    temperature: 0.7
  
  # Agent 2: Code analyzer (currently disabled)
  - name: "code_analyzer"
    description: "Specialized agent for code analysis and review"
    tools:
      - "get_current_time"
    enabled: false
    temperature: 0.3
  
  # Agent 3: Researcher
  - name: "researcher"
    description: "Agent for research and information gathering"
    tools:
      - "get_current_time"
    enabled: false
    temperature: 0.5

default_agent: "general_assistant"
```

**Field Explanations:**

- **`name`** - Unique identifier for the agent (use in code to select it)
- **`description`** - What this agent does (shown when running)
- **`tools`** - List of tool names this agent can use (must match tool function names)
- **`enabled`** - `true` = create this agent, `false` = skip it
- **`temperature`** - Creativity level (0.0 = robotic, 1.0 = very creative)
- **`default_agent`** - Which agent to use when you don't specify one

---

### 📄 File 4: `mcp_servers.yaml` - External Connections

**What it does:** Configures connections to external systems via MCP (Model Context Protocol).

```yaml
mcp_servers:
  # Example: File system access
  - name: "filesystem"
    type: "stdio"
    command: "mcp-server-filesystem"
    args:
      - "/path/to/allowed/directory"
    enabled: false
    description: "Provides file system access to agents"
  
  # Example: Database access
  - name: "database"
    type: "stdio"
    command: "mcp-server-postgres"
    args:
      - "postgresql://user:pass@localhost/db"
    enabled: false
    description: "Provides database query capabilities"
  
  # Example: Web search
  - name: "web_search"
    type: "http"
    url: "http://localhost:8080/mcp"
    enabled: false
    description: "Provides web search capabilities"

settings:
  timeout: 30
  max_retries: 3
  cache_responses: true
```

**Field Explanations:**

- **`name`** - Identifier for this MCP server
- **`type`** - How to connect (`stdio` = run a program, `http` = web API)
- **`command`** - Program to run for stdio type
- **`args`** - Arguments to pass to the command
- **`enabled`** - `true` = connect to this server, `false` = ignore it
- **`description`** - What this MCP server provides

**Current Status:** ⚠️ Configuration exists but needs implementation (see [MCP Setup](#-setting-up-mcp-servers---step-by-step))

---

### 📄 File 5: `.env` - Secrets & Settings

**What it does:** Stores sensitive information and feature toggles.

```env
# Azure OpenAI Configuration
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_API_KEY=your-secret-key
AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4o
AZURE_OPENAI_API_VERSION=2024-02-15-preview

# PostgreSQL Configuration
POSTGRES_URL=postgresql://langchain:langchain_password@localhost:5432/langchain_db

# Database credentials (for Docker)
POSTGRES_USER=langchain
POSTGRES_PASSWORD=langchain_password
POSTGRES_DB=langchain_db

# Feature Flags
HITL_ENABLED=true   # Require human approval?
MCP_ENABLED=false   # Use MCP servers?
```

**⚠️ IMPORTANT:** Never share this file publicly - it contains your secret API keys!

---

### 📄 File 6: `docker-compose.yml` - Database Setup

**What it does:** Configures and runs PostgreSQL database in Docker.

```yaml
services:
  postgres:
    image: postgres:16-alpine  # PostgreSQL version
    ports:
      - "5432:5432"            # Expose on port 5432
    environment:
      POSTGRES_USER: langchain
      POSTGRES_PASSWORD: langchain_password
      POSTGRES_DB: langchain_db
    volumes:
      - postgres_data:/var/lib/postgresql/data  # Persist data
```

**What gets stored:**
- All conversation messages
- Agent checkpoints (state)
- Session histories

**Commands:**
```powershell
docker-compose up -d      # Start database
docker-compose down       # Stop database
docker-compose down -v    # Stop and delete all data (reset)
docker-compose logs -f    # View database logs
```

---

## 🔄 How Everything Works Together

Let's trace a complete example: **"What time is it?"**

### The Journey of a Message:

```
1. You run: python main.py
   └─> main.py starts

2. main() function executes:
   └─> Creates AgentFramework()
       ├─> Loads .env settings (Azure keys, etc.)
       ├─> Creates MCPContextProvider (reads mcp_servers.yaml)
       ├─> Creates HumanInTheLoopMiddleware (reads HITL_ENABLED)
       ├─> Loads tools from tools_registry.py (get_current_time, calculate, etc.)
       └─> Loads agent configs from agents_config.yaml

3. initialize_async() runs:
   └─> Connects to PostgreSQL (docker-compose)
   └─> Creates agents:
       ├─> Reads agent config: {'name': 'general_assistant', 'tools': ['get_current_time', 'calculate'], ...}
       ├─> Creates Azure OpenAI connection (GPT-4o)
       ├─> Gets tools: [get_current_time, calculate]
       └─> Creates Langgraph agent with these tools
       └─> Stores in self.agents = {'general_assistant': agent_object}

4. run_conversation("What time is it?", session_id="user_123") called:
   
   Step 4a: Get agent
   └─> agent_data = self.get_agent(None)  # Uses default
   └─> Gets 'general_assistant' agent

   Step 4b: Get MCP context
   └─> mcp_context = await self.mcp.get_context("What time is it?")
   └─> Returns empty (MCP_ENABLED=false)

   Step 4c: Human approval (HITL)
   └─> Prints: "[HITL] Agent wants to: Process message: 'What time is it?'"
   └─> You type: y
   └─> Approved ✓

   Step 4d: Prepare config
   └─> thread_id = "user_123_general_assistant"
   └─> This is the "memory key" for this conversation

   Step 4e: Agent processes
   └─> Azure GPT-4o receives:
       ├─> User message: "What time is it?"
       ├─> Available tools: [get_current_time, calculate]
       ├─> Previous messages from thread "user_123_general_assistant" (if any)
   
   └─> Agent thinks: "I need to use the get_current_time tool"
   
   └─> Agent calls: get_current_time()
       └─> Returns: "2025-10-15 14:30:45"
   
   └─> Agent responds: "The current time is 2:30 PM on October 15, 2025"

   Step 4f: Save to database
   └─> PostgreSQL stores:
       ├─> User message: "What time is it?"
       ├─> Agent response: "The current time is..."
       ├─> Tool call: get_current_time()
       └─> Thread ID: "user_123_general_assistant"

5. Response printed to your terminal!

6. Next message in same session:
   └─> run_conversation("What did I just ask?", session_id="user_123")
   └─> Agent loads thread "user_123_general_assistant" from database
   └─> Sees previous message: "What time is it?"
   └─> Responds: "You asked me what time it was"
```

### Visual Flow:

```
┌─────────────────────────────────────────────────────────┐
│  You: "What time is it?"                                │
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
        ┌─────────────────────────┐
        │  main.py                │
        │  run_conversation()     │
        └─────────┬───────────────┘
                  │
      ┌───────────┼───────────┐
      │           │           │
      ▼           ▼           ▼
┌─────────┐ ┌──────────┐ ┌──────────┐
│   MCP   │ │   HITL   │ │  Agent   │
│ Context │ │ Approval │ │  Lookup  │
└─────────┘ └──────────┘ └──────────┘
      │           │           │
      └───────────┴───────────┘
                  │
                  ▼
        ┌─────────────────────┐
        │  Azure GPT-4o       │
        │  "I need time tool" │
        └─────────┬───────────┘
                  │
                  ▼
        ┌─────────────────────┐
        │  tools_registry.py  │
        │  get_current_time() │
        └─────────┬───────────┘
                  │
                  ▼
        ┌─────────────────────┐
        │  Returns: "2:30 PM" │
        └─────────┬───────────┘
                  │
                  ▼
        ┌─────────────────────┐
        │  Agent responds     │
        │  + Saves to DB      │
        └─────────┬───────────┘
                  │
                  ▼
        ┌─────────────────────┐
        │  PostgreSQL         │
        │  (Conversation      │
        │   stored forever)   │
        └─────────────────────┘
```

---

## 🤖 Working with Agents

### Pre-configured Agents

The framework comes with **6 specialized agents** ready to use:

| Agent Name | Purpose | Temperature | Tools | Debug |
|-----------|---------|-------------|-------|-------|
| **general_assistant** | General purpose assistant | 0.7 | time, calculator | false |
| **code_analyzer** | Code review & analysis | 0.3 | time | true |
| **orchestrator** | Multi-agent coordinator | 0.5 | time | true |
| **planner** | Project structure designer | 0.4 | time | true |
| **architect** | Technical architecture | 0.3 | time | true |
| **coder** | Code implementation | 0.2 | time | true |

### Using Agents in Your Code

**1. Use Default Agent (general_assistant)**
```python
from main import AgentFramework

framework = AgentFramework()
await framework.initialize_async()

# Uses default agent (general_assistant)
await framework.run_conversation("What time is it?", "session_123")
```

**2. Use Specific Agent**
```python
# Use code analyzer agent
await framework.run_conversation(
    "Review this Python function for bugs",
    session_id="session_123",
    agent_name="code_analyzer"  # Specify agent
)
```

**3. List Available Agents**
```python
agents = framework.list_agents()
print(f"Available agents: {agents}")
# Output: ['general_assistant', 'code_analyzer', 'orchestrator', 'planner', 'architect', 'coder']
```

**4. Get Agent Details**
```python
agent_data = framework.get_agent("code_analyzer")
print(f"Agent: {agent_data['config']['name']}")
print(f"Tools: {agent_data['tools']}")
print(f"Temperature: {agent_data['config']['temperature']}")
```

### Adding Your Own Agent

**Step 1: Open `agents_config.yaml`**

**Step 2: Add your agent configuration**

```yaml
agents:
  # ... existing agents ...
  
  # NEW AGENT - Customer Support
  - name: "customer_support"
    description: "Friendly customer support agent"
    system_prompt: |
      You are a helpful customer support agent. You:
      - Greet customers warmly
      - Solve problems efficiently
      - Escalate complex issues
      - Always maintain a positive tone
    tools:
      - "get_current_time"
      - "send_notification"
      - "search_documentation"
    enabled: true
    temperature: 0.8
    debug: false
```

**Step 3: Save the file**

**Step 4: Use your new agent**

```python
framework = AgentFramework()  # Automatically loads new agent
await framework.initialize_async()

await framework.run_conversation(
    "I need help with my order",
    session_id="customer_001",
    agent_name="customer_support"
)
```

**That's it!** No code changes needed - just config! 🎉

### Agent Configuration Options

```yaml
- name: "agent_name"              # Unique identifier (use in code)
  description: "What it does"     # Human-readable description
  system_prompt: |                # Agent's personality & instructions
    Your custom instructions here
  tools:                          # List of tool names
    - "tool_name_1"
    - "tool_name_2"
  enabled: true                   # true = load, false = skip
  temperature: 0.7                # 0.0 = precise, 1.0 = creative
  debug: false                    # true = show thought process
```

### Temperature Guide

- **0.0 - 0.3** (Precise): Math, code, factual tasks
  - Example: `coder` (0.2), `architect` (0.3)
- **0.4 - 0.6** (Balanced): General conversation, planning
  - Example: `planner` (0.4), `orchestrator` (0.5)
- **0.7 - 1.0** (Creative): Writing, brainstorming, support
  - Example: `general_assistant` (0.7), `customer_support` (0.8)

### Debug Mode Per Agent

Enable debug to see the agent's thought process:

```yaml
- name: "my_agent"
  # ... other settings ...
  debug: true  # Shows [values], [updates], tool calls
```

Output with `debug: true`:
```
[values] {'agent': 'my_agent', 'messages': [HumanMessage('What time is it?')]}
[updates] {'tool_calls': [{'name': 'get_current_time', 'args': {}}]}
[values] {'messages': [AIMessage('The current time is 2:30 PM')]}
```

See **[docs/DEBUG_GUIDE.md](DEBUG_GUIDE.md)** for complete debug guide.

### Multi-Agent Collaboration

The **orchestrator** agent can coordinate other agents:

```python
# Orchestrator coordinates planner, architect, and coder
await framework.run_conversation(
    "Generate a calculator web app",
    session_id="project_123",
    agent_name="orchestrator"
)
```

**Flow:**
1. **Orchestrator** analyzes requirements
2. **Planner** designs project structure
3. **Architect** defines technical architecture
4. **Coder** implements the code
5. **Orchestrator** validates and delivers

See `tests/examples/example_project_generator.py` for complete example.

---

## 🛠️ Working with Tools

### Understanding the New Tool System (v2.0)

The framework uses **explicit tool imports** - no magic auto-discovery! This is cleaner, more predictable, and gives you full control.

**Key Benefits:**
- ✅ **Explicit over implicit** - You see exactly what tools each agent has
- ✅ **Independent modules** - Each folder can have its own tools file (any name!)
- ✅ **Flexible naming** - Not hardcoded to `tools_registry.py`
- ✅ **Better control** - Each agent specifies exactly what tools it needs
- ✅ **Clean imports** - `from main import tool` (framework-branded)

### Quick Example

**1. Define Your Tools (any file name)**

```python
# my_tools.py (can be any name!)
from main import tool  # Import decorator from framework

@tool
def send_email(recipient: str, subject: str, body: str) -> str:
    """Send an email via SMTP."""
    # Your implementation
    return f"✅ Email sent to {recipient}"

@tool
def query_database(query: str) -> str:
    """Query the product database."""
    # Your implementation
    return "Database results..."
```

**2. Configure Agent to Use Tools**

```yaml
# agents.yaml
agents:
  - name: customer_support
    description: "Customer support agent"
    enabled: true
    temperature: 0.7
    
    # Explicit tool imports (no auto-discovery!)
    tool_imports:
      - "my_tools.send_email"
      - "my_tools.query_database"
      - "tools_registry.get_current_time"  # From default tools
    
    system_prompt: |
      You are a customer support agent with access to email and database tools.
```

**3. That's it!** Framework loads tools dynamically based on your config.

### Built-in Tools (General Purpose)

Located in `tools_registry.py`:

| Tool Name | Purpose | Parameters |
|-----------|---------|------------|
| **get_current_time** | Returns current date/time | None |
| **calculate** | Math expression evaluator | `expression: str` |
| **convert_units** | Convert between units (temp, length, weight) | `value: float, from_unit: str, to_unit: str` |
| **calculate_percentage** | Calculate percentage of value | `value: float, percentage: float` |
| **calculate_statistics** | Stats (mean, median, min, max) | `numbers: str` (comma-separated) |
| **create_file** | Create file with content | `filepath: str, content: str` |
| **create_multiple_files** | Create multiple files from JSON | `files: str` (JSON format) |
| **read_file** | Read file contents | `filepath: str` |
| **list_files** | List directory contents | `directory: str` |
| **get_weather** | Weather information (mock) | `city: str` |
| **get_weather_forecast** | Weather forecast (mock) | `location: str, days: int` |
| **get_weather_alerts** | Weather alerts (mock) | `location: str` |

### Tool Import Format

The import string follows Python's module path:
```
"module_name.tool_name"
```

**Examples:**
```yaml
tool_imports:
  - "tools_registry.get_current_time"        # Root tools_registry.py
  - "tms.tools_registry.tms_analyzer"        # tms/tools_registry.py
  - "my_custom_module.my_tool"               # my_custom_module.py
  - "subfolder.tools.helper"                 # subfolder/tools.py
  - "multiagent.tools_registry.get_weather"  # multiagent/tools_registry.py
```

### Adding Custom Tools

**Step 1: Create Your Tools File**

```python
# email_tools.py
from main import tool  # Framework import (recommended)
# OR: from langchain_core.tools import tool  # Also works

@tool
def send_email(recipient: str, subject: str, body: str) -> str:
    """
    Send an email via SMTP.
    
    Args:
        recipient: Email address of recipient
        subject: Email subject line
        body: Email body content
    
    Returns:
        Confirmation message
    
    Example:
        send_email("user@example.com", "Hello", "Welcome!")
    """
    import smtplib
    from email.mime.text import MIMEText
    
    # Your SMTP logic here
    msg = MIMEText(body)
    msg['Subject'] = subject
    msg['From'] = 'bot@company.com'
    msg['To'] = recipient
    
    # server = smtplib.SMTP('smtp.gmail.com', 587)
    # server.send_message(msg)
    # server.quit()
    
    return f"✅ Email sent to {recipient}"

@tool
def draft_email(recipient: str, subject: str) -> str:
    """Draft an email without sending it."""
    return f"📧 Draft: To={recipient}, Subject={subject}"
```

**Step 2: Configure Agent
    user = database.get_user(user_id)
    # Convert to string for AI consumption
    return f"User: {user['name']}, Email: {user['email']}, Status: {user['status']}"
```

**4. Handle Errors Gracefully**
```python
@tool
def call_api(endpoint: str) -> str:
    """Call an external API endpoint."""
    try:
        response = requests.get(endpoint)
        response.raise_for_status()
        return response.text
    except Exception as e:
        return f"❌ Error calling API: {str(e)}"
```

### Real-World Tool Examples

**1. Database Query Tool**
```python
@tool
def query_database(sql: str) -> str:
    """Execute a SQL query and return results."""
    import psycopg2
    
    try:
        conn = psycopg2.connect(os.getenv("DATABASE_URL"))
        cursor = conn.cursor()
        cursor.execute(sql)
        results = cursor.fetchall()
        conn.close()
        
        return f"Query results: {results}"
    except Exception as e:
        return f"❌ Database error: {str(e)}"
```

**2. File Operations Tool**
```python
@tool
def read_file(filepath: str) -> str:
    """Read contents of a text file."""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        return f"File contents:\n{content}"
    except FileNotFoundError:
        return f"❌ File not found: {filepath}"
    except Exception as e:
        return f"❌ Error reading file: {str(e)}"
```

**3. Web Search Tool**
```python
@tool
def web_search(query: str) -> str:
    """Search the web for information using DuckDuckGo."""
    import requests
    
    try:
        url = f"https://api.duckduckgo.com/?q={query}&format=json"
**Step 2: Configure Agent**

```yaml
# agents.yaml
agents:
  - name: email_agent
    description: "Email specialist"
    tool_imports:
      - "email_tools.send_email"
      - "email_tools.draft_email"
      - "tools_registry.get_current_time"
    system_prompt: |
      You are an email specialist. Use send_email to send emails
      and draft_email to create drafts for review.
```

**Step 3: Test It**

```bash
python your_app.py
# Ask: "Send an email to john@example.com with subject Test"
# Agent will use send_email tool automatically
```

### Tool Design Best Practices

**✅ DO: Use Type Hints**
```python
@tool
def my_tool(param1: str, param2: int, optional: bool = False) -> str:
    """Clear description of what the tool does."""
    return "result"
```

**✅ DO: Write Comprehensive Docstrings**
The AI reads the docstring to understand when to use the tool:
```python
@tool
def search_database(query: str, category: str = "all") -> str:
    """
    Search the product database for items matching the query.
    
    Use this when the user asks about:
    - Product availability
    - Product specifications  
    - Product pricing
    - Inventory status
    
    Args:
        query: Search terms to find products (e.g., "laptop", "phone")
        category: Product category to search in (default: "all")
    
    Returns:
        JSON string with list of matching products and their details
    
    Example:
        search_database("gaming laptop", "electronics")
    """
    # Implementation
    return '{"products": [...]}'
```

**✅ DO: Return Strings**
Always return string results (AI can only process strings):
```python
@tool
def get_user_data(user_id: str) -> str:
    """Get user information from database."""
    user = db.query(user_id)  # Returns object
    
    # Convert to string for AI
    return f"""
User Details:
- Name: {user.name}
- Email: {user.email}
- Status: {user.status}
"""
```

**✅ DO: Handle Errors Gracefully**
```python
@tool
def external_api_call(endpoint: str) -> str:
    """Call external API endpoint."""
    try:
        response = requests.get(endpoint, timeout=10)
        response.raise_for_status()
        return f"✅ Success: {response.json()}"
    except requests.Timeout:
        return "⏱️ Request timed out. Please try again."
    except requests.HTTPError as e:
        return f"❌ API Error: {e}"
    except Exception as e:
        return f"❌ Unexpected error: {str(e)}"
```

**❌ DON'T: Use Wildcards**
```yaml
# This won't work - no wildcard support
tool_imports:
  - "my_tools.*"  # ❌ NOT SUPPORTED
```

**❌ DON'T: Return Complex Objects**
```python
@tool
def bad_tool(user_id: str) -> dict:  # ❌ AI can't read dicts
    return {"name": "John", "age": 30}

@tool  
def good_tool(user_id: str) -> str:  # ✅ Return string
    return "Name: John, Age: 30"
```

### Organizing Tools by Purpose

**Pattern 1: Shared Common Tools**
```
project/
├── common_tools.py          # Shared utilities
├── email_tools.py           # Email-specific
├── database_tools.py        # Database operations
└── agents.yaml
```

```python
# common_tools.py
from main import tool

@tool
def get_current_time() -> str:
    """Get current timestamp."""
    from datetime import datetime
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
```

```yaml
# agents.yaml - Multiple agents can use same tools
agents:
  - name: agent1
    tool_imports:
      - "common_tools.get_current_time"
      - "email_tools.send_email"
  
  - name: agent2
    tool_imports:
      - "common_tools.get_current_time"
      - "database_tools.query_db"
```

**Pattern 2: Specialized Tool Sets Per Agent**
```
project/
├── diagnostics/
│   └── tools.py             # Diagnostic tools
├── communication/
│   └── tools.py             # Email, Slack, etc.
└── agents.yaml
```

```yaml
# agents.yaml
agents:
  - name: diagnostic_agent
    tool_imports:
      - "diagnostics.tools.diagnose_system"
      - "diagnostics.tools.check_health"
  
  - name: communication_agent
    tool_imports:
      - "communication.tools.send_email"
      - "communication.tools.send_slack"
```

**Pattern 3: Mix and Match**
```yaml
agents:
  - name: power_agent
    tool_imports:
      - "tools_registry.get_current_time"        # General
      - "tms.tools_registry.tms_analyzer"        # TMS-specific
      - "custom_module.special_tool"             # Custom
```

### Real-World Example: TMS System

See the **[tms/ folder](tms/README.md)** for a complete production example:

```python
# tms/tools_registry.py
from main import tool

@tool
def tms_analyzer(query: str) -> str:
    """Diagnose TMS issues for preset/bay combinations."""
    # Complex implementation
    return "Diagnostic results..."

@tool
def tms_email_sender(query: str) -> str:
    """Draft or send emails via SMTP."""
    # SMTP implementation
    return "Email sent..."
```

```yaml
# tms/agents.yaml
agents:
  - name: tms_diagnostic_analyzer
    tool_imports:
      - "tms.tools_registry.tms_analyzer"
      - "tms.tools_registry.get_current_time"
  
  - name: tms_email_send
    hitl: true  # Requires approval
    tool_imports:
      - "tms.tools_registry.tms_email_sender"
      - "tms.tools_registry.get_current_time"
```

### Troubleshooting Tools

**Issue: "Module not found"**
```
Failed to import tool 'mymodule.mytool': No module named 'mymodule'
```

**Solution:**
1. Check file `mymodule.py` exists
2. Verify Python path includes the directory
3. Module name matches file name (case-sensitive)

**Issue: "Tool not found in module"**
```
Tool 'mytool' not found in module 'mymodule'
```

**Solution:**
1. Function is decorated with `@tool`
2. Function name matches exactly (case-sensitive)
3. Function is defined before being imported

**Issue: "No tools loaded"**
```
Agent 'my_agent' loaded 0 tool(s)
```

**Solution:**
1. Check `tool_imports` field exists in agents.yaml
2. Import strings are properly formatted: `"module.function"`
3. Tools are decorated with `@tool`

### Advanced: Tool Validation

---

## ✅ Testing Your Code

The framework includes a **comprehensive test suite** with 22+ tests covering all major features.

### Test Structure

```
tests/
├── conftest.py                     # Pytest fixtures (framework, sessions)
├── test_framework_basic.py         # Framework initialization (7 tests)
├── test_conversations.py           # Conversations & memory (6 tests)
├── test_tools.py                   # Tool registry (4 tests) ✅ VERIFIED
├── test_multi_agent.py             # Multi-agent collaboration (5 tests)
├── test_api.py                     # API endpoints
├── test_v1_migration.py            # LangChain v1 migration
├── pytest.ini                      # Pytest configuration
├── README.md                       # Complete testing guide
├── TEST_SUMMARY.md                 # Test structure summary
├── QUICK_COMMANDS.md               # Quick pytest commands
└── examples/                       # Example applications
    ├── example_basic_usage.py      # Basic framework usage
    ├── example_advanced.py         # Multi-agent system
    ├── example_project_generator.py # 4-agent collaboration
    └── app_with_api.py             # CLI + API together
```

### Quick Test Commands

```powershell
# Run all tests
pytest tests/ -v

# Run specific test file
pytest tests/test_framework_basic.py -v
pytest tests/test_tools.py -v
pytest tests/test_conversations.py -v

# Run tests with output
pytest tests/ -v -s

# Run tests with coverage
pytest tests/ --cov=. --cov-report=html

# Run specific test
pytest tests/test_tools.py::test_get_all_tools -v

# Run tests in parallel (faster)
pytest tests/ -n auto
```

### Test Categories

**1. Framework Tests** (`test_framework_basic.py`)
- Framework initialization
- Agent creation
- Configuration loading
- LLM provider setup
- Error handling

```powershell
pytest tests/test_framework_basic.py -v
# Expected: 7 tests passed
```

**2. Tool Tests** (`test_tools.py`) ✅ VERIFIED PASSING
- Tool discovery
- Tool retrieval by name
- Tool attributes validation
- Invalid tool handling

```powershell
pytest tests/test_tools.py -v
# Expected: 4 tests passed in ~0.27s
```

**3. Conversation Tests** (`test_conversations.py`)
- Basic conversations
- Tool usage in conversations
- Memory persistence
- Session management
- Agent switching

```powershell
pytest tests/test_conversations.py -v
# Expected: 6 tests passed
```

**4. Multi-Agent Tests** (`test_multi_agent.py`)
- Agent coordination
- Orchestrator pattern
- Multiple agents in sequence
- Agent communication
- Project generation workflow

```powershell
pytest tests/test_multi_agent.py -v
# Expected: 5 tests passed
```

**5. API Tests** (`test_api.py`)
- Health endpoint
- Agent listing
- Chat endpoint
- Streaming chat
- Error responses

```powershell
pytest tests/test_api.py -v
```

### Running Examples

All examples are in `tests/examples/` directory:

**1. Basic Usage Example**
```powershell
python tests/examples/example_basic_usage.py
```
Demonstrates: Framework initialization, basic conversation, tool usage, memory

**2. Advanced Multi-Agent Example**
```powershell
python tests/examples/example_advanced.py
```
Demonstrates: Customer support bot, agent routing, complex conversations

**3. Project Generator Example**
```powershell
python tests/examples/example_project_generator.py
```
Demonstrates: 4-agent collaboration (orchestrator, planner, architect, coder)

**4. CLI + API Example**
```powershell
python tests/examples/app_with_api.py
```
Demonstrates: Running CLI and FastAPI server simultaneously

### Writing Your Own Tests

**Example: Test Custom Agent**
```python
# tests/test_custom.py
import pytest
from main import AgentFramework

@pytest.mark.asyncio
async def test_custom_agent():
    """Test custom agent creation and usage."""
    framework = AgentFramework()
    await framework.initialize_async()
    
    # Verify agent exists
    assert "my_custom_agent" in framework.list_agents()
    
    # Test conversation
    await framework.run_conversation(
        "Test message",
        session_id="test_session",
        agent_name="my_custom_agent"
    )
    
    await framework.cleanup()
```

**Example: Test Custom Tool**
```python
# tests/test_custom_tools.py
from tools_registry import get_all_tools, my_custom_tool

def test_custom_tool_exists():
    """Test that custom tool is discovered."""
    all_tools = get_all_tools()
    tool_names = [tool.name for tool in all_tools]
    assert "my_custom_tool" in tool_names

def test_custom_tool_execution():
    """Test custom tool execution."""
    result = my_custom_tool.invoke({"param": "value"})
    assert "expected output" in result
```

### Test Configuration

**pytest.ini**
```ini
[pytest]
testpaths = tests
python_files = test_*.py
python_classes = Test*
python_functions = test_*
asyncio_mode = auto
markers =
    slow: marks tests as slow
    integration: marks tests as integration tests
```

### Continuous Integration

Add tests to your CI/CD pipeline:

```yaml
# .github/workflows/tests.yml
name: Tests
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-python@v2
        with:
          python-version: '3.10'
      - run: pip install -r requirements.txt
      - run: pytest tests/ -v
```

### Test Best Practices

1. **Use fixtures** for setup/teardown:
```python
@pytest.fixture
async def framework():
    fw = AgentFramework()
    await fw.initialize_async()
    yield fw
    await fw.cleanup()
```

2. **Test isolation**: Each test should be independent
3. **Clear assertions**: Use descriptive assertion messages
4. **Mock external services**: Don't rely on external APIs in tests
5. **Test edge cases**: Not just happy paths

### Documentation

- **[tests/README.md](tests/README.md)** - Complete testing guide
- **[tests/TEST_SUMMARY.md](tests/TEST_SUMMARY.md)** - Test structure
- **[tests/QUICK_COMMANDS.md](tests/QUICK_COMMANDS.md)** - Command reference
- **[tests/examples/README.md](tests/examples/README.md)** - Examples guide

---

## 🚀 Advanced Features

### 1. Debug Mode

Enable debug mode to see your agent's complete thought process.

**Per-Agent Debug (Recommended)**
```yaml
# agents_config.yaml
agents:
  - name: "my_agent"
    debug: true  # Only this agent shows debug output
```

**Global Debug**
```env
# .env
DEBUG_MODE=true  # All agents show debug output
```

**Debug Output Example:**
```
[values] {'agent': 'general_assistant', 'messages': [HumanMessage('What time is it?')]}
[updates] {'tool_calls': [{'name': 'get_current_time', 'args': {}}]}
[updates] {'tool_messages': [ToolMessage('2025-11-01 14:30:45')]}
[values] {'messages': [AIMessage('The current time is 2:30 PM')]}
```

See **[docs/DEBUG_GUIDE.md](DEBUG_GUIDE.md)** for complete debug guide.

---

### 2. Human-in-the-Loop (HITL)

Require human approval before agent actions.

**Enable HITL**
```env
# .env
HITL_ENABLED=true
```

**Example Flow:**
```
[HITL] Agent wants to: Process message: 'Send email to john@example.com'
[HITL] Using tool: Agent: customer_support
[HITL] Approve? (y/n): y
[HITL] Decision: APPROVED
```

**Customize HITL in Code:**
```python
# main.py - HumanInTheLoopMiddleware
async def should_proceed(self, action: str, tool_name: str = None) -> bool:
    # Only require approval for sensitive tools
    sensitive_tools = ["send_email", "delete_file", "execute_command"]
    
    if tool_name not in sensitive_tools:
        return True  # Auto-approve safe tools
    
    # Ask for approval for sensitive tools
    response = input(f"[HITL] Approve {tool_name}? (y/n): ")
    return response.lower() == 'y'
```

---

### 3. Multi-LLM Support

Switch between different LLM providers easily.

**Azure OpenAI (Default)**
```env
# .env
LLM_PROVIDER=azure_openai
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_API_KEY=your-key
AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4o
```

**OpenAI Direct**
```env
LLM_PROVIDER=openai
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-4o
```

**Anthropic Claude**
```env
LLM_PROVIDER=anthropic
ANTHROPIC_API_KEY=sk-ant-...
ANTHROPIC_MODEL=claude-3-opus-20240229
```

**Google Gemini**
```env
LLM_PROVIDER=google
GOOGLE_API_KEY=...
GOOGLE_MODEL=gemini-pro
```

**Ollama (Local)**
```env
LLM_PROVIDER=ollama
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=llama2
```

**Local HuggingFace**
```env
LLM_PROVIDER=local
HUGGINGFACE_MODEL=meta-llama/Llama-2-7b-chat-hf
```

See **[docs/LLM_PROVIDERS.md](LLM_PROVIDERS.md)** for complete multi-LLM guide.

---

### 4. Professional Logging

Configure logging levels and formats.

**Configuration**
```env
# .env
LOG_LEVEL=INFO           # DEBUG, INFO, WARNING, ERROR, CRITICAL
LOG_FORMAT=standard      # standard, detailed, json
LOG_FILE=app.log         # File path (optional)
```

**Log Levels:**
- **DEBUG**: Detailed diagnostic information
- **INFO**: General informational messages (default)
- **WARNING**: Warning messages
- **ERROR**: Error messages
- **CRITICAL**: Critical errors

**Log Formats:**
- **standard**: Simple format for console
- **detailed**: Includes timestamps and line numbers
- **json**: Structured JSON for log aggregation

See **[docs/LOGGING_GUIDE.md](LOGGING_GUIDE.md)** for complete logging guide.

---

### 5. Model Context Protocol (MCP)

Connect to external data sources via MCP.

**Enable MCP**
```env
# .env
MCP_ENABLED=true
```

**Configure MCP Servers**
```yaml
# mcp_servers.yaml
mcp_servers:
  - name: "filesystem"
    type: "stdio"
    command: "npx"
    args:
      - "-y"
      - "@modelcontextprotocol/server-filesystem"
      - "C:/MyProject"
    enabled: true
    description: "File system access"
  
  - name: "github"
    type: "stdio"
    command: "npx"
    args:
      - "-y"
      - "@modelcontextprotocol/server-github"
    env:
      GITHUB_TOKEN: "your_token"
    enabled: false
    description: "GitHub API access"
```

**Note:** MCP support is currently a stub implementation. The configuration exists, but the actual MCP protocol client needs to be implemented in `main.py` → `MCPContextProvider.get_context()`.

---

### 6. Conversation Memory & Checkpointing

Agents remember conversations using PostgreSQL checkpointing.

**How It Works:**
```python
# Each conversation has a unique thread_id
thread_id = f"{session_id}_{agent_name}"

# Messages are stored in PostgreSQL
config = {
    "configurable": {
        "thread_id": thread_id
    }
}

# Agent retrieves past messages automatically
async for event in agent.astream_events(inputs, config=config):
    # Agent has access to full conversation history
    pass
```

**Memory Benefits:**
- ✅ Conversations persist across restarts
- ✅ Agents remember context from previous messages
- ✅ Each user gets isolated memory (session_id)
- ✅ Powered by `langgraph-checkpoint-postgres`

**Example:**
```python
# First message
await framework.run_conversation("My name is John", "user_123")
# Agent: "Nice to meet you, John!"

# Later conversation (same session_id)
await framework.run_conversation("What's my name?", "user_123")
# Agent: "Your name is John" (remembers!)
```

---

### 7. Custom System Prompts

Give agents unique personalities via `system_prompt`.

**Example: Code Reviewer**
```yaml
# agents_config.yaml
- name: "code_reviewer"
  system_prompt: |
    You are an expert software engineer specializing in code review.
    Analyze code for:
    - Bugs and potential errors
    - Performance issues
    - Security vulnerabilities
    - Best practices and code quality
    
    Provide specific, actionable feedback with examples.
  tools: ["get_current_time"]
  temperature: 0.3
```

**Example: Creative Writer**
```yaml
- name: "creative_writer"
  system_prompt: |
    You are a creative writer with a vivid imagination.
    Write engaging, descriptive content with:
    - Rich imagery and metaphors
    - Varied sentence structure
    - Emotional depth
    - Unique perspectives
  tools: ["get_current_time"]
  temperature: 0.9
```

See **[docs/SYSTEM_PROMPTS.md](SYSTEM_PROMPTS.md)** for more examples.

---

### 8. Async Architecture

The framework is fully async for high performance.

**Benefits:**
- ✅ Non-blocking I/O operations
- ✅ Handle multiple requests concurrently
- ✅ Efficient database connections
- ✅ Streaming responses

**Usage:**
```python
import asyncio
from main import AgentFramework

async def main():
    framework = AgentFramework()
    await framework.initialize_async()
    
    # Run multiple conversations concurrently
    await asyncio.gather(
        framework.run_conversation("Hello", "user_1"),
        framework.run_conversation("Hi", "user_2"),
        framework.run_conversation("Hey", "user_3")
    )
    
    await framework.cleanup()

asyncio.run(main())
```

---

### 9. Configuration-Driven Design

All customization via config files - no code changes needed.

**What You Can Configure:**

| Configuration | File | What to Change |
|--------------|------|----------------|
| **Agents** | `agents_config.yaml` | Add/remove agents, tools, temperatures, system prompts |
| **Tools** | `tools_registry.py` | Add custom tool functions with `@tool` decorator |
| **LLM Provider** | `.env` | Switch between Azure, OpenAI, Anthropic, Ollama, etc. |
| **Features** | `.env` | Enable/disable HITL, MCP, debug mode |
| **API Settings** | `.env` | Configure API host, port, reload |
| **Logging** | `.env` | Set log level, format, output file |
| **MCP Servers** | `mcp_servers.yaml` | Configure external data sources |
| **Database** | `.env` | PostgreSQL connection string |

---

### 10. Extensibility

The framework is designed for extensibility.

**Extension Points:**

1. **Custom Agents**: Add unlimited agents via YAML
2. **Custom Tools**: Add tool functions with `@tool` decorator
3. **Custom LLM Providers**: Implement `_initialize_llm()` variants
4. **Custom Middleware**: Extend `HumanInTheLoopMiddleware`
5. **Custom MCP Clients**: Implement `MCPContextProvider.get_context()`
6. **Custom API Endpoints**: Add routes to `api_server.py`

See **[docs/EXTENSIBILITY.md](EXTENSIBILITY.md)** for complete extensibility guide.

---

## 🐛 Troubleshooting

### Common Issues & Solutions

**Issue: "ModuleNotFoundError: No module named 'langgraph'"**

**Solution:**
```powershell
pip install -r requirements.txt
```
Make sure all dependencies are installed.

---

**Issue: "docker-compose: command not found"**

**Solution:**
- Install Docker Desktop: https://www.docker.com/products/docker-desktop
- Restart your terminal after installation
- Verify with: `docker --version`

---

**Issue: "Connection refused" to PostgreSQL**

**Solution:**
```powershell
# Check if Docker is running
docker ps

# Start the database
docker-compose up -d

# Check logs
docker-compose logs -f postgres

# Verify connection
docker exec -it agent-framework-postgres-1 psql -U langchain -d langchain_db
```

---

**Issue: "Invalid Azure OpenAI credentials"**

**Solution:**
- Check your `.env` file has correct values
- Verify endpoint URL ends with `.openai.azure.com/`
- Verify API key is correct (starts with alphanumeric chars)
- Check deployment name matches your Azure deployment
- Verify API version is supported: `2024-02-15-preview`

**Test Azure connection:**
```powershell
curl https://your-resource.openai.azure.com/openai/deployments?api-version=2024-02-15-preview `
  -H "api-key: your-api-key"
```

---

**Issue: Tool not found**

```
[Warning] Tool 'my_tool' not found in registry
```

**Solution:**
- Check tool name in `agents_config.yaml` matches function name in `tools_registry.py`
- Make sure you added `@tool` decorator above the function
- Verify function is defined in `tools_registry.py` (not another file)
- Restart the program to reload tools

**Verify tools:**
```python
from tools_registry import get_all_tools
tools = get_all_tools()
print([tool.name for tool in tools])
```

---

**Issue: Agent not created**

```
Agent 'my_agent' not found. Available: general_assistant, code_analyzer
```

**Solution:**
- Check `agents_config.yaml` for your agent definition
- Make sure `enabled: true` is set
- Check for YAML syntax errors (indentation matters!)
- Verify YAML formatting with: https://www.yamllint.com/

**Validate YAML:**
```python
import yaml
with open('agents_config.yaml') as f:
    config = yaml.safe_load(f)
    print([agent['name'] for agent in config['agents'] if agent['enabled']])
```

---

**Issue: "psycopg.OperationalError" on Windows**

```
psycopg.OperationalError: asynchronous connection failed
```

**Solution:**
This is fixed in `api_server.py` with Windows event loop policy:

```python
# api_server.py (lines 15-22)
if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
```

If you're running `main.py` directly, add this at the top:
```python
import sys
import asyncio

if sys.platform == "win32":
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
```

---

**Issue: "RuntimeError: This event loop is already running"**

**Solution:**
You're trying to call `asyncio.run()` from within an async context.

**Instead of:**
```python
# DON'T DO THIS
async def my_function():
    asyncio.run(framework.initialize_async())  # ❌ Wrong
```

**Do this:**
```python
# DO THIS
async def my_function():
    await framework.initialize_async()  # ✅ Correct
```

---

**Issue: Tests fail with "fixture 'event_loop' not found"**

**Solution:**
Make sure `pytest-asyncio` is installed and configured:

```powershell
pip install pytest-asyncio>=0.23.0
```

Check `pytest.ini`:
```ini
[pytest]
asyncio_mode = auto
```

---

**Issue: API server returns 500 Internal Server Error**

**Solution:**
Check the console output for detailed error messages.

Common causes:
- Database not running: `docker-compose up -d`
- Invalid `.env` configuration
- Azure OpenAI credentials incorrect

**View detailed logs:**
```powershell
# Run API server with verbose logging
$env:LOG_LEVEL="DEBUG"; python api_server.py
```

---

**Issue: Agent responses are too slow**

**Solutions:**

1. **Use faster model:**
```env
# .env
AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4o-mini  # Faster than gpt-4o
```

2. **Reduce temperature:**
```yaml
# agents_config.yaml
temperature: 0.1  # Faster, more deterministic
```

3. **Use local model (Ollama):**
```env
LLM_PROVIDER=ollama
OLLAMA_MODEL=llama2
```

---

**Issue: Database fills up over time**

**Solution:**
Clean up old checkpoints periodically.

```python
# cleanup_old_checkpoints.py
import asyncio
from main import AgentFramework

async def cleanup():
    framework = AgentFramework()
    await framework.initialize_async()
    
    # Delete checkpoints older than 30 days
    await framework.checkpointer.delete_old_checkpoints(days=30)
    
    await framework.cleanup()

asyncio.run(cleanup())
```

**Or reset database:**
```powershell
docker-compose down -v  # Deletes ALL data
docker-compose up -d    # Fresh start
```

---

**Issue: Debug output is too verbose**

**Solution:**

1. **Disable debug for specific agents:**
```yaml
# agents_config.yaml
- name: "my_agent"
  debug: false  # Turn off debug
```

2. **Disable global debug:**
```env
# .env
DEBUG_MODE=false
```

3. **Adjust log level:**
```env
LOG_LEVEL=WARNING  # Only show warnings and errors
```

---

**Issue: Import errors when running examples**

```
ModuleNotFoundError: No module named 'main'
```

**Solution:**
Examples are in `tests/examples/` but they import from root. Run them from the project root:

```powershell
# Run from project root directory
cd "C:\Users\...\Agent-Framework"
python tests\examples\example_basic_usage.py
```

Or add root to Python path:
```python
import sys
sys.path.insert(0, '../..')  # Add root to path
from main import AgentFramework
```

---

### Getting Help

If you're still stuck:

1. **Check documentation:**
   - [docs/DEVELOPER_GUIDE.md](DEVELOPER_GUIDE.md) - API reference
   - [docs/DEBUG_GUIDE.md](DEBUG_GUIDE.md) - Debug mode setup
   - [docs/API_GUIDE.md](API_GUIDE.md) - REST API details

2. **Run tests to verify setup:**
```powershell
pytest tests/test_framework_basic.py -v
pytest tests/test_tools.py -v
```

3. **Enable debug logging:**
```env
DEBUG_MODE=true
LOG_LEVEL=DEBUG
```

4. **Check issue tracker:** Look for similar issues in project repository

---

## ⚡ REST API & Swagger UI

The framework includes a **FastAPI server** that provides REST API access with automatic Swagger UI documentation.

### How to Implement Web API in Your Project

There are **three ways** to add web API functionality to your agent-based application:

#### **Method 1: Simple --api Flag (Recommended)**

The simplest way - add a simple check in your main script:

```python
# your_project.py
from main import create_api, create_cli
import sys

if __name__ == "__main__":
    if '--api' in sys.argv:
        # API mode - starts FastAPI server with Swagger UI
        api = create_api("agents.yaml", host="0.0.0.0", port=8000)
        api.run()
    else:
        # CLI mode - interactive chat
        cli = create_cli("agents.yaml")
        cli.run()
```

**Usage:**
```powershell
# Run CLI mode (interactive chat)
python your_project.py

# Run API mode (FastAPI server)
python your_project.py --api
```

**Why This Pattern?**
- ✅ Simple - just 2 lines of code
- ✅ Explicit - clear what --api does
- ✅ Flexible - easy to add custom logic per mode
- ✅ Standard - same pattern used in multiagent example

#### **Method 2: Separate API Script**

Create a dedicated API server file:

```python
# api.py - Separate API server
from main import create_api

if __name__ == "__main__":
    api = create_api(
        agents_config_path="agents.yaml",
        host="0.0.0.0",
        port=8000
    )
    api.run()
```

```python
# cli.py - Separate CLI script
from main import create_cli

if __name__ == "__main__":
    cli = create_cli("agents.yaml")
    cli.run()
```

**Usage:**
```powershell
python api.py   # Start API server
python cli.py   # Start CLI chat
```

**When to Use:**
- Large applications with complex startup logic
- Different deployment strategies (CLI vs API)
- Need separate configurations per mode

#### **Method 3: Custom Business Logic + API**

Combine custom business logic with API mode:

```python
# project_generator.py - Custom app with API support
from main import create_api, AgentFramework
import sys

class ProjectGenerator:
    def __init__(self):
        self.framework = AgentFramework("agents.yaml")
    
    def generate(self, description):
        """Custom business logic."""
        response = self.framework.run_conversation(
            f"Create a project: {description}",
            session_id="generator"
        )
        # ... custom file creation logic ...
        return response

def main():
    if '--api' in sys.argv:
        # API mode - exposes agents via REST API
        api = create_api("agents.yaml")
        api.run()
    else:
        # CLI mode - custom business logic
        generator = ProjectGenerator()
        description = input("Project description: ")
        generator.generate(description)

if __name__ == "__main__":
    main()
```

**When to Use:**
- Applications with custom business logic beyond simple chat
- Need both programmatic usage AND web API access
- Want to reuse agents in different contexts

### Starting the API Server

**Quick Start:**
```powershell
# Use the built-in API server
python api_server.py

# Or use the multiagent example with --api flag
cd multiagent
python agents.py --api
```

**Access Points:**
- **Swagger UI**: http://localhost:8000/docs (Interactive API testing)
- **ReDoc**: http://localhost:8000/redoc (Alternative documentation)
- **OpenAPI Schema**: http://localhost:8000/openapi.json

### API Endpoints

| Endpoint | Method | Description | Example |
|----------|--------|-------------|---------|
| `/health` | GET | Health check | `GET /health` |
| `/agents` | GET | List all agents | `GET /agents` |
| `/agents/{name}` | GET | Get agent details | `GET /agents/general_assistant` |
| `/chat` | POST | Send message to agent | See below |
| `/chat/stream` | POST | Stream agent response (SSE) | See below |

### API Usage Examples

**1. Health Check**
```bash
curl http://localhost:8000/health
```

**Response:**
```json
{
  "status": "healthy",
  "timestamp": "2025-11-01T14:30:45.123456"
}
```

**2. List All Agents**
```bash
curl http://localhost:8000/agents
```

**Response:**
```json
{
  "agents": [
    {
      "name": "general_assistant",
      "description": "General purpose AI assistant",
      "tools": ["get_current_time", "calculate"],
      "temperature": 0.7,
      "enabled": true
    },
    {
      "name": "code_analyzer",
      "description": "Code review specialist",
      "tools": ["get_current_time"],
      "temperature": 0.3,
      "enabled": true
    }
  ],
  "count": 6
}
```

**3. Get Agent Details**
```bash
curl http://localhost:8000/agents/general_assistant
```

**Response:**
```json
{
  "name": "general_assistant",
  "description": "General purpose AI assistant",
  "tools": ["get_current_time", "calculate"],
  "temperature": 0.7,
  "system_prompt": "You are a helpful, friendly AI assistant...",
  "enabled": true,
  "debug": false
}
```

**4. Chat with Agent**
```bash
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "What time is it?",
    "thread_id": "user_123",
    "agent_name": "general_assistant"
  }'
```

**Response:**
```json
{
  "response": "The current time is 2:30 PM on November 1, 2025.",
  "thread_id": "user_123",
  "agent_name": "general_assistant",
  "timestamp": "2025-11-01T14:30:45.123456"
}
```

**5. Streaming Chat (Server-Sent Events)**
```bash
curl -X POST http://localhost:8000/chat/stream \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Calculate 25 * 48",
    "thread_id": "user_123"
  }'
```

**Response (SSE):**
```
data: {"type": "token", "content": "The"}
data: {"type": "token", "content": " result"}
data: {"type": "token", "content": " is"}
data: {"type": "token", "content": " 1200"}
data: {"type": "done", "full_response": "The result is 1200"}
```

### Client Examples

**Python Client**
```python
import requests

def chat(message, thread_id="default", agent_name=None):
    """Send message to AI agent."""
    url = "http://localhost:8000/chat"
    payload = {
        "message": message,
        "thread_id": thread_id
    }
    if agent_name:
        payload["agent_name"] = agent_name
    
    response = requests.post(url, json=payload)
    return response.json()["response"]

# Usage
answer = chat("What time is it?", thread_id="user_123")
print(answer)
```

**JavaScript/TypeScript Client**
```javascript
async function chat(message, threadId = "default", agentName = null) {
  const response = await fetch('http://localhost:8000/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      message: message,
      thread_id: threadId,
      agent_name: agentName
    })
  });
  
  const data = await response.json();
  return data.response;
}

// Usage
const answer = await chat("Calculate 25 * 48", "user_123");
console.log(answer);
```

**React Component Example**
```jsx
import React, { useState } from 'react';

function ChatComponent() {
  const [message, setMessage] = useState('');
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);

  const sendMessage = async () => {
    setLoading(true);
    
    const res = await fetch('http://localhost:8000/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: message,
        thread_id: 'user_session_123'
      })
    });
    
    const data = await res.json();
    setResponse(data.response);
    setLoading(false);
  };

  return (
    <div>
      <input 
        value={message} 
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Ask me anything..."
      />
      <button onClick={sendMessage} disabled={loading}>
        {loading ? 'Thinking...' : 'Send'}
      </button>
      <p>{response}</p>
    </div>
  );
}
```

**Streaming Example (Python)**
```python
import requests

def chat_stream(message, thread_id="default"):
    """Stream chat response token by token."""
    url = "http://localhost:8000/chat/stream"
    payload = {"message": message, "thread_id": thread_id}
    
    with requests.post(url, json=payload, stream=True) as response:
        for line in response.iter_lines():
            if line:
                # Remove 'data: ' prefix
                data_str = line.decode('utf-8').replace('data: ', '')
                data = json.loads(data_str)
                
                if data['type'] == 'token':
                    print(data['content'], end='', flush=True)
                elif data['type'] == 'done':
                    print()  # New line
                    break

# Usage
chat_stream("Tell me a story", "user_123")
```

### API Configuration

Configure in `.env`:
```env
# API Server Configuration
API_HOST=0.0.0.0        # Listen on all interfaces
API_PORT=8000           # Port number
API_RELOAD=false        # Auto-reload on code changes (dev only)
```

### Windows Event Loop Fix

The API server includes a fix for Windows psycopg async compatibility:

```python
# api_server.py (lines 15-22)
if sys.platform == "win32":
    # Required for psycopg async on Windows
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
```

### API Benefits

- 🌐 **Language agnostic**: Use from Python, JavaScript, Go, Rust, etc.
- 📱 **Build any UI**: Web apps, mobile apps, desktop apps
- 📖 **Interactive docs**: Test API in browser with Swagger UI
- 🔄 **Streaming support**: Real-time token-by-token responses
- 🔌 **Easy integration**: Drop-in to existing systems
- � **Production ready**: Async, scalable, tested

### Complete API Documentation

For detailed API reference, see **[docs/API_GUIDE.md](API_GUIDE.md)**:
- Complete endpoint documentation
- Request/response schemas
- Authentication setup
- Rate limiting
- Error handling
- Deployment guides

---

## ❓ FAQ

### General Questions

**Q: What is this framework for?**

**A:** This is a production-ready AI agent framework built with LangChain v1 and LangGraph. It allows developers to:
- Build multi-agent AI applications
- Create custom AI agents with different personalities
- Add custom tools/capabilities to agents
- Access agents via REST API
- Persist conversations in PostgreSQL
- Use multiple LLM providers (Azure OpenAI, OpenAI, Anthropic, Ollama, etc.)

---

**Q: Do I need to modify `main.py` to use the framework?**

**A:** No! The framework follows a "framework-first" design:
- **Import** classes from `main.py` into your own app
- **Configure** via `agents_config.yaml`, `tools_registry.py`, and `.env`
- **Never modify** core framework files

---

**Q: Can I use this in production?**

**A:** Yes! The framework is production-ready:
- ✅ Async architecture for high performance
- ✅ PostgreSQL for reliable conversation storage
- ✅ REST API with Swagger UI
- ✅ Comprehensive test suite (22+ tests)
- ✅ Error handling and logging
- ✅ Human-in-the-loop safety layer
- ✅ Multi-LLM support
- ✅ Configuration-driven (no code changes needed)

---

**Q: How much does it cost to run?**

**A:** Costs depend on your LLM provider:

**Azure OpenAI (GPT-4o):**
- ~$0.03 per 1K tokens
- ~$30-100/month for moderate use

**OpenAI Direct (GPT-4o):**
- Similar to Azure pricing

**Anthropic Claude:**
- Varies by model (Claude 3 Opus, Sonnet, Haiku)

**Ollama (Local):**
- Free! Runs on your hardware
- Requires GPU for good performance

**PostgreSQL:**
- Free (Docker locally)
- $15-50/month (managed services like AWS RDS, Azure Database)

**Total estimate:** $20-100/month for cloud setup with moderate use

---

### Technical Questions

**Q: What Python version do I need?**

**A:** Python 3.10 or higher is required. Test with:
```powershell
python --version
```

---

**Q: Can I use local models (Ollama, LM Studio)?**

**A:** Yes! Configure in `.env`:

**Ollama:**
```env
LLM_PROVIDER=ollama
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=llama2
```

**Local HuggingFace:**
```env
LLM_PROVIDER=local
HUGGINGFACE_MODEL=meta-llama/Llama-2-7b-chat-hf
```

See **[docs/LLM_PROVIDERS.md](LLM_PROVIDERS.md)** for complete guide.

---

**Q: How do agents remember past conversations?**

**A:** The framework uses LangGraph's PostgreSQL checkpointer:
1. Each conversation has a unique `thread_id` = `{session_id}_{agent_name}`
2. All messages are stored in PostgreSQL
3. When you send a new message, the agent retrieves the full conversation history
4. Conversations persist across restarts

**Example:**
```python
# First message
await framework.run_conversation("My name is Alice", "user_123")

# Restart the application...

# Later message (same session_id)
await framework.run_conversation("What's my name?", "user_123")
# Agent: "Your name is Alice" (remembered!)
```

---

**Q: Can I add a web UI?**

**A:** Yes! Multiple options:

**Option 1: Use the REST API**
```javascript
// React, Vue, Angular, vanilla JS
fetch('http://localhost:8000/chat', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    message: "Hello!",
    thread_id: "user_123"
  })
})
```

**Option 2: Streamlit**
```python
import streamlit as st
from main import AgentFramework

st.title("AI Agent Chat")
message = st.text_input("Your message:")

if st.button("Send"):
    framework = AgentFramework()
    await framework.initialize_async()
    response = await framework.run_conversation(message, "streamlit_session")
    st.write(response)
```

**Option 3: Gradio**
```python
import gradio as gr
from main import AgentFramework

async def chat(message, history):
    framework = AgentFramework()
    await framework.initialize_async()
    response = await framework.run_conversation(message, "gradio_session")
    return response

gr.ChatInterface(chat).launch()
```

---

**Q: How do I add a new tool?**

**A:** Three simple steps:

1. Add function in `tools_registry.py`:
```python
@tool
def my_new_tool(param: str) -> str:
    """Description of what the tool does."""
    return f"Result: {param}"
```

2. Assign to agent in `agents_config.yaml`:
```yaml
agents:
  - name: "my_agent"
    tools:
      - "my_new_tool"  # Add here
```

3. Restart the framework - that's it!

---

**Q: How do I create a new agent?**

**A:** Just add to `agents_config.yaml`:

```yaml
agents:
  - name: "my_new_agent"
    description: "What it does"
    system_prompt: |
      You are a helpful assistant that...
    tools:
      - "tool1"
      - "tool2"
    enabled: true
    temperature: 0.7
    debug: false
```

No code changes needed!

---

**Q: Can agents work together?**

**A:** Yes! Use the **orchestrator pattern**:

The `orchestrator` agent coordinates other agents:
```python
await framework.run_conversation(
    "Generate a calculator web app",
    session_id="project_001",
    agent_name="orchestrator"
)
```

**Flow:**
1. Orchestrator analyzes requirements
2. Planner designs project structure
3. Architect defines technical details
4. Coder implements the code
5. Orchestrator validates and delivers

See `tests/examples/example_project_generator.py` for complete example.

---

**Q: How do I debug agent behavior?**

**A:** Enable debug mode:

```yaml
# agents_config.yaml
- name: "my_agent"
  debug: true  # Shows thought process
```

**Output:**
```
[values] {'messages': [HumanMessage('What time is it?')]}
[updates] {'tool_calls': [{'name': 'get_current_time'}]}
[updates] {'tool_messages': [ToolMessage('14:30:45')]}
[values] {'messages': [AIMessage('The time is 2:30 PM')]}
```

See **[docs/DEBUG_GUIDE.md](DEBUG_GUIDE.md)** for complete guide.

---

**Q: How do I run tests?**

**A:** The framework includes 22+ pytest tests:

```powershell
# Run all tests
pytest tests/ -v

# Run specific test file
pytest tests/test_tools.py -v

# Run with coverage
pytest tests/ --cov=. --cov-report=html
```

See **[tests/README.md](tests/README.md)** for complete testing guide.

---

**Q: Can I use this with other frameworks?**

**A:** Yes! The framework is designed to integrate with:

**FastAPI:** ✅ Built-in (`api_server.py`)
**Streamlit:** ✅ Import `AgentFramework` in your Streamlit app
**Gradio:** ✅ Wrap in Gradio interface
**Flask:** ✅ Import and use in Flask routes
**Django:** ✅ Import and use in Django views
**LangServe:** ✅ Compatible with LangChain ecosystem

---

**Q: What if I want to use a different database?**

**A:** The framework uses LangGraph's checkpointer system. Currently supports:
- ✅ PostgreSQL (default)
- ✅ SQLite (for development)
- ✅ In-memory (for testing)

**Switch to SQLite:**
```python
# main.py
from langgraph.checkpoint.sqlite import SqliteSaver

self.checkpointer = SqliteSaver.from_conn_string("./checkpoints.db")
```

**Switch to in-memory:**
```python
from langgraph.checkpoint.memory import MemorySaver

self.checkpointer = MemorySaver()
```

---

**Q: Can I deploy this to the cloud?**

**A:** Yes! Multiple options:

**Docker:**
```dockerfile
FROM python:3.10
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["python", "api_server.py"]
```

**Docker Compose:**
```yaml
services:
  api:
    build: .
    ports:
      - "8000:8000"
    environment:
      - AZURE_OPENAI_ENDPOINT=${AZURE_OPENAI_ENDPOINT}
      - AZURE_OPENAI_API_KEY=${AZURE_OPENAI_API_KEY}
  postgres:
    image: postgres:16-alpine
    # ... database config
```

**Cloud Platforms:**
- ✅ Azure App Service
- ✅ AWS ECS/Fargate
- ✅ Google Cloud Run
- ✅ Heroku
- ✅ Railway
- ✅ Render

---

**Q: How do I handle errors in production?**

**A:** The framework includes error handling:

1. **Logging:**
```env
LOG_LEVEL=ERROR  # Only log errors
LOG_FILE=errors.log  # Save to file
LOG_FORMAT=json  # Structured logging
```

2. **Try-Catch in Tools:**
```python
@tool
def my_tool(param: str) -> str:
    """My custom tool."""
    try:
        # Tool logic
        return result
    except Exception as e:
        return f"❌ Error: {str(e)}"
```

3. **API Error Responses:**
The FastAPI server returns proper HTTP status codes and error messages.

4. **Health Checks:**
```bash
curl http://localhost:8000/health
```

---

**Q: Can I customize the system prompts?**

**A:** Yes! Each agent has its own `system_prompt` in `agents_config.yaml`:

```yaml
- name: "customer_support"
  system_prompt: |
    You are a friendly customer support agent.
    
    Your personality:
    - Warm and empathetic
    - Patient and understanding
    - Solution-oriented
    
    Your capabilities:
    - Answer product questions
    - Troubleshoot issues
    - Escalate complex problems
    
    Always end responses with "Is there anything else I can help with?"
```

See **[docs/SYSTEM_PROMPTS.md](SYSTEM_PROMPTS.md)** for more examples.

---

**Q: Is this framework secure?**

**A:** Security considerations:

**✅ Built-in Security:**
- API keys in `.env` (never in code)
- Human-in-the-loop approval for sensitive actions
- PostgreSQL with authentication
- No hardcoded credentials

**⚠️ You Should Add:**
- API authentication (JWT tokens, API keys)
- Rate limiting
- Input validation
- HTTPS in production
- Database connection encryption
- Regular security audits

---

**Q: Where can I find more examples?**

**A:** Check `tests/examples/` directory:

1. **`example_basic_usage.py`** - Basic framework usage
2. **`example_advanced.py`** - Multi-agent customer support
3. **`example_project_generator.py`** - 4-agent collaboration
4. **`app_with_api.py`** - CLI + API server together

Also see documentation:
- **[docs/DEVELOPER_GUIDE.md](DEVELOPER_GUIDE.md)** - Advanced examples
- **[tests/README.md](tests/README.md)** - Test examples
- **[tests/examples/README.md](tests/examples/README.md)** - Examples guide

---

**Q: How do I contribute or report issues?**

**A:** This is a thesis project. For:
- **Bug reports**: Document the issue with steps to reproduce
- **Feature requests**: Describe the use case and desired behavior
- **Pull requests**: Follow the existing code style and add tests

---

**Q: What's the license?**

**A:** Check the LICENSE file in the project root. This is an educational/thesis project.

---

## 📚 Additional Resources

### Documentation
- **[docs/DEVELOPER_GUIDE.md](DEVELOPER_GUIDE.md)** - Complete API reference
- **[docs/FRAMEWORK_OVERVIEW.md](FRAMEWORK_OVERVIEW.md)** - Quick reference
- **[docs/DEBUG_GUIDE.md](DEBUG_GUIDE.md)** - Debug mode guide
- **[docs/LOGGING_GUIDE.md](LOGGING_GUIDE.md)** - Logging configuration
- **[docs/LLM_PROVIDERS.md](LLM_PROVIDERS.md)** - Multi-LLM setup
- **[docs/API_GUIDE.md](API_GUIDE.md)** - REST API documentation
- **[docs/SYSTEM_PROMPTS.md](SYSTEM_PROMPTS.md)** - Agent personality examples
- **[docs/EXTENSIBILITY.md](EXTENSIBILITY.md)** - Extensibility guide
- **[docs/MIGRATION_V1.md](MIGRATION_V1.md)** - LangChain v1 migration

### Testing
- **[tests/README.md](tests/README.md)** - Complete testing guide
- **[tests/TEST_SUMMARY.md](tests/TEST_SUMMARY.md)** - Test structure
- **[tests/QUICK_COMMANDS.md](tests/QUICK_COMMANDS.md)** - Quick commands
- **[tests/examples/README.md](tests/examples/README.md)** - Examples guide

### External Resources
- **LangChain Documentation**: https://python.langchain.com/
- **LangGraph Documentation**: https://langchain-ai.github.io/langgraph/
- **Azure OpenAI**: https://azure.microsoft.com/en-us/products/ai-services/openai-service
- **FastAPI Documentation**: https://fastapi.tiangolo.com/
- **PostgreSQL Documentation**: https://www.postgresql.org/docs/

---

## 🎓 Summary

### What You Can Do Without Coding

| Task | File to Edit | Coding Required? |
|------|-------------|------------------|
| Add new agent | `agents_config.yaml` | ❌ No |
| Enable/disable agent | `agents_config.yaml` | ❌ No |
| Change agent personality | `agents_config.yaml` (system_prompt) | ❌ No |
| Change agent temperature | `agents_config.yaml` | ❌ No |
| Assign tools to agent | `agents_config.yaml` | ❌ No |
| Enable debug mode | `agents_config.yaml` (per-agent) or `.env` (global) | ❌ No |
| Enable/disable HITL | `.env` | ❌ No |
| Enable/disable MCP | `.env` | ❌ No |
| Configure MCP servers | `mcp_servers.yaml` | ❌ No |
| Change LLM provider | `.env` | ❌ No |
| Configure logging | `.env` | ❌ No |
| Configure API settings | `.env` | ❌ No |
| Add new tool | `tools_registry.py` | ✅ Yes (minimal - just the function) |

### What You've Built

✅ **Production-ready AI agent framework**  
✅ **6 specialized agents** (extensible to unlimited)  
✅ **9+ built-in tools** (extensible)  
✅ **REST API with Swagger UI**  
✅ **Conversation memory** (PostgreSQL checkpointing)  
✅ **Multi-LLM support** (6 providers)  
✅ **Debug mode** (see AI thought process)  
✅ **Professional logging**  
✅ **Human-in-the-loop** safety  
✅ **Comprehensive test suite** (22+ tests)  
✅ **Complete documentation** (12+ guides)  

**You now have a fully extensible, production-ready AI agent framework!** 🎉

---

**Built with ❤️ using LangChain v1 + LangGraph + Azure OpenAI**

*Last updated: November 1, 2025*
*Version: 2.0 - Complete rewrite with LangChain v1, testing, and REST API*
