# 🏭 TMS AI Agent System

**Terminal Management System (TMS) AI Assistant**  
Built with Agent Framework for Siemens Energy - Saudi Aramco Operations

---

## 📋 Overview

This TMS AI Agent system provides intelligent troubleshooting and support for Terminal Management System operations. It uses the **Agent Framework** with a **hierarchical multi-agent architecture** featuring intelligent routing, shared conversation context, and selective human-in-the-loop (HITL) approval for critical actions.

### **What This System Does:**

1. **🔍 Diagnose TMS Issues** - Analyzes preset/bay/channel problems using XML configuration and trace logs
2. **📊 Analyze Trace Logs** - Deep pattern recognition for timeouts, alarms, and invalid events
3. **📧 Draft Support Emails** - Creates professional emails with full content display for review
4. **📤 Send Emails (HITL)** - Sends emails via SMTP with mandatory human approval
5. **🎯 Intelligent Routing** - LLM-based agent selection for optimal task handling

### **Key Features:**

- ✅ **5 Specialized Agents** - Orchestrator + 4 specialist sub-agents
- ✅ **Shared Context** - All agents see the same conversation history
- ✅ **Intelligent Routing** - Automatically selects the best agent for each query
- ✅ **Selective HITL** - Human approval required ONLY for email sending (not drafting)
- ✅ **Complete Transparency** - Full email content displayed before approval
- ✅ **Real SMTP Sending** - Production-ready email delivery with Direct Send

---

## 🏗️ Architecture

```
tms/
├── agents.yaml           # 5-agent hierarchical configuration
├── agents_simple.py      # Main application entry point (CLI/API)
├── tools_registry.py     # TMS tools + services + knowledge base (all-in-one)
├── .env                  # Azure OpenAI credentials (copy from root)
├── data/                 # TMS configuration files
│   └── tms_accuload_list_wcc.xml
└── log/                  # TMS trace log files
    └── Channel_X_autoTraceExport_*.txt
```

### **Hierarchical Multi-Agent System:**

```
tms_diagnostics (Orchestrator)
├── tms_diagnostic_analyzer (Diagnostics Specialist)
├── tms_email_draft (Email Drafter - No HITL)
├── tms_email_send (Email Sender - HITL Required)
└── tms_log_analyzer (Log Analysis Specialist)
```

### **Clean & Simple:**
- ✅ Only **4 files** needed: `agents.yaml`, `agents_simple.py`, `tools_registry.py`, `.env`
- ✅ All dependencies bundled in `tools_registry.py` (no separate services.py, knowledge.py, models.py)
- ✅ Framework handles all the complexity (routing, memory, LLM calls, HITL)
- ✅ Data files (XML, logs) in subdirectories for organization

---

## 🤖 Agents (5-Agent Architecture)

### 1. **tms_diagnostics** (Orchestrator - Default)
- **Role:** Coordinates sub-agents (does NOT perform diagnostics itself)
- **Tools:** `get_current_time` only
- **HITL:** No approval needed
- **Purpose:** Routes requests to specialized sub-agents
- **Example Query:** *"What can you help me with?"*

### 2. **tms_diagnostic_analyzer** (Diagnostics Specialist)
- **Role:** Performs actual diagnostic analysis of preset/bay/channel issues
- **Tools:** `tms_analyzer`, `get_current_time`
- **HITL:** No approval needed
- **Expertise:** Channel mapping, socket timeouts, alarm codes, configuration issues
- **Keywords:** "diagnose", "analyze", "check", "issue at bay X preset Y"
- **Example Query:** *"I have an issue at bay 4 and preset 24"*

### 3. **tms_email_draft** (Email Drafter)
- **Role:** Creates and displays email drafts for review (does NOT send)
- **Tools:** `tms_email_sender` (draft mode), `get_current_time`
- **HITL:** ❌ **No approval needed** - Safe drafting only
- **Context:** Extracts diagnostic info from conversation history automatically
- **Keywords:** "draft", "write", "create", "compose", "prepare" email
- **Example Query:** *"Draft an email about this issue"*
- **Output:** Full email content displayed with subject, body, attachments

### 4. **tms_email_send** (Email Sender)
- **Role:** Sends emails via SMTP (requires approval)
- **Tools:** `tms_email_sender` (send mode), `get_current_time`
- **HITL:** ✅ **Approval REQUIRED** - Critical action protection
- **Context:** Extracts diagnostic info from conversation history automatically
- **SMTP:** siemensenergy-com01i.mail.protection.outlook.com:25 (no auth required)
- **Keywords:** "send", "dispatch", "deliver", "transmit", "mail to support"
- **Example Query:** *"Send this email to the support team"*
- **Process:** User approves → Email sent → Confirmation displayed

### 5. **tms_log_analyzer** (Log Analysis Specialist)
- **Role:** Deep analysis of TMS trace log files
- **Tools:** `tms_log_analyzer_tool`, `get_current_time`
- **HITL:** No approval needed
- **Expertise:** Pattern recognition, timeline analysis, recurring issues
- **Keywords:** "analyze log", "check log", "trace log analysis"
- **Example Query:** *"Analyze the trace log for patterns"*

---

## 🛠️ Tools

All tools are defined in `tools_registry.py`:

| Tool | Purpose | Returns |
|------|---------|---------|
| `tms_analyzer` | Main diagnostics tool - parses preset/bay, finds channel, reads logs, detects issues | Detailed diagnosis with causes & actions |
| `tms_log_analyzer_tool` | Deep log analysis - pattern detection, timeline, severity assessment | Log analysis report with patterns |
| `tms_email_sender` | **Real SMTP email sending** - draft or send professional support emails via SMTP Direct Send | Email content (draft) or send confirmation with delivery status |
| `get_current_time` | Utility - returns current timestamp | Current date/time string |

### **Email Functionality:**

The `tms_email_sender` tool supports two modes:
- ✅ **Draft Mode** (default): Generates complete email content for review (NOT SENT)
  - Full subject line, body, and attachment info displayed
  - No approval required
  - Used by `tms_email_draft` agent
  
- ✅ **Send Mode**: Actually sends email via SMTP with HITL approval
  - Requires keywords: 'send', 'dispatch', 'deliver', 'transmit'
  - Human approval required (HITL middleware)
  - Used by `tms_email_send` agent
  - Automatically attaches trace log files
  - Shows delivery confirmation or detailed error messages

**SMTP Configuration:**
```python
Server: siemensenergy-com01i.mail.protection.outlook.com
Port: 25
Method: SMTP Direct Send (no authentication required)
From: tms.support.agent@siemens-energy.com
To: mohammad.alam@siemens-energy.com
CC: mohammad.alam@siemens-energy.com
```

### **Integrated Components:**

The `tools_registry.py` file includes:
- **TMS Services** (`TMS` class) - File operations, XML parsing, log reading
- **Knowledge Base** (`TMSKnowledge` class) - System info, procedures, alarm codes
- **Tool Functions** - LangChain `@tool` decorated functions
- **SMTP Module** - Real email sending via `smtplib` and `email.mime`

---

## 🎯 Intelligent Routing

The system uses **LLM-based agent selection** to automatically route queries to the best agent:

### **How Routing Works:**

1. **User Query** → Router analyzes intent
2. **LLM Decision** → Compares query against agent descriptions
3. **Agent Selection** → Routes to best matching agent
4. **Temperature 0.0** → Consistent, deterministic routing

### **Routing Examples:**

| Query | Selected Agent | Reason |
|-------|---------------|--------|
| "I have issue at bay 9 preset 9" | `tms_diagnostic_analyzer` | Keywords: issue, bay, preset |
| "Draft an email about this" | `tms_email_draft` | Keyword: draft (no HITL) |
| "Send email to support" | `tms_email_send` | Keyword: send (HITL required) |
| "Analyze the trace log" | `tms_log_analyzer` | Keywords: analyze, log |
| "What can you do?" | `tms_diagnostics` | General/orchestration query |

### **Context Sharing:**

All agents share the **same conversation thread**, enabling:
- ✅ Email agents see diagnostic results automatically
- ✅ No need to repeat bay/preset/issue information
- ✅ Seamless multi-agent collaboration
- ✅ Complete conversation history across agent switches

---

## 🛡️ Human-in-the-Loop (HITL)

### **Selective Approval System:**

| Agent | HITL Enabled | Reason |
|-------|-------------|--------|
| `tms_diagnostics` | ❌ No | Safe orchestration only |
| `tms_diagnostic_analyzer` | ❌ No | Read-only diagnostics |
| `tms_email_draft` | ❌ No | Safe drafting (no sending) |
| `tms_email_send` | ✅ **YES** | Critical action (actual email sending) |
| `tms_log_analyzer` | ❌ No | Read-only log analysis |

### **HITL Workflow:**

```
User: "Send this email to support"
↓
Router: Selects tms_email_send agent
↓
HITL Middleware: Intercepts request
↓
[HITL] WARNING - Agent wants to: Process message: 'send this email to support'
[HITL] Using tool: Agent: tms_email_send
[HITL] Approve? (y/n): _
↓
User types 'y' → Email sent ✅
User types 'n' → Request rejected ❌
```

### **Configuration:**

HITL is controlled in `agents.yaml`:
```yaml
- name: tms_email_send
  hitl: true  # ← Approval required
```

Global HITL setting in `.env`:
```bash
HITL_ENABLED=true
```

---

## 🚀 Quick Start

### **1. Setup Environment**

```powershell
# Navigate to TMS directory
cd tms

# Copy .env from root (or create new one)
cp ../.env .env

# Verify .env has Azure OpenAI credentials:
# AZURE_OPENAI_API_KEY=your_key_here
# AZURE_OPENAI_ENDPOINT=your_endpoint_here
# AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4o
# AZURE_OPENAI_API_VERSION=2024-06-01
# HITL_ENABLED=true
```

### **2. Verify Data Files**

```powershell
# Check XML configuration file exists
ls data/tms_accuload_list_wcc.xml

# Check trace log file exists
ls log/Channel_*
```

### **3. Run the Application**

```powershell
# Interactive CLI mode (default)
python agents_simple.py

# Web API server with Swagger UI
python agents_simple.py --api

# Help
python agents_simple.py --help
```

### **4. Using the CLI**

```powershell
# Start interactive chat
python agents_simple.py

# Example conversation:
👤 You: I have an issue at bay 9 and preset 9
🤖 [tms_diagnostic_analyzer]: Full diagnosis with causes and actions...

👤 You: draft an email for this issue
🤖 [tms_email_draft]: Complete email draft displayed...

👤 You: send this email
[HITL] Approve? (y/n): y
🤖 [tms_email_send]: Email sent successfully!
```

### **4. Using the Web API**

When running in API mode (`--api`):

```powershell
python agents_simple.py --api
```

**Access Points:**
- 🌐 **API Base:** http://localhost:8000
- 📖 **Swagger UI (Interactive Docs):** http://localhost:8000/docs
- 📄 **ReDoc (Alternative Docs):** http://localhost:8000/redoc
- ❤️ **Health Check:** http://localhost:8000/health
- 📋 **List Agents:** http://localhost:8000/agents

**Example API Calls:**

```bash
# Health check
curl http://localhost:8000/health

# List available agents
curl http://localhost:8000/agents

# Chat with TMS agent
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "I have an issue at bay 4 and preset 24",
    "thread_id": "user_session_001"
  }'

# Stream response (Server-Sent Events)
curl http://localhost:8000/chat/stream \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Check preset 2 bay 3",
    "thread_id": "user_session_001"
  }'
```

**API Features:**
- ✅ RESTful endpoints with JSON
- ✅ Conversation thread management (shared across agents)
- ✅ Streaming responses (SSE)
- ✅ CORS enabled for web integration
- ✅ Automatic request validation
- ✅ Interactive Swagger UI documentation
- ✅ HITL approval in API mode (configurable)

```powershell
python agents.py --api
```

**Access Points:**
- 🌐 **API Base:** http://localhost:8000
- 📖 **Swagger UI (Interactive Docs):** http://localhost:8000/docs
- 📄 **ReDoc (Alternative Docs):** http://localhost:8000/redoc
- ❤️ **Health Check:** http://localhost:8000/health
- 📋 **List Agents:** http://localhost:8000/agents

**Example API Calls:**

```bash
# Health check
curl http://localhost:8000/health

# List available agents
curl http://localhost:8000/agents

# Chat with TMS agent
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "I have an issue at bay 4 and preset 24",
    "thread_id": "user_session_001"
  }'

# Stream response (Server-Sent Events)
curl http://localhost:8000/chat/stream \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Check preset 2 bay 3",
    "thread_id": "user_session_001"
  }'
```

**API Features:**
- ✅ RESTful endpoints with JSON
- ✅ Conversation thread management
- ✅ Streaming responses (SSE)
- ✅ CORS enabled for web integration
- ✅ Automatic request validation
- ✅ Interactive Swagger UI documentation

---

## 💬 Usage Examples

### **Example 1: Complete Workflow (Diagnose → Draft → Send)**

```
👤 You: I have an issue at bay 9 and preset 9

🤖 [tms_diagnostic_analyzer]:
**Diagnosis for Bay 9 and Preset 9:**

**Issue Identified:** Socket timeout detected on Channel 01.
This indicates a communication timeout between the TMS server and the preset controller.

**Root Cause:**
- Network connectivity issue
- Preset controller may be powered off
- Firewall blocking port 502 (Modbus protocol)
- Possible cable disconnection

**Recommended Actions:**
1. Ping the preset controller to check its network connectivity
2. Verify if port 502 is open and accessible
3. Inspect all physical connections to ensure cables are properly connected
4. Check the preset controller display for any error messages

---

👤 You: draft an email for this issue

🤖 [tms_email_draft]:
Here is the email draft for your review:

📧 **EMAIL DRAFT (Ready for Review - NOT SENT)**

**From:** tms.support.agent@siemens-energy.com
**To:** mohammad.alam@siemens-energy.com
**CC:** mohammad.alam@siemens-energy.com
**Subject:** TMS Alert - Support Required for Bay 9, Preset 9

**Body:**
Dear Siemens Energy Support Team,

EXECUTIVE SUMMARY:
We are experiencing a TMS (Terminal Management System) issue that requires your immediate attention.

ISSUE DETAILS:
- Location: Bay 9, Preset 9
- Reported: 2025-11-03 08:01:18
- Severity: Medium (Operational impact)

TECHNICAL DETAILS:
- System: Terminal Management System (TMS AccuLoad)
- Affected Components: Preset Controller 9, Bay 9
- Issue: Socket Timeout on channel 01
- Root cause: Network connectivity issue, preset controller powered off,
  firewall blocking port 502, or cable disconnection

TROUBLESHOOTING PERFORMED:
1. Initial TMS diagnostics completed
2. Trace log file generated and attached
3. Configuration verified
4. Basic connectivity checks performed

RECOMMENDED ACTIONS:
1. Review attached trace log file
2. Analyze alarm codes and error messages
3. Check preset controller configuration
4. Verify network connectivity and Modbus communication

ATTACHMENTS:
- Trace log file: Channel_3_autoTraceExport_7312025_5-20-29_PM.txt

URGENCY:
Please review and respond within 4 hours.

Best regards,
Saudi Aramco Operations Team

📎 **Attachment:** Channel_3_autoTraceExport_7312025_5-20-29_PM.txt

Would you like me to send this email, or would you like to make any changes?

---

👤 You: send this email to the support team

WARNING - Agent wants to: Process message: 'send this email to the support team'
WARNING - Using tool: Agent: tms_email_send
[HITL] Approve? (y/n): y

INFO - Decision: APPROVED

🤖 [tms_email_send]:
✅ **EMAIL SENT SUCCESSFULLY!**

**From:** tms.support.agent@siemens-energy.com
**To:** mohammad.alam@siemens-energy.com
**CC:** mohammad.alam@siemens-energy.com
**Subject:** TMS Alert - Support Required for Bay 9, Preset 9
**Attachment:** Channel_3_autoTraceExport_7312025_5-20-29_PM.txt
**Sent via:** siemensenergy-com01i.mail.protection.outlook.com:25

📧 Email has been delivered to the support team.
```

### **Example 2: Direct Diagnosis**

```
👤 You: diagnose preset 24 bay 4

🤖 [tms_diagnostic_analyzer]:
✅ TMS ANALYSIS RESULTS

Configuration:
- Preset ID: 24
- Bay Number: 4
- Channel: 3

Log File: Channel_3_autoTraceExport_7312025_5-20-29_PM.txt

ALARMS DETECTED:
🚨 Alarm 2001: Overfill Protection Triggered
   Severity: HIGH
   Action: Stop loading immediately

Recommendation:
⚠️ Review alarms and take corrective action

Available Commands:
- trlist -c3 -a : Get full trace log
- tmsstatus : Check system status
- tmsreset -c3 : Reset channel (requires supervisor)
```

### **Example 3: Log Analysis**

```
👤 You: analyze the trace log

🤖 [tms_log_analyzer]:
📊 TMS LOG ANALYSIS

Log File: Channel_3_autoTraceExport_7312025_5-20-29_PM.txt
Size: 45231 characters
Analyzed: 2025-11-03 10:15:22

PATTERN DETECTION:
- Socket Timeouts: 3 🔴
- Invalid Events: 1 ⚠️
- Alarm Codes: 2 🚨

ISSUE SEVERITY:
🔴 CRITICAL - Multiple issues detected

RECOMMENDATIONS:
- Investigate network connectivity and preset controller status
- Review operational procedures with operators
- Check alarm codes and take corrective actions
```

### **Example 4: HITL Rejection**

```
👤 You: send email about the timeout

WARNING - Agent wants to: Process message: 'send email about the timeout'
[HITL] Approve? (y/n): n

INFO - Decision: REJECTED

🤖 System: Request rejected by human supervisor.

👤 You: Actually, draft it first

🤖 [tms_email_draft]: [Shows complete draft without approval]
```

---

## 🔧 How It Works

### **1. Framework Integration**

The TMS agents leverage the **Agent Framework** which provides:
- ✅ **Intelligent Routing** - LLM-based agent selection for optimal task matching
- ✅ **Shared Context** - All agents access the same conversation thread
- ✅ **Tool Integration** - Seamlessly calls TMS tools during conversation
- ✅ **Memory Management** - PostgreSQL-based conversation persistence
- ✅ **LLM Orchestration** - Handles all Azure OpenAI API calls
- ✅ **HITL Middleware** - Selective human approval for critical actions
- ✅ **Error Handling** - Graceful fallbacks and retries

### **2. Multi-Agent Workflow**

```
User Query
    ↓
Router (LLM-based)
    ↓
Agent Selection (temperature=0.0)
    ↓
┌─────────────────────────────────────────┐
│ Selected Agent (with shared context)    │
│   ↓                                     │
│ Tool Call(s)                            │
│   ↓                                     │
│ HITL Check (if enabled)                 │
│   ↓                                     │
│ LLM Response Generation                 │
└─────────────────────────────────────────┘
    ↓
Response to User (context saved)
```

### **3. Context Sharing Mechanism**

**Problem Solved:** Email agent needs diagnostic info without asking user again

**Solution:** Shared thread_id across all agents

```python
# Old (broken): Each agent had separate thread
thread_id = f"{session_id}_{agent_name}"  # ❌ Isolated

# New (working): All agents share same thread
thread_id = f"{session_id}"  # ✅ Shared context
```

**Result:**
- Diagnostic agent finds issue → Saves to thread
- User asks for email → Router switches to email agent
- Email agent reads same thread → Sees diagnostic results
- No need to ask user for information again ✅

### **4. Routing Logic**

**Agent Selection Process:**

```python
routing_prompt = """
You are a routing assistant.
Available agents:
- tms_diagnostic_analyzer: "diagnose", "analyze", "check", "issue at bay X"
- tms_email_draft: "draft", "write", "create", "compose" email
- tms_email_send: "send", "dispatch", "deliver", "transmit" email
- tms_log_analyzer: "analyze log", "trace log", "log patterns"

User query: "{query}"
Respond with ONLY the agent name.
"""
```

**Router uses LLM** to match query intent with agent capabilities

### **5. HITL Implementation**

**Middleware Interception:**

```python
# Before agent processing
if agent.hitl_enabled:
    print(f"[HITL] Agent wants to: {action}")
    approval = input("[HITL] Approve? (y/n): ")
    if approval.lower() != 'y':
        return "Request rejected by human supervisor"

# Continue with agent processing
```

**Configured per-agent in agents.yaml:**
```yaml
- name: tms_email_send
  hitl: true  # Only this agent requires approval
```
                                        Reads XML config
                                        Finds channel number
                                        Reads trace log
                                        Detects patterns
                                              ↓
                                        Returns diagnosis
                                              ↓
                                        Agent formats response
                                              ↓
                                        Back to user
```

### **3. Tool Execution Flow**

```python
# User: "I have an issue at bay 4 and preset 24"

# 1. Framework routes to tms_diagnostics agent
# 2. Agent calls tms_analyzer tool
def tms_analyzer(query: str) -> str:
    # Parse: preset_id=24, bay_nr=4
    preset_id, bay_nr = parse_query(query)
    
    # Find channel from XML
    channel_no = TMS.find_channel_by_preset("24", "4")  # Returns "3"
    
    # Read trace log
    log_content = TMS.read_existing_log()
    
    # Detect issues
    if "Socket TimeOut" in log_content:
        return socket_timeout_guidance()
    elif "ALARM" in log_content:
        return alarm_analysis()
    else:
        return normal_analysis()

# 3. Framework receives tool result
# 4. Agent uses LLM to format final response
# 5. User receives friendly, actionable diagnosis
```

---

## 📊 System Components

### **TMS Services (`TMS` class)**

```python
class TMS:
    """File and system operations"""
    
    @staticmethod
    def find_channel_by_preset(preset_id, bay_nr):
        """Parses XML to find channel number"""
        # Searches tms_accuload_list_wcc.xml
        # Returns channel_no or None
    
    @staticmethod
    def read_existing_log():
        """Reads trace log file"""
        # Tries multiple encodings
        # Returns log content as string
    
    @staticmethod
    def get_config_info():
        """Returns current configuration"""
        # Platform, paths, file status
```

### **Knowledge Base (`TMSKnowledge` class)**

```python
class TMSKnowledge:
    """TMS domain knowledge"""
    
    @staticmethod
    def get_system_info():
        """System components and ranges"""
    
    @staticmethod
    def get_operational_procedure(name):
        """Step-by-step procedures"""
    
    @staticmethod
    def get_alarm_info(alarm_code):
        """Alarm descriptions and actions"""
    
    @staticmethod
    def get_issue_guidance(issue_type, **kwargs):
        """Guidance for known issues"""
```

---

## 🎯 Design Principles

### **1. Framework-First Approach**
- Let the **Agent Framework** handle:
  - ✅ Agent selection (smart routing)
  - ✅ Tool orchestration
  - ✅ LLM API calls
  - ✅ Memory management
  - ✅ Error handling

- TMS code focuses on:
  - ✅ Domain logic (TMS-specific operations)
  - ✅ Tool implementations
  - ✅ Knowledge base

### **2. Simplicity**
- **4 files only**: `agents.yaml`, `agents.py`, `tools_registry.py`, `.env`
- All dependencies bundled (no separate services, knowledge, models files)
- Clean separation: Config (YAML) → Application (agents.py) → Tools (tools_registry.py)

### **3. Maintainability**
- **Single source of truth**: Each component has one clear responsibility
- **Framework abstracts complexity**: Don't reinvent routing, memory, LLM handling
- **Easy to extend**: Add new agents in YAML, new tools in tools_registry.py

### **4. Production-Ready**
- **Error handling**: Try/except with fallbacks
- **Multiple encodings**: Handles various log file formats
- **Path detection**: Auto-detects Windows/Linux environments
- **Human-in-the-Loop**: Draft mode for email approval before sending

---

## 🔍 Key Decisions

### **Why Agent Framework?**

**Before (Custom Implementation):**
```python
# Complex custom routing logic
if "email" in query or "send" in query:
    agent = tms_email_agent
elif "log" in query or "analyze" in query:
    agent = tms_log_agent
else:
    agent = tms_diagnostics_agent

# Manual tool calling
result = tms_analyzer(preset_id, bay_nr)

# Manual LLM API calls
response = openai.ChatCompletion.create(...)

# Manual memory management
conversation_history.append(...)
```

**After (Framework-Powered):**
```python
# Framework handles everything!
response = await framework.run_conversation(query, session_id)
```

The framework:
- ✅ Uses LLM to understand query intent
- ✅ Selects appropriate agent based on descriptions
- ✅ Automatically calls tools when needed
- ✅ Manages conversation history
- ✅ Formats final response

### **Why All-in-One tools_registry.py?**

**Benefits:**
1. **Single file to understand** - All TMS logic in one place
2. **No circular imports** - Simple linear dependencies
3. **Easy deployment** - Just copy one file
4. **Framework requirement** - Tools must be in `tools_registry.py` (or imported there)

**Structure:**
```python
# TMS Services (File operations)
class TMS:
    ...

# Knowledge Base (Domain knowledge)
class TMSKnowledge:
    ...

# Tools (Agent-callable functions)
@tool
def tms_analyzer(query: str) -> str:
    # Uses TMS and TMSKnowledge
    ...

# Export
def get_tms_tools() -> List:
    return [tms_analyzer, tms_log_analyzer_tool, tms_email_sender, get_current_time]
```

---

## ✨ Key Benefits

### **1. No Information Re-entry**
- ❌ **Before:** User had to repeat bay/preset/issue to email agent
- ✅ **After:** Diagnostic info flows automatically via shared context

### **2. Selective Approval**
- ❌ **Before:** Single agent required approval for all email tasks
- ✅ **After:** Draft emails freely, approve only when sending

### **3. Complete Transparency**
- ❌ **Before:** Email content hidden, user blind to what's being sent
- ✅ **After:** Full email displayed before approval prompt

### **4. Intelligent Routing**
- ❌ **Before:** Fixed agent, no flexibility
- ✅ **After:** LLM automatically selects best agent for each query

### **5. Specialized Expertise**
- ❌ **Before:** Generalist agent trying to do everything
- ✅ **After:** 5 specialized agents, each expert in their domain

---

## 💡 Best Practices

### **For Operators:**

1. **Start with Diagnostics**
   ```
   "I have issue at bay X preset Y"
   ```
   Get full diagnosis before taking action

2. **Review Draft First**
   ```
   "draft an email" → Review content → "send it"
   ```
   Always check email content before sending

3. **Use Natural Language**
   ```
   ✅ "check bay 9"
   ✅ "what's wrong with preset 5?"
   ✅ "send this to support"
   ```
   No need for exact keywords

4. **One Session, Multiple Tasks**
   ```
   1. "diagnose bay 9 preset 9"
   2. "draft email"
   3. "send email"
   ```
   Context flows automatically through conversation

### **For Administrators:**

1. **Configure HITL per Agent**
   ```yaml
   # agents.yaml
   - name: safe_agent
     hitl: false  # No approval
   
   - name: critical_agent
     hitl: true   # Requires approval
   ```

2. **Monitor Routing Decisions**
   ```bash
   # Enable debug logging
   INFO - Agent: tms_diagnostic_analyzer selected
   ```
   Verify correct agent selection

3. **Customize Agent Descriptions**
   ```yaml
   description: "Your keywords here: analyze, check, diagnose"
   ```
   Improves routing accuracy

4. **Test Email Sending**
   ```python
   # Test SMTP connectivity
   python -c "import smtplib; smtplib.SMTP('siemensenergy-com01i.mail.protection.outlook.com', 25)"
   ```

---

## 🧪 Testing

```powershell
# Test complete workflow
python agents_simple.py

# Test conversation:
# 1. "I have issue at bay 9 preset 9" → Should route to diagnostic_analyzer
# 2. "draft email" → Should route to email_draft (no approval)
# 3. "send email" → Should route to email_send (approval required)

# Test routing explicitly
python -c "
from main import AgentFramework
fw = AgentFramework('agents.yaml')
# Check agent descriptions for routing keywords
"

# Test SMTP connection
python -c "
import smtplib
server = smtplib.SMTP('siemensenergy-com01i.mail.protection.outlook.com', 25)
print('SMTP connection OK')
server.quit()
"
```

---

## 📦 Dependencies

### **Python Packages:**
- `langchain-core` - Tool decorators
- `langchain-openai` (via framework) - Azure OpenAI integration
- Standard library: `xml.etree.ElementTree`, `re`, `os`, `datetime`, `pathlib`, `smtplib`

### **Framework Requirements:**
- `main.py` (Agent Framework) - Must be in parent directory
- `.env` with Azure OpenAI credentials
- PostgreSQL database (for conversation memory)

---

## 🔐 Security

- **Environment Variables**: All credentials in `.env` (never hardcoded)
- **Email Safety**: Draft mode default + HITL for sending
- **SMTP**: Uses Direct Send (no password storage)
- **Selective HITL**: Approval only for critical actions (email sending)
- **.gitignore**: Ensures `.env` files are never committed
- **Context Isolation**: Each user session has separate thread_id

---

## � Troubleshooting

### **Issue: Agent asks for information already provided**

**Cause:** Context not shared between agents

**Fix:** Ensure `main.py` uses shared thread_id:
```python
"thread_id": f"{session_id}"  # Not: f"{session_id}_{agent_name}"
```

### **Issue: HITL not working**

**Cause:** HITL disabled or agent misconfigured

**Fix:**
1. Check `.env`: `HITL_ENABLED=true`
2. Check `agents.yaml`: agent has `hitl: true`
3. Restart application

### **Issue: Email not sending**

**Cause:** SMTP connection failed

**Fix:**
1. Test SMTP: `telnet siemensenergy-com01i.mail.protection.outlook.com 25`
2. Check firewall allows port 25
3. Verify sender domain: `@siemens-energy.com`

### **Issue: Wrong agent selected**

**Cause:** Router couldn't match query to agent

**Fix:**
1. Use clearer keywords: "diagnose bay X", "send email"
2. Update agent descriptions in `agents.yaml`
3. Check router temperature is 0.0 for consistency

---

## 🚧 Future Enhancements

1. **Multi-language Support**: Arabic for Saudi Aramco operators
2. **Real-time Monitoring**: Live dashboard for TMS status
3. **Predictive Analytics**: ML model for issue prediction before failure
4. **Voice Interface**: Speech-to-text for hands-free operation
5. **Mobile App**: iOS/Android interface for field operations
6. **Automated Escalation**: Auto-send critical alerts without HITL
7. **Knowledge Base Integration**: Link to TMS manuals and procedures

---

## 📚 Learn More

- **Agent Framework**: See `/docs/FRAMEWORK_OVERVIEW.md` in root directory
- **Tool Development**: See `/docs/EXTENSIBILITY.md` for creating custom tools
- **API Integration**: See `/docs/API_GUIDE.md` for REST API usage

---

## 👥 Support

**Siemens Energy - Digital Services**  
📧 Email: tms.support.agent@siemens-energy.com  
📞 Phone: +966 (0) 911 654-0

---

## 📄 License

© 2025 Siemens Energy - Proprietary and Confidential

---

**Built with ❤️ using Agent Framework**
