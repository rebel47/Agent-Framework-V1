"""
TMS Tools Registry
==================
All TMS-specific tools for Terminal Management System diagnostics.

Usage in agents.yaml:
    tool_imports:
      - "tms.tools_registry.tms_analyzer"
      - "tms.tools_registry.tms_email_sender"
      - "tms.tools_registry.get_current_time"

Import the decorator from framework:
    from main import tool
"""

from main import tool
from typing import Optional, Dict, List
from datetime import datetime
from pathlib import Path
import sys
import os
import xml.etree.ElementTree as ET
import re
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders


# ============================================================================
# TMS SERVICES - File and System Operations
# ============================================================================

class TMS:
    """TMS filesystem and system utility methods"""
    
    @staticmethod
    def _get_base_path():
        """Detect if running in Docker (Linux) or Windows and return appropriate base path"""
        if sys.platform.startswith('linux') or os.path.exists('/app'):
            return Path('/app')
        else:
            current_file = Path(__file__)
            tms_dir = current_file.parent
            return tms_dir
    
    _BASE_PATH = _get_base_path()
    XML_FILE_PATH = str(_BASE_PATH / "data" / "tms_accuload_list_wcc.xml")
    LOG_FILE_PATH = str(_BASE_PATH / "log" / "Channel_3_autoTraceExport_7312025_5-20-29_PM.txt")
    
    @staticmethod
    def get_config_info():
        """Get current path configuration"""
        return {
            "platform": sys.platform,
            "base_path": str(TMS._BASE_PATH),
            "xml_path": TMS.XML_FILE_PATH,
            "log_path": TMS.LOG_FILE_PATH,
            "xml_exists": os.path.exists(TMS.XML_FILE_PATH),
            "log_exists": os.path.exists(TMS.LOG_FILE_PATH)
        }
    
    @staticmethod
    def find_channel_by_preset(preset_id: str, bay_nr: str) -> Optional[str]:
        """Find channel_no using preset id and bay_nr from XML file"""
        try:
            tree = ET.parse(TMS.XML_FILE_PATH)
            root = tree.getroot()
            
            for channel in root.findall('CHANNEL'):
                channel_no = channel.get('channel_no')
                for preset in channel.findall('PRESET'):
                    if preset.get('id') == preset_id and preset.get('bay_nr') == bay_nr:
                        return channel_no
            return None
        except Exception as e:
            print(f"Error reading XML file: {e}")
            return None
    
    @staticmethod
    def read_existing_log() -> str:
        """Read the existing log file with multiple encoding attempts"""
        encodings = ['utf-8', 'latin-1', 'cp1252', 'iso-8859-1']
        
        for encoding in encodings:
            try:
                with open(TMS.LOG_FILE_PATH, 'r', encoding=encoding) as f:
                    return f.read()
            except (UnicodeDecodeError, FileNotFoundError):
                continue
        return ""
    
    @staticmethod
    def get_current_timestamp() -> str:
        """Get current timestamp in readable format"""
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ============================================================================
# TMS KNOWLEDGE BASE - All TMS Information
# ============================================================================

class TMSKnowledge:
    """Complete TMS knowledge base"""
    
    @staticmethod
    def get_system_info():
        """Get TMS system information"""
        return {
            "name": "Terminal Management System",
            "purpose": "oil & gas terminal loading operations, tankfarm automation",
            "components": {
                "preset_controllers": {
                    "description": "Control loading operations at specific bays",
                    "range": "1-10"
                },
                "bays": {
                    "description": "Physical loading positions",
                    "range": "1-20"
                }
            }
        }
    
    @staticmethod
    def get_operational_procedure(procedure_name: str) -> List[str]:
        """Get operational procedures"""
        procedures = {
            "loading_sequence": [
                "1. Driver/Operator swipes card at preset",
                "2. System validates credentials and allocation",
                "3. Preset displays product and quantity",
                "4. Operator connects loading arm",
                "5. Press START button to begin loading",
                "6. System monitors flow rate and quantity",
                "7. Automatic stop at preset quantity",
                "8. Print ticket and disconnect"
            ]
        }
        return procedures.get(procedure_name, [])
    
    @staticmethod
    def get_command_help(command: str) -> Dict:
        """Get command help information"""
        commands = {
            "trlist": {
                "purpose": "Extract trace logs for specific channel",
                "syntax": "trlist -c{channel_number} -a",
                "example": "trlist -c3 -a > channel3_trace.txt"
            }
        }
        return commands.get(command, {})
    
    @staticmethod
    def get_issue_guidance(issue_type: str, **kwargs) -> str:
        """Get guidance for known issues"""
        issues = {
            "no_channel_found": """⚠️ Configuration Issue Detected:

No channel mapping found for Preset {preset_id}, Bay {bay_nr}

DIAGNOSTIC STEPS:
1. **Verify Configuration**: Check XML file
2. **Check Physical Setup**: Confirm preset/bay mapping at HMI
3. **Manual Check**: Run command to verify

COMMON CAUSES:
- Bay not configured for this preset
- Missing XML configuration entry
- Preset controller offline""",
            
            "socket_timeout": """🔌 SOCKET TIMEOUT DETECTED - Channel {channel_no}

**Issue:** Communication timeout between TMS server and preset controller

**Possible Causes:**
- Network connectivity issue
- Preset controller powered off
- Firewall blocking port 502 (Modbus)
- Cable disconnection

**IMMEDIATE CHECKS:**
1. Ping preset controller
2. Check port 502 connectivity
3. Verify physical connections
4. Check preset controller display""",
            
            "invalid_event": """⚠️ INVALID EVENT SEQUENCE DETECTED

**Event Type:** {event_type}
**Channel:** {channel_no}

**Issue:** Improper operational sequence detected

**TO RESOLVE:**
1. Reset the preset controller
2. Clear pending events
3. Start operation from beginning"""
        }
        
        template = issues.get(issue_type, "Unknown issue type")
        return template.format(**kwargs)
    
    @staticmethod
    def get_alarm_info(alarm_code: str) -> Dict:
        """Get alarm code information"""
        alarms = {
            "1001": {"description": "Emergency Stop Activated", "severity": "critical", "action": "Check E-Stop buttons"},
            "2001": {"description": "Overfill Protection Triggered", "severity": "high", "action": "Stop loading immediately"},
            "3001": {"description": "Flow Rate Exceeded", "severity": "medium", "action": "Reduce flow rate"},
            "4001": {"description": "Card Reader Error", "severity": "low", "action": "Check card reader"}
        }
        return alarms.get(alarm_code, {"description": "Unknown alarm", "severity": "unknown", "action": "Contact support"})


# ============================================================================
# TMS TOOLS - Agent Tools
# ============================================================================

@tool
def tms_analyzer(query: str) -> str:
    """
    Analyze TMS (Terminal Management System) issues for preset, bay, and channel problems.
    
    This tool:
    1. Parses preset_id and bay_nr from the query
    2. Finds the corresponding channel using XML configuration
    3. Reads trace log files for the channel
    4. Detects known issues (socket timeout, invalid events, alarms)
    5. Provides diagnosis with possible causes and recommended actions
    
    Args:
        query: Natural language query containing preset and bay information
               Examples: "preset 2 bay 3", "check preset_id=1 bay_nr=2", 
                        "issue at bay 4 preset 24"
    
    Returns:
        Detailed diagnosis with channel mapping, issues, causes, and actions
    """
    # Parse preset_id and bay_nr from query
    patterns = [
        r'preset[_\s]*id[=\s:]*(\d+).*?bay[_\s]*nr[=\s:]*(\d+)',
        r'preset[=\s:]*(\d+).*?bay[=\s:]*(\d+)',
        r'bay[=\s:]*(\d+).*?preset[=\s:]*(\d+)',
        r'(\d+).*?(\d+)'
    ]
    
    preset_id, bay_nr = None, None
    for pattern in patterns:
        match = re.search(pattern, query.lower())
        if match:
            if 'bay.*?preset' in pattern:
                bay_nr, preset_id = match.group(1), match.group(2)
            else:
                preset_id, bay_nr = match.group(1), match.group(2)
            break
    
    if not preset_id or not bay_nr:
        return """❌ Could not parse preset_id and bay_nr from query.

Please provide TMS issue information in one of these formats:
- "preset 2 bay 3"
- "preset_id=2 bay_nr=3"
- "issue at bay 4 preset 24"
- "check preset 1 bay 5"

Example: "I have an issue at bay 4 and preset 24"
"""
    
    # Find channel number
    channel_no = TMS.find_channel_by_preset(preset_id, bay_nr)
    
    if not channel_no:
        return TMSKnowledge.get_issue_guidance(
            "no_channel_found",
            preset_id=preset_id,
            bay_nr=bay_nr
        ) + f"\n\n{TMSKnowledge.get_system_info()['purpose']}"
    
    # Read trace log
    log_content = TMS.read_existing_log()
    
    if not log_content:
        return f"""❌ Could not read trace log for channel {channel_no}.

**Configuration Info:**
{TMS.get_config_info()}

**Recommended Actions:**
1. Check if log file exists
2. Verify file permissions
3. Run trlist command to generate new log"""
    
    # Check for known issues
    if "Socket TimeOut" in log_content or "timeout" in log_content.lower():
        return TMSKnowledge.get_issue_guidance("socket_timeout", channel_no=channel_no, preset_id=preset_id, bay_nr=bay_nr)
    
    if "Invalid Event" in log_content:
        event_match = re.search(r'Invalid Event:\s*(\w+)', log_content)
        event_type = event_match.group(1) if event_match else "Unknown"
        return TMSKnowledge.get_issue_guidance("invalid_event", event_type=event_type, channel_no=channel_no, timestamp=TMS.get_current_timestamp())
    
    # Check for alarms
    alarm_pattern = r'ALARM[:\s]*(\d{4})'
    alarms_found = re.findall(alarm_pattern, log_content)
    alarm_analysis = ""
    
    if alarms_found:
        alarm_info_list = []
        for alarm_code in set(alarms_found):
            alarm_info = TMSKnowledge.get_alarm_info(alarm_code)
            alarm_info_list.append(
                f"🚨 **Alarm {alarm_code}**: {alarm_info['description']}\n"
                f"   Severity: {alarm_info['severity'].upper()}\n"
                f"   Action: {alarm_info['action']}"
            )
        alarm_analysis = "**ALARMS DETECTED:**\n\n" + "\n\n".join(alarm_info_list)
    
    # Return analysis
    return f"""✅ **TMS ANALYSIS RESULTS**

**Configuration:**
- Preset ID: {preset_id}
- Bay Number: {bay_nr}
- Channel: {channel_no}

**Log File:** {TMS.LOG_FILE_PATH.split(os.sep)[-1]}

{alarm_analysis if alarm_analysis else '✅ No alarms detected in log file'}

**Log Content Summary:**
{log_content[:2000]}...

**Recommendation:**
{'⚠️ Review alarms and take corrective action' if alarm_analysis else '✅ System appears operational - no critical issues detected'}

**Available Commands:**
- trlist -c{channel_no} -a : Get full trace log
- tmsstatus : Check system status
- tmsreset -c{channel_no} : Reset channel (requires supervisor)
"""


@tool
def tms_log_analyzer_tool(log_file_path: Optional[str] = None) -> str:
    """
    Analyze TMS trace log file for patterns, errors, and issues.
    
    This tool performs deep analysis of TMS trace logs:
    1. Parses log file for events and timestamps
    2. Detects patterns (timeouts, alarms, invalid events)
    3. Identifies recurring issues
    4. Provides timeline of critical events
    
    Args:
        log_file_path: Optional path to specific log file (defaults to current log)
    
    Returns:
        Detailed log analysis with patterns, timeline, and recommendations
    """
    log_path = log_file_path or TMS.LOG_FILE_PATH
    log_content = TMS.read_existing_log()
    
    if not log_content:
        return f"❌ Could not read log file: {log_path}"
    
    # Analyze patterns
    analysis = f"""📊 **TMS LOG ANALYSIS**

**Log File:** {os.path.basename(log_path)}
**Size:** {len(log_content)} characters
**Analyzed:** {TMS.get_current_timestamp()}

**PATTERN DETECTION:**
"""
    
    # Count patterns
    timeout_count = log_content.count("Socket TimeOut") + log_content.lower().count("timeout")
    invalid_event_count = log_content.count("Invalid Event")
    alarm_count = len(re.findall(r'ALARM[:\s]*\d{4}', log_content))
    
    analysis += f"""
- Socket Timeouts: {timeout_count} {'🔴' if timeout_count > 0 else '✅'}
- Invalid Events: {invalid_event_count} {'⚠️' if invalid_event_count > 0 else '✅'}
- Alarm Codes: {alarm_count} {'🚨' if alarm_count > 0 else '✅'}

**ISSUE SEVERITY:**
{'🔴 CRITICAL - Multiple issues detected' if (timeout_count + invalid_event_count + alarm_count) > 5 else '✅ NORMAL - No critical patterns detected'}

**LOG EXCERPT:**
{log_content[:1500]}...

**RECOMMENDATIONS:**
"""
    
    if timeout_count > 0:
        analysis += "\n- Investigate network connectivity and preset controller status"
    if invalid_event_count > 0:
        analysis += "\n- Review operational procedures with operators"
    if alarm_count > 0:
        analysis += "\n- Check alarm codes and take corrective actions"
    if (timeout_count + invalid_event_count + alarm_count) == 0:
        analysis += "\n- ✅ System operating normally, no immediate action required"
    
    return analysis


@tool
def tms_email_sender(query: str) -> str:
    """
    Generate and optionally send professional email for TMS support team via SMTP.
    
    **IMPORTANT:** When calling this tool, ALWAYS include complete diagnostic information:
    - Bay number and preset number
    - Issue description and symptoms
    - Diagnostic findings (error codes, root cause)
    - Recommended actions
    
    **Example Usage:**
    "Send email about Bay 9 Preset 9 issue: Socket Timeout detected. Root cause: Connection lost to preset controller. Recommended: Check network cables and restart controller."
    
    This tool can:
    1. **Draft Mode** (default): Generate email for review
    2. **Send Mode**: Actually send email via SMTP Direct Send
    
    **SMTP Configuration:**
    - Server: siemensenergy-com01i.mail.protection.outlook.com:25
    - Method: SMTP Direct Send (no authentication required)
    - Default To: mohammad.alam@siemens-energy.com
    - Default CC: mohammad.alam@siemens-energy.com
    - **CC Support**: Automatically extracts email addresses from query and adds to CC list
    
    Args:
        query: Complete diagnostic information and send/draft instruction
               Must include: bay number, preset number, issue details, findings
               Optional: Additional CC email addresses (will be automatically extracted)
               Examples: "Send email about Bay 4 Preset 3: Communication timeout. Root cause: Modbus connection failed. Check cabling."
                        "Draft email for Bay 2 Preset 5: Alarm code 0x1234 detected. Controller not responding."
                        "Send email about Bay 9 Preset 9 issue and add robert.grewe@siemens-energy.com to CC"
    
    Returns:
        Email content (draft mode) or send confirmation (send mode)
    """
    # Check if user wants to send
    send_keywords = ['send', 'dispatch', 'deliver', 'transmit']
    should_send = any(keyword in query.lower() for keyword in send_keywords)
    
    # Extract issue details
    preset_match = re.search(r'preset[=\s:]*(\d+)', query.lower())
    bay_match = re.search(r'bay[=\s:]*(\d+)', query.lower())
    
    preset_id = preset_match.group(1) if preset_match else "Unknown"
    bay_nr = bay_match.group(1) if bay_match else "Unknown"
    
    # Extract email addresses from query (look for CC emails)
    email_pattern = r'[\w\.-]+@[\w\.-]+\.\w+'
    found_emails = re.findall(email_pattern, query)
    
    # Email configuration
    smtp_server = "siemensenergy-com01i.mail.protection.outlook.com"
    smtp_port = 25
    from_email = "tms.support.agent@siemens-energy.com"
    to_email = "mohammad.alam@siemens-energy.com"
    
    # Build CC list - default CC + any emails found in query
    cc_emails = ["mohammad.alam@siemens-energy.com"]
    for email in found_emails:
        if email.lower() != to_email.lower() and email not in cc_emails:
            cc_emails.append(email)
    
    cc_email = ", ".join(cc_emails)
    
    # Generate email
    subject = f"TMS Alert - Support Required for Bay {bay_nr}, Preset {preset_id}"
    
    body = f"""Dear Siemens Energy Support Team,

EXECUTIVE SUMMARY:
We are experiencing a TMS (Terminal Management System) issue that requires your immediate attention.

ISSUE DETAILS:
- Location: Bay {bay_nr}, Preset {preset_id}
- Reported: {TMS.get_current_timestamp()}
- Severity: Medium (Operational impact)

TECHNICAL DETAILS:
The operator has reported an issue with the TMS system. Please review the attached trace log file for detailed analysis.

- System: Terminal Management System (TMS AccuLoad)
- Affected Components: Preset Controller {preset_id}, Bay {bay_nr}
- Issue Category: {query if query else "Operational issue reported"}

TROUBLESHOOTING PERFORMED:
1. Initial TMS diagnostics completed
2. Trace log file generated and attached
3. Configuration verified
4. Basic connectivity checks performed

RECOMMENDED ACTIONS:
1. Review attached trace log file
2. Analyze alarm codes and error messages
3. Check preset controller configuration
4. Verify network connectivity and Modbus communication

ATTACHMENTS:
- Trace log file: {os.path.basename(TMS.LOG_FILE_PATH)}

URGENCY:
Please review and respond within 4 hours.

Best regards,

Saudi Aramco Operations Team
Email: tms.support.agent@siemens-energy.com
Phone: +966 (0) 911 654-0
"""
    
    log_filename = os.path.basename(TMS.LOG_FILE_PATH)
    
    if should_send:
        try:
            # Create multipart message
            msg = MIMEMultipart()
            msg['From'] = from_email
            msg['To'] = to_email
            msg['Cc'] = cc_email
            msg['Subject'] = subject
            
            # Add body
            msg.attach(MIMEText(body, 'plain'))
            
            # Attach log file if it exists
            if os.path.exists(TMS.LOG_FILE_PATH):
                try:
                    with open(TMS.LOG_FILE_PATH, 'rb') as attachment:
                        part = MIMEBase('application', 'octet-stream')
                        part.set_payload(attachment.read())
                        encoders.encode_base64(part)
                        part.add_header(
                            'Content-Disposition',
                            f'attachment; filename= {log_filename}'
                        )
                        msg.attach(part)
                except Exception as e:
                    body += f"\n\n[Note: Could not attach log file: {e}]"
            
            # Send email via SMTP Direct Send
            with smtplib.SMTP(smtp_server, smtp_port, timeout=30) as server:
                server.set_debuglevel(0)  # Set to 1 for verbose SMTP debugging
                # Include all CC recipients in the recipient list
                recipients = [to_email] + cc_emails
                server.sendmail(from_email, recipients, msg.as_string())
            
            return f"""✅ **EMAIL SENT SUCCESSFULLY!**

**From:** {from_email}
**To:** {to_email}
**CC:** {cc_email}
**Subject:** {subject}
**Attachment:** {log_filename if os.path.exists(TMS.LOG_FILE_PATH) else 'None'}
**Sent via:** {smtp_server}:{smtp_port} (SMTP Direct Send)

📧 Email has been delivered to the support team.
"""
        
        except Exception as e:
            return f"""❌ **EMAIL SENDING FAILED!**

**Error:** {str(e)}

**SMTP Configuration:**
- Server: {smtp_server}:{smtp_port}
- From: {from_email}
- To: {to_email}

**Troubleshooting:**
1. Check network connectivity to SMTP server
2. Verify SMTP server accepts Direct Send (no auth)
3. Check if port 25 is open
4. Verify sender domain (@siemens-energy.com)

**Email Content (Draft):**
---
{subject}

{body}
---

Please copy this content and send manually, or contact IT support.
"""
    else:
        return f"""📧 **EMAIL DRAFT (Ready for Review - NOT SENT)**

**From:** {from_email}
**To:** {to_email}
**CC:** {cc_email}
**Subject:** {subject}

**Body:**
{body}

📎 **Attachment:** {log_filename}

---
**ACTIONS:**
- To SEND this email, say: "send this email to support team"
- To MODIFY, provide updated details
- This is a DRAFT - no email has been sent yet

**SMTP Config:** {smtp_server}:{smtp_port} (SMTP Direct Send)
"""


@tool
def get_current_time() -> str:
    """Get the current date and time."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ============================================================================
# Optional: Legacy export function for backward compatibility
# ============================================================================
# With explicit tool_imports in agents.yaml, this function is no longer needed.
# Tools are imported directly: "tms.tools_registry.tms_analyzer"

def get_tms_tools() -> List:
    """
    Get all TMS tools (legacy function).
    
    In new code, use explicit imports in agents.yaml:
        tool_imports:
          - "tms.tools_registry.tms_analyzer"
          - "tms.tools_registry.tms_email_sender"
    
    Returns:
        List of all TMS tools
    """
    return [
        tms_analyzer,
        tms_log_analyzer_tool,
        tms_email_sender,
        get_current_time
    ]
