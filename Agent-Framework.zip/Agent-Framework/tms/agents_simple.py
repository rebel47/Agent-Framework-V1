"""
TMS Multi-Agent System
======================
Terminal Management System AI Assistant

Files needed:
1. agents.py (this file) - Entry point
2. agents.yaml - Agent definitions  
3. tools_registry.py - TMS tools
4. .env - API keys

Commands:
    python agents.py         → CLI chat mode
    python agents.py --api   → Web API server
"""

import sys
from pathlib import Path
from dotenv import load_dotenv

# Load TMS environment variables
env_path = Path(__file__).parent / ".env"
load_dotenv(dotenv_path=env_path)

# Add parent directory to path (for framework import)
sys.path.insert(0, str(Path(__file__).parent.parent))

# Import from agentframework
from main import create_cli, create_api


def main():
    """Main entry point - Choose CLI or API mode."""
    
    print("\n" + "="*80)
    print("🏭 TMS (Terminal Management System) AI Assistant")
    print("   Siemens Energy - Saudi Aramco Operations")
    print("="*80 + "\n")
    
    # Check command line arguments
    if '--api' in sys.argv:
        # API mode
        api = create_api(agents_config_path="agents.yaml")
        api.run()
    else:
        # CLI mode (default)
        cli = create_cli(agents_config_path="agents.yaml")
        cli.run()


if __name__ == "__main__":
    main()
