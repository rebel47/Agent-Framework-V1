"""
🚀 Multi-Agent Project Generator - Simplified
==============================================
Demonstrates multi-agent pipeline: orchestrator → planner → architect → coder

Usage:
    python example_project_generator.py
"""

import asyncio
import re
from pathlib import Path
from main import AgentFramework


class ProjectGenerator:
    """Multi-Agent Project Generator - Simplified version."""
    
    def __init__(self):
        self.framework = AgentFramework()
        self.output_dir = Path("generated_projects")
        self.output_dir.mkdir(exist_ok=True)
    
    async def initialize(self):
        """Initialize framework and verify agents."""
        print("� Initializing Multi-Agent Project Generator...")
        await self.framework.initialize_async()
        
        required = ['orchestrator', 'planner', 'architect', 'coder']
        available = self.framework.list_agents()
        missing = [a for a in required if a not in available]
        
        if missing:
            print(f"❌ Missing agents: {missing}")
            return False
        
        print(f"✅ Ready with agents: {', '.join(required)}\n")
        return True
    
    async def cleanup(self):
        """Cleanup resources."""
        if self.framework:
            await self.framework.cleanup()
    
    async def generate_project(self, request: str):
        """Generate project using agent pipeline."""
        session = f"project_{request[:20].replace(' ', '_')}"
        
        print(f"\n{'='*60}\n🎯 REQUEST: {request}\n{'='*60}\n")
        
        # Agent Pipeline: Each agent builds on previous outputs
        print("📊 STEP 1: Orchestrator analyzing...")
        orchestrator_out = await self.framework.run_conversation(
            request, f"{session}_orch", "orchestrator"
        )
        
        print("\n📁 STEP 2: Planner designing structure...")
        planner_out = await self.framework.run_conversation(
            f"REQUEST: {request}\n\nORCHESTRATOR: {orchestrator_out}\n\nDesign project structure.",
            f"{session}_plan", "planner"
        )
        
        print("\n🏗️ STEP 3: Architect creating design...")
        architect_out = await self.framework.run_conversation(
            f"REQUEST: {request}\n\nSTRUCTURE: {planner_out}\n\nCreate technical architecture.",
            f"{session}_arch", "architect"
        )
        
        print("\n💻 STEP 4: Coder generating code...")
        coder_out = await self.framework.run_conversation(
            f"""REQUEST: {request}
            
ARCHITECTURE: {architect_out}

Generate code files in format:
### File: `filename`
```language
code
```""",
            f"{session}_code", "coder"
        )
        
        # Create files
        print("\n📝 STEP 5: Creating files...")
        project_path = self.output_dir / request[:20].replace(' ', '-')
        self._create_files(project_path, coder_out)
        
        print(f"\n✅ Done! Location: {project_path.absolute()}\n")
        return project_path
    
    def _create_files(self, path: Path, response: str):
        """Parse markdown code blocks and create files."""
        path.mkdir(parents=True, exist_ok=True)
        count = 0
        
        # Find all: ### File: `filename` followed by ```code```
        pattern = r'###?\s+(?:File:\s*)?`([^`]+)`\s*\n```\w*\n(.*?)```'
        for match in re.finditer(pattern, response, re.DOTALL):
            filename, code = match.groups()
            file_path = path / filename.strip()
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_text(code.strip(), encoding='utf-8')
            print(f"  ✓ {filename}")
            count += 1
        
        if count == 0:
            print("  ⚠️ No files found, creating README...")
            (path / "README.md").write_text(f"# Generated Project\n\n{response}")
            count = 1
        
        print(f"\n✅ Created {count} file(s)")
    
    async def run(self):
        """Main entry point."""
        if not await self.initialize():
            return
        
        print("� Describe your project (or 'quit' to exit):")
        request = input("\n🎯 ").strip()
        
        if request.lower() in ['quit', 'exit', 'q']:
            print("👋 Goodbye!")
            return
        
        if request:
            await self.generate_project(request)
        
        await self.framework.cleanup()


async def main():
    """Run the generator."""
    try:
        generator = ProjectGenerator()
        await generator.run()
    except KeyboardInterrupt:
        print("\n\n⏹️ Cancelled")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        raise


if __name__ == "__main__":
    asyncio.run(main())
