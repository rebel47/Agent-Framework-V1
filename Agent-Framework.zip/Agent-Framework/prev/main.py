"""
main.py
Minimal all-in-one entrypoint for the AI agent framework.
Includes:
- Azure OpenAI model
- LangChain Postgres chat memory
- Human-in-the-Loop middleware
- MCP server hook placeholder
"""

import os
from dotenv import load_dotenv
from langchain_openai import AzureChatOpenAI
from langchain.agents import create_agent
from langchain.agents.middleware import HumanInTheLoopMiddleware
from langchain_postgres import PostgresChatMessageHistory

# ========================
# 1️⃣ Load Environment
# ========================
load_dotenv()

AZURE_KEY = os.getenv("AZURE_OPENAI_API_KEY")
AZURE_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
AZURE_DEPLOYMENT = os.getenv("AZURE_DEPLOYMENT_NAME")
POSTGRES_URL = os.getenv("POSTGRES_URL")

# ========================
# 2️⃣ Initialize Postgres Memory
# ========================
def get_memory(session_id: str = "default-session"):
    """
    Create (or reuse) a Postgres-backed chat history using LangChain's Postgres memory.
    """
    return PostgresChatMessageHistory(
        connection_string=POSTGRES_URL,
        session_id=session_id,
    )

memory = get_memory()

# ========================
# 3️⃣ Initialize Model
# ========================
llm = AzureChatOpenAI(
    azure_endpoint=AZURE_ENDPOINT,
    deployment_name=AZURE_DEPLOYMENT,
    api_version="2024-05-01-preview",
    api_key=AZURE_KEY,
)

# ========================
# 4️⃣ Define Simple Tools
# ========================
def read_email(query: str):
    return f"[Mock] Reading emails matching: {query}"

def send_email(recipient: str, subject: str, body: str):
    return f"[Mock] Sending email to {recipient} with subject '{subject}'"

tools = [read_email, send_email]

# ========================
# 5️⃣ Human-in-the-Loop Middleware
# ========================
hitl = HumanInTheLoopMiddleware(
    interrupt_on={
        # Require human approval for sending emails
        "send_email": {"allowed_decisions": ["approve", "edit", "reject"]},
        # Auto-approve read actions
        "read_email": False,
    }
)

# ========================
# 6️⃣ Initialize Agent
# ========================
agent = create_agent(
    model=llm,
    tools=tools,
    middleware=[hitl],
)

# ========================
# 7️⃣ MCP Server Hook (Placeholder)
# ========================
class MCPServer:
    """
    Placeholder for MCP server integration.
    This is where you’ll expose your agent’s context to external systems.
    """
    def __init__(self, agent):
        self.agent = agent

    def start(self):
        print("[MCP] Server started. Agent context available via MCP protocol.")

mcp_server = MCPServer(agent)

# ========================
# 8️⃣ Run Example Session
# ========================
if __name__ == "__main__":
    print("🚀 Starting Agent Framework Runtime...")
    print(f"🧠 Connected to PostgreSQL memory: {POSTGRES_URL}")

    # Start MCP
    mcp_server.start()

    # Run an example interaction
    user_input = "Send a project summary email to Alice"
    print(f"\n👤 User: {user_input}")

    result = agent.invoke({"input": user_input})
    print(f"\n🤖 Agent: {result}")
