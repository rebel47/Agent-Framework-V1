import yaml
import graphviz
import os

def load_agent_config(filepath="agents.yaml"):
    """Loads the agent configuration from a YAML file."""
    if not os.path.exists(filepath):
        print(f"Error: File not found at '{filepath}'")
        print("Please make sure 'agents.yaml' is in the same directory as this script.")
        return None
        
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)
    except yaml.YAMLError as e:
        print(f"Error parsing YAML file: {e}")
        return None
    except Exception as e:
        print(f"An error occurred: {e}")
        return None

def format_tools(tool_imports):
    """Helper function to format the tool list for the diagram."""
    if not tool_imports:
        return "- (No tools)"
    # Cleans up the path prefix 'multiagent.tools_registry.'
    cleaned_tools = [tool.split('.')[-1] for tool in tool_imports]
    return "<BR/>".join(f"- {tool}" for tool in cleaned_tools)

def format_properties(agent):
    """Helper function to format key agent properties."""
    props = []
    if 'debug' in agent:
        props.append(f"- debug: {str(agent['debug']).lower()}")
    if 'hitl' in agent:
        # Highlight the HITL=true property
        if agent['hitl']:
            props.append(f"- <B>hitl: true</B>")
        else:
            props.append(f"- hitl: false")
    if 'parent' in agent:
        props.append(f"- parent: {agent['parent']}")
    
    return "<BR/>".join(props)

def create_agent_label(agent, color="#fdf"):
    """Creates an HTML-like label for a Graphviz node."""
    
    tools_html = format_tools(agent.get('tool_imports', []))
    props_html = format_properties(agent)

    label = f'''<
    <TABLE BORDER="0" CELLBORDER="1" CELLSPACING="0" CELLPADDING="4">
      <TR><TD ALIGN="CENTER" BGCOLOR="{color}"><B>{agent['name']}</B><BR/>({agent.get('description', 'Agent')})</TD></TR>
      <TR><TD ALIGN="LEFT" BALIGN="LEFT">
        <B>Properties:</B><BR/>
        {props_html}
        <BR/><B>Tools:</B><BR/>
        {tools_html}
      </TD></TR>
    </TABLE>>'''
    return label

def visualize_agent_system(config, output_filename="agent_system_graph"):
    """Generates and renders a Graphviz diagram from the agent config."""
    
    if not config or 'agents' not in config:
        print("Invalid configuration data. Cannot visualize.")
        return

    dot = graphviz.Digraph(comment='Multi-Agent System')
    dot.attr(rankdir='TB', label='Multi-Agent System (from agents.yaml)', fontsize='20', layout='dot')

    # Define entry and exit points
    dot.node('User', 'User Request', shape='circle', style='filled', fillcolor='#ffffff')
    dot.node('Response', 'Final Response', shape='circle', style='filled', fillcolor='#ffffff')

    agents_by_name = {agent['name']: agent for agent in config['agents']}
    main_agent_name = config.get('default_agent')
    
    if not main_agent_name or main_agent_name not in agents_by_name:
        print(f"Error: Default agent '{main_agent_name}' not found in agents list.")
        return

    main_agent = agents_by_name[main_agent_name]
    
    # 1. Add the Main Agent (Orchestrator)
    main_label = create_agent_label(main_agent, color="#fdf")
    dot.node(main_agent_name, label=main_label, shape='plain')
    dot.edge('User', main_agent_name, label='Initial Request')
    
    # 2. Add Sub-Agents
    sub_agent_names = main_agent.get('sub_agents', [])
    if sub_agent_names:
        with dot.subgraph(name='cluster_subagents') as c:
            c.attr(label='Specialized Sub-Agents', style='rounded', color='gray')
            
            # Define some colors for sub-agents
            colors = ['#e6f3ff', '#e6ffe6', '#ffebf0', '#fff9e6']
            
            for i, sub_name in enumerate(sub_agent_names):
                if sub_name not in agents_by_name:
                    print(f"Warning: Sub-agent '{sub_name}' (listed in main_agent) not defined in config.")
                    continue
                    
                sub_agent = agents_by_name[sub_name]
                color = colors[i % len(colors)] # Cycle through colors
                
                # Create node for sub-agent
                sub_label = create_agent_label(sub_agent, color=color)
                c.node(sub_name, label=sub_label, shape='plain')
                
                # Add delegation and response edges
                dot.edge(main_agent_name, sub_name, label=f'Delegates\n{sub_name.split("_")[0]} task', style='dashed')
                dot.edge(sub_name, main_agent_name, label='Result', dir='back', style='dotted')

    # 3. Add final response edge
    dot.edge(main_agent_name, 'Response', label='Final Answer')

    # Render and save the graph
    try:
        dot.render(output_filename, view=True, format='png', cleanup=True)
        print(f"\nSuccessfully generated '{output_filename}.png' and opened it.")
    except Exception as e:
        print(f"\nError rendering graph. Do you have Graphviz installed and in your system's PATH?")
        print(f"Details: {e}")
        print("\nGraphviz DOT source (for debugging):\n")
        print(dot.source)

# --- Main execution ---
if __name__ == "__main__":
    agent_config = load_agent_config("agents.yaml")
    if agent_config:
        visualize_agent_system(agent_config)