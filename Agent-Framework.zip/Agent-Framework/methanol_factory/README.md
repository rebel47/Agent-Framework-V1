# Methanol Factory Construction - Multi-Agent System

A specialized multi-agent system for analyzing methanol factory construction requirements and matching them against department capabilities. Built on the Agent-Framework, this system uses LLM-powered semantic analysis to generate comprehensive offer reports.

## 🎯 Use Case

**Problem**: When constructing a methanol factory, multiple specialized departments (roof, windows, electrical, automation) need to analyze construction requirements and determine what services they can or cannot provide.

**Solution**: This multi-agent system automates the analysis by:
1. Reading construction requirement documents (PDF/DOCX/Excel)
2. Reading each department's capability documents (PDF/DOCX/Excel)
3. Using LLM semantic understanding to match requirements with capabilities
4. Generating department-specific Excel reports showing:
   - ✅ Services they CAN provide
   - ❌ Services they CANNOT provide
   - 💡 Analysis and recommendations

## 🏗️ Architecture

### Agents

**Coordinator Agent** (`coordinator_agent`)
- Main orchestrator that routes queries to specialized agents
- Helps users navigate available documents
- Coordinates multi-department analysis

**Specialist Agents**
- **Roof Agent** (`roof_agent`) - Roofing systems specialist
- **Window Agent** (`window_agent`) - Window systems specialist
- **Electrical Agent** (`electrical_agent`) - Electrical systems specialist
- **Automation Agent** (`automation_agent`) - Automation & control systems specialist

Each specialist agent:
- Reads and extracts domain-specific requirements
- Analyzes company capabilities
- Performs semantic matching (no hardcoding!)
- Generates Excel reports with gap analysis

### Tools

All agents have access to:
- `read_pdf_document` - Extract text from PDF files
- `read_docx_document` - Extract text and tables from Word documents
- `read_excel_document` - Read Excel spreadsheets
- `list_available_documents` - List available requirement/capability files
- `generate_excel_report` - Create multi-sheet Excel analysis reports

## 📁 Folder Structure

```
methanol_factory/
├── agents.yaml              # Agent configuration
├── agents.py                # Launcher script
├── tools_registry.py        # Document processing tools
├── README.md               # This file
├── data/
│   ├── requirements/       # Factory construction requirements (PDF/DOCX/Excel)
│   └── capabilities/       # Department capability documents (PDF/DOCX/Excel)
└── output/                 # Generated Excel reports
```

## 🚀 Getting Started

### Prerequisites

1. **Main Framework Setup** (if not already done):
```bash
cd ..  # Go to parent directory
pip install -r requirements.txt
```

2. **Project-Specific Dependencies**:
```bash
# Install document processing libraries
pip install PyPDF2 python-docx openpyxl pandas
```

Or install all at once from the project folder:
```bash
cd methanol_factory
pip install -r requirements.txt
```

### Prepare Documents

1. **Add requirement documents** to `data/requirements/`:
   - Factory construction specifications
   - Technical requirements
   - Any format: PDF, DOCX, Excel

2. **Add capability documents** to `data/capabilities/`:
   - Department service offerings
   - Technical capabilities
   - Any format: PDF, DOCX, Excel

### Launch Modes

#### Interactive CLI Mode

```bash
python agents.py
```

This launches an interactive chat where you can:
- Ask questions naturally
- Type `help` for available commands
- Type `quit` or `exit` to quit

Example interaction:
```
You: List available documents
Agent: [Shows available requirement and capability documents]

You: I'm from the roof company. Analyze the roof requirements.
Agent: [Reads factory_requirements.txt, roof_company_services.txt, performs analysis]

You: Generate a report
Agent: [Creates Excel report in output/ folder]
```

#### REST API Mode

```bash
python agents.py --api
```

Access:
- **Swagger UI**: http://localhost:8000/docs
- **OpenAI compatible**: http://localhost:8000/v1/chat/completions

Example API call:
```bash
curl -X POST http://localhost:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "model": "roof_agent",
    "messages": [
      {"role": "user", "content": "Analyze the roof requirements and generate a report"}
    ]
  }'
```

## 📊 Workflow Example

### Scenario: Roof Company Analysis

1. **User starts conversation**:
   ```
   User: "Hi, I'm from the roof company. What documents are available?"
   ```

2. **Agent lists documents**:
   ```
   Agent: [Uses list_available_documents tool]
   "Available requirements: factory_specs.pdf
    Available capabilities: roof_services.xlsx"
   ```

3. **User requests analysis**:
   ```
   User: "Please analyze the roof requirements and compare with our capabilities"
   ```

4. **Agent performs analysis**:
   ```
   Agent: 
   [Uses read_pdf_document on factory_specs.pdf]
   [Uses read_excel_document on roof_services.xlsx]
   [Performs LLM-based semantic analysis]
   [Uses generate_excel_report]
   
   "Analysis complete! Report generated: output/roof_analysis_20250113_143022.xlsx"
   ```

5. **Excel report contains**:
   - **Summary Sheet**: High-level overview
   - **Requirements Sheet**: All extracted roof requirements
   - **Capabilities Sheet**: Company's roof capabilities
   - **Analysis Sheet**: Detailed ✅ CAN / ❌ CANNOT breakdown

## 🎨 Key Features

### ✨ Semantic Understanding
- No hardcoded keyword matching
- LLM analyzes requirements contextually
- Understands technical specifications semantically

### 🔄 Multi-Format Support
- PDF: Technical specifications
- DOCX: Requirement documents with tables
- Excel: Structured capability data

### 📈 Professional Reports
- Multi-sheet Excel workbooks
- Timestamped filenames
- Clear ✅/❌ gap analysis
- Professional formatting

### 🎯 Department-Specific
- Each agent specializes in one domain
- Personalized analysis for each department
- Independent report generation

### 🤝 Cross-Department Coordination
- Coordinator agent can orchestrate multiple departments
- Support for complex multi-department queries
- Comprehensive factory-wide analysis

## 🔧 Customization

### Adding New Departments

1. **Add agent to `agents.yaml`**:
```yaml
- name: hvac_agent
  description: "HVAC systems specialist"
  model_provider: azure
  tools:
    - read_pdf_document
    - read_docx_document
    - read_excel_document
    - list_available_documents
    - generate_excel_report
  system_prompt: |
    You are the HVAC Agent specializing in heating, ventilation, and air conditioning...
```

2. **Add to coordinator's sub_agents**:
```yaml
sub_agents:
  - roof_agent
  - window_agent
  - electrical_agent
  - automation_agent
  - hvac_agent  # New agent
```

### Custom Tools

Add new tools in `tools_registry.py`:

```python
@tool
def custom_tool(param: str) -> str:
    """Custom tool description."""
    # Implementation
    return result
```

## 🧪 Testing

### Test with Sample Documents

1. Create `data/requirements/sample_factory.txt`:
```
Roof Requirements:
- 10,000 sq meters industrial roofing
- Fire-resistant materials required
- UV protection coating

Window Requirements:
- 50 safety glass windows
- Emergency exit windows
```

2. Create `data/capabilities/roof_services.txt`:
```
Roof Services Available:
- Industrial roofing up to 15,000 sq meters
- Fire-resistant materials (Class A)
- Weather-resistant coatings
```

3. Run analysis:
```bash
python agents.py
```

```
You: List available documents
Agent: [Shows factory_requirements.txt and roof_company_services.txt]

You: Analyze requirements and generate report
Agent: [Performs analysis and creates Excel report]
```

4. Check `output/` folder for generated report!

## 🌐 Integration

### OpenAI Compatible API

The system exposes an OpenAI-compatible endpoint, making it easy to integrate with tools like:
- LangChain
- Open WebUI
- Custom ChatGPT interfaces
- Any OpenAI SDK

Example with OpenAI Python SDK:
```python
from openai import OpenAI

client = OpenAI(
    base_url="http://localhost:8000/v1",
    api_key="dummy"  # Not required
)

response = client.chat.completions.create(
    model="coordinator_agent",
    messages=[
        {"role": "user", "content": "List available documents"}
    ]
)

print(response.choices[0].message.content)
```

## 📝 Configuration

### Environment Variables

Framework requires these environment variables (see main project `.env`):

```env
# Azure OpenAI (recommended)
AZURE_OPENAI_API_KEY=your_key
AZURE_OPENAI_ENDPOINT=your_endpoint
AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4o
AZURE_OPENAI_API_VERSION=2024-02-15-preview

# OR OpenAI
OPENAI_API_KEY=your_key
OPENAI_MODEL=gpt-4o
```

### Agent Configuration

Adjust agent behavior in `agents.yaml`:

- `temperature`: 0.0-1.0 (lower = more deterministic)
- `max_tokens`: Response length limit
- `model_provider`: `azure` or `openai`
- `debug`: Enable/disable debug logging

## 🛠️ Troubleshooting

### Missing Libraries
```
Error: PyPDF2 not found
Solution: pip install PyPDF2
```

### Document Not Found
```
Error: Cannot read file
Solution: Ensure file is in data/requirements/ or data/capabilities/
```

### No Output Generated
- Check `output/` folder permissions
- Verify agent completed analysis
- Check logs for errors

### API Not Starting
```
Solution: pip install uvicorn fastapi
```

## 📚 Related Documentation

- [Framework Overview](../docs/FRAMEWORK_OVERVIEW.md)
- [API Guide](../docs/API_GUIDE.md)
- [Developer Guide](../docs/DEVELOPER_GUIDE.md)
- [System Prompts](../docs/SYSTEM_PROMPTS.md)

## 🤝 Contributing

This is a specialized example built on Agent-Framework. For framework improvements, see main project README.

## 📄 License

Same as main Agent-Framework project.

---

**Built with ❤️ using Agent-Framework**
