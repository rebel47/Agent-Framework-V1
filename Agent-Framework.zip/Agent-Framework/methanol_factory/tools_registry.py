"""
Tools Registry for Methanol Factory Construction Multi-Agent System
====================================================================
Defines all tools available to construction department agents.

Usage in agents.yaml:
    tool_imports:
      - "methanol_factory.tools_registry.read_pdf_document"
      - "methanol_factory.tools_registry.generate_excel_report"

Import the decorator from main:
    from main import tool
"""

from main import tool
from typing import List, Dict, Any, Optional
import os
import pandas as pd
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

# Try importing document libraries
try:
    import PyPDF2
    PDF_AVAILABLE = True
except ImportError:
    PDF_AVAILABLE = False
    logger.warning("PyPDF2 not installed. PDF reading will not be available.")

try:
    from docx import Document
    DOCX_AVAILABLE = True
except ImportError:
    DOCX_AVAILABLE = False
    logger.warning("python-docx not installed. DOCX reading will not be available.")

try:
    import openpyxl
    EXCEL_AVAILABLE = True
except ImportError:
    EXCEL_AVAILABLE = False
    logger.warning("openpyxl not installed. Excel operations will be limited.")


@tool
def read_pdf_document(file_path: str) -> str:
    """
    Read and extract text from a PDF document.
    
    Args:
        file_path: Path to the PDF file (relative to methanol_factory/data/)
        
    Returns:
        Extracted text content from the PDF
        
    Example:
        read_pdf_document("requirements/factory_specs.pdf")
    """
    if not PDF_AVAILABLE:
        return "Error: PyPDF2 not installed. Please install with: pip install PyPDF2"
    
    try:
        # Construct full path
        base_path = os.path.join(os.path.dirname(__file__), "data")
        full_path = os.path.join(base_path, file_path)
        
        if not os.path.exists(full_path):
            return f"Error: File not found at {full_path}"
        
        text_content = []
        with open(full_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            for page_num, page in enumerate(pdf_reader.pages, 1):
                text = page.extract_text()
                text_content.append(f"--- Page {page_num} ---\n{text}")
        
        result = "\n\n".join(text_content)
        logger.info(f"Successfully read PDF: {file_path} ({len(result)} characters)")
        return result
        
    except Exception as e:
        error_msg = f"Error reading PDF {file_path}: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool
def read_docx_document(file_path: str) -> str:
    """
    Read and extract text from a Word DOCX document.
    
    Args:
        file_path: Path to the DOCX file (relative to methanol_factory/data/)
        
    Returns:
        Extracted text content from the document
        
    Example:
        read_docx_document("capabilities/roof_services.docx")
    """
    if not DOCX_AVAILABLE:
        return "Error: python-docx not installed. Please install with: pip install python-docx"
    
    try:
        # Construct full path
        base_path = os.path.join(os.path.dirname(__file__), "data")
        full_path = os.path.join(base_path, file_path)
        
        if not os.path.exists(full_path):
            return f"Error: File not found at {full_path}"
        
        doc = Document(full_path)
        
        # Extract all paragraphs
        paragraphs = [para.text for para in doc.paragraphs if para.text.strip()]
        
        # Extract tables
        tables_text = []
        for table in doc.tables:
            table_data = []
            for row in table.rows:
                row_data = [cell.text.strip() for cell in row.cells]
                table_data.append(" | ".join(row_data))
            tables_text.append("\n".join(table_data))
        
        # Combine content
        content = "\n\n".join(paragraphs)
        if tables_text:
            content += "\n\n--- TABLES ---\n" + "\n\n".join(tables_text)
        
        logger.info(f"Successfully read DOCX: {file_path} ({len(content)} characters)")
        return content
        
    except Exception as e:
        error_msg = f"Error reading DOCX {file_path}: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool
def read_excel_document(file_path: str, sheet_name: str = None) -> str:
    """
    Read and extract data from an Excel document.
    
    Args:
        file_path: Path to the Excel file (relative to methanol_factory/data/)
        sheet_name: Optional specific sheet name to read (reads all sheets if not specified)
        
    Returns:
        Formatted text representation of Excel data
        
    Example:
        read_excel_document("capabilities/automation_services.xlsx")
        read_excel_document("capabilities/automation_services.xlsx", "Services")
    """
    try:
        # Construct full path
        base_path = os.path.join(os.path.dirname(__file__), "data")
        full_path = os.path.join(base_path, file_path)
        
        if not os.path.exists(full_path):
            return f"Error: File not found at {full_path}"
        
        # Read Excel file
        if sheet_name:
            df = pd.read_excel(full_path, sheet_name=sheet_name)
            content = f"--- Sheet: {sheet_name} ---\n{df.to_string()}"
        else:
            excel_file = pd.ExcelFile(full_path)
            sheets_content = []
            for sheet in excel_file.sheet_names:
                df = pd.read_excel(full_path, sheet_name=sheet)
                sheets_content.append(f"--- Sheet: {sheet} ---\n{df.to_string()}")
            content = "\n\n".join(sheets_content)
        
        logger.info(f"Successfully read Excel: {file_path}")
        return content
        
    except Exception as e:
        error_msg = f"Error reading Excel {file_path}: {str(e)}"
        logger.error(error_msg)
        return error_msg


@tool
def list_available_documents(folder: str = None) -> str:
    """
    List all available documents in the data folders.
    
    Args:
        folder: Optional specific folder ("requirements" or "capabilities")
        
    Returns:
        List of available documents
        
    Example:
        list_available_documents()
        list_available_documents("requirements")
    """
    try:
        base_path = os.path.join(os.path.dirname(__file__), "data")
        
        if folder:
            target_path = os.path.join(base_path, folder)
            if not os.path.exists(target_path):
                return f"Error: Folder '{folder}' not found"
            folders = [folder]
        else:
            folders = ["requirements", "capabilities"]
        
        result = []
        for folder_name in folders:
            folder_path = os.path.join(base_path, folder_name)
            if os.path.exists(folder_path):
                files = os.listdir(folder_path)
                if files:
                    result.append(f"📁 {folder_name}/")
                    for file in sorted(files):
                        result.append(f"  - {file}")
                else:
                    result.append(f"📁 {folder_name}/ (empty)")
        
        return "\n".join(result) if result else "No documents found"
        
    except Exception as e:
        return f"Error listing documents: {str(e)}"


@tool
def generate_excel_report(
    department: str,
    requirements_data: str,
    capabilities_data: str,
    analysis_result: str
) -> str:
    """
    Generate an Excel report comparing requirements against capabilities.
    
    Args:
        department: Department name (roof, window, electrical, automation)
        requirements_data: Extracted requirements text
        capabilities_data: Extracted capabilities text
        analysis_result: LLM analysis comparing requirements vs capabilities
        
    Returns:
        Path to the generated Excel file
        
    Example:
        generate_excel_report("roof", requirements, capabilities, analysis)
    """
    try:
        # Create output filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_dir = os.path.join(os.path.dirname(__file__), "output")
        os.makedirs(output_dir, exist_ok=True)
        filename = f"{department}_analysis_{timestamp}.xlsx"
        output_path = os.path.join(output_dir, filename)
        
        # Parse analysis result (assuming LLM provides structured data)
        # This is a basic implementation - the LLM should provide structured output
        
        # Create Excel workbook
        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            # Summary sheet
            summary_data = {
                'Department': [department.upper()],
                'Report Generated': [datetime.now().strftime("%Y-%m-%d %H:%M:%S")],
                'Analysis': [analysis_result[:500]]  # Preview
            }
            summary_df = pd.DataFrame(summary_data)
            summary_df.to_excel(writer, sheet_name='Summary', index=False)
            
            # Requirements sheet
            req_lines = requirements_data.split('\n')
            req_df = pd.DataFrame({'Requirements': req_lines})
            req_df.to_excel(writer, sheet_name='Requirements', index=False)
            
            # Capabilities sheet
            cap_lines = capabilities_data.split('\n')
            cap_df = pd.DataFrame({'Capabilities': cap_lines})
            cap_df.to_excel(writer, sheet_name='Capabilities', index=False)
            
            # Analysis sheet
            analysis_lines = analysis_result.split('\n')
            analysis_df = pd.DataFrame({'Analysis Details': analysis_lines})
            analysis_df.to_excel(writer, sheet_name='Analysis', index=False)
        
        logger.info(f"Generated Excel report: {output_path}")
        return f"✅ Excel report generated successfully!\n\nFile: {filename}\nLocation: {output_path}\n\nThe report contains:\n- Summary of analysis\n- Full requirements list\n- Full capabilities list\n- Detailed comparison analysis"
        
    except Exception as e:
        error_msg = f"Error generating Excel report: {str(e)}"
        logger.error(error_msg)
        return error_msg


# Export all tools
__all__ = [
    'read_pdf_document',
    'read_docx_document', 
    'read_excel_document',
    'list_available_documents',
    'generate_excel_report'
]
