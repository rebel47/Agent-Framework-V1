"""
Methanol Factory Construction - Multi-Agent System
===================================================
Entry point for the methanol factory construction offer generation system.

Files needed:
1. agents.py (this file) - Entry point
2. agents.yaml - Agent definitions (5 agents)
3. tools_registry.py - Document processing tools
4. .env - API keys (in parent directory)

Usage:
    python agents.py         → CLI chat mode
    python agents.py --api   → Web API server on port 8000
"""

import sys
from pathlib import Path

# Add parent directory to path to import framework
sys.path.insert(0, str(Path(__file__).parent.parent))

# Import from main framework
from main import create_cli, create_api


def main():
    """Main entry point - Choose CLI or API mode."""
    
    print("🏭 Methanol Factory Construction Multi-Agent System")
    print("=" * 60)
    print("📋 Use Case: Construction offer generation")
    print("🤖 Agents: coordinator + roof + window + electrical + automation")
    print("=" * 60)
    
    # Check command line arguments
    if '--api' in sys.argv:
        # API mode
        print("\n🌐 Starting API Server...")
        print("📖 Swagger UI: http://localhost:8000/docs")
        print("🔗 OpenAI Compatible: http://localhost:8000/v1/chat/completions")
        print("\n💡 Available agents:")
        print("   - coordinator_agent (main orchestrator)")
        print("   - roof_agent (roof company specialist)")
        print("   - window_agent (window company specialist)")
        print("   - electrical_agent (electrical company specialist)")
        print("   - automation_agent (automation company specialist)")
        print("\n� Press Ctrl+C to stop\n")
        
        api = create_api(agents_config_path="agents.yaml")
        api.run()
    else:
        # CLI mode (default)
        print("\n🤖 Starting Interactive CLI...")
        print("� Commands:")
        print("   - Type your question naturally")
        print("   - 'help' - Show help")
        print("   - 'quit' or 'exit' - Exit chat")
        print("\n💡 Example queries:")
        print("   - 'List available documents'")
        print("   - 'Analyze roof requirements'")
        print("   - 'Generate report for roof department'\n")
        
        cli = create_cli(agents_config_path="agents.yaml")
        cli.run()


if __name__ == "__main__":
    main()
