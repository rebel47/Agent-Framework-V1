"""
FastAPI Server for AgentFramework
==================================
Provides REST API endpoints with automatic Swagger UI documentation.

Can be used standalone or imported by user's agents.py file.

Usage (standalone):
    python api_server.py
    
Usage (from user's agents.py):
    from agentframework import create_api
    
    api = create_api()
    api.run()

Features:
- Chat with agents via REST API
- Stream responses (SSE)
- List agents and their capabilities
- Manage conversation threads
- Interactive Swagger UI at /docs
"""

import logging
import asyncio
import sys
import time
import uuid
from typing import Optional, List, Dict, Any
from contextlib import asynccontextmanager

# Fix for Windows: psycopg requires WindowsSelectorEventLoopPolicy
if sys.platform == 'win32':
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.responses import StreamingResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from main import AgentFramework


# Configure logging
logger = logging.getLogger(__name__)

# Global framework instance and config path
framework: Optional[AgentFramework] = None
config_path: str = "agents.yaml"  # Default, can be overridden


# ============================================================================
# Pydantic Models for API
# ============================================================================

class ChatRequest(BaseModel):
    """Request model for chat endpoint."""
    message: str = Field(..., description="User message to send to the agent", min_length=1)
    thread_id: Optional[str] = Field(None, description="Conversation thread ID (auto-generated if not provided)")
    agent_name: Optional[str] = Field(None, description="Specific agent to use (defaults to main/default agent if not provided)")
    
    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "message": "Hello! Can you help me?"
                },
                {
                    "message": "Analyze this data",
                    "agent_name": "specific_agent_name",
                    "thread_id": "my_session_123"
                }
            ]
        }
    }


class ChatResponse(BaseModel):
    """Response model for chat endpoint."""
    response: str = Field(..., description="Agent's response message")
    thread_id: str = Field(..., description="Conversation thread ID")
    agent_name: str = Field(..., description="Agent that handled the request")
    
    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "response": "Agent response will appear here",
                    "thread_id": "session_id",
                    "agent_name": "agent_name"
                }
            ]
        }
    }


class AgentInfo(BaseModel):
    """Model for agent information."""
    name: str = Field(..., description="Agent name/identifier")
    system_prompt: Optional[str] = Field(None, description="Agent's system prompt")
    tools: List[str] = Field(default_factory=list, description="List of tools available to this agent")
    temperature: float = Field(..., description="LLM temperature setting")
    debug: bool = Field(..., description="Whether debug mode is enabled")
    sub_agents: Optional[List[str]] = Field(None, description="List of sub-agents this agent can delegate to (if supervisor)")
    parent: Optional[str] = Field(None, description="Parent agent name (if this is a sub-agent)")
    role: str = Field(default="agent", description="Agent role: 'supervisor', 'sub-agent', or 'agent'")
    
    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "name": "agent_name",
                    "system_prompt": "Agent's system prompt...",
                    "tools": ["tool1", "tool2"],
                    "temperature": 0.7,
                    "debug": False,
                    "sub_agents": ["sub_agent1", "sub_agent2"],
                    "parent": None,
                    "role": "supervisor"
                }
            ]
        }
    }


class AgentListResponse(BaseModel):
    """Response model for listing all agents."""
    agents: List[str] = Field(..., description="List of all available agent names")
    default_agent: str = Field(..., description="Default agent name")
    total_count: int = Field(..., description="Total number of agents")
    
    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "agents": ["agent1", "agent2", "agent3"],
                    "default_agent": "agent1",
                    "total_count": 3
                }
            ]
        }
    }


class HealthResponse(BaseModel):
    """Health check response."""
    status: str = Field(..., description="Service status")
    framework_initialized: bool = Field(..., description="Whether framework is initialized")
    agents_count: int = Field(..., description="Number of configured agents")
    llm_provider: str = Field(..., description="Configured LLM provider")


# ============================================================================
# OpenAI-Compatible Models (for Open WebUI integration)
# ============================================================================

class OpenAIMessage(BaseModel):
    """OpenAI-compatible message format."""
    role: str
    content: str

class OpenAIChatCompletionRequest(BaseModel):
    """OpenAI-compatible chat completion request."""
    model: Optional[str] = None  # Maps to agent_name in our framework, uses default if not provided
    messages: List[OpenAIMessage]
    stream: Optional[bool] = False
    temperature: Optional[float] = 0.7
    max_tokens: Optional[int] = None

class OpenAIModelInfo(BaseModel):
    """OpenAI-compatible model info."""
    id: str
    object: str = "model"
    created: int
    owned_by: str = "agentframework"


# ============================================================================
# Application Lifecycle
# ============================================================================

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize and cleanup framework on app startup/shutdown."""
    global framework
    
    import sys
    # Fix for Windows event loop (required for psycopg async)
    if sys.platform == 'win32':
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    
    logger.info("Starting AgentFramework API Server...")
    
    try:
        # Initialize framework with user's config
        framework = AgentFramework(agents_config_path=config_path)
        await framework.initialize_async()
        logger.info(f"✓ Framework initialized with {len(framework.list_agents())} agents")
        logger.info(f"✓ Default agent: {framework.default_agent_name}")
        
        # Update API schema with actual agent names for better documentation
        if hasattr(ChatRequest, 'model_config'):
            ChatRequest.model_config["json_schema_extra"]["examples"] = [
                {
                    "message": "Your message here",
                    "thread_id": "my_session_001",
                    "agent_name": framework.default_agent_name
                }
            ]
        
        # Update OpenAI-compatible endpoint schema with default agent
        if hasattr(OpenAIChatCompletionRequest, 'model_config'):
            OpenAIChatCompletionRequest.model_config = {
                "json_schema_extra": {
                    "examples": [
                        {
                            "model": framework.default_agent_name,
                            "messages": [
                                {"role": "user", "content": "Your message here"}
                            ],
                            "stream": False
                        }
                    ]
                }
            }
        
        yield
        
    except Exception as e:
        logger.error(f"Failed to initialize framework: {e}")
        raise
    finally:
        # Cleanup
        if framework:
            logger.info("Shutting down framework...")
            await framework.cleanup()
            logger.info("✓ Framework cleanup complete")


# ============================================================================
# FastAPI Application
# ============================================================================

app = FastAPI(
    title="AgentFramework API",
    description="""
    🤖 **AgentFramework REST API with Swagger UI**
    
    This API provides programmatic access to your AI agents with features including:
    
    - 💬 **Chat with agents** via REST endpoints
    - 🔄 **Stream responses** for real-time interaction
    - 📋 **List agents** and their capabilities
    - 🔧 **Manage conversations** with thread IDs
    - 📊 **Monitor health** and status
    - 🔌 **OpenAI-Compatible** endpoints for Open WebUI, TypingMind, LibreChat, etc.
    
    **Getting Started:**
    1. Check `/health` to verify the service is running
    2. Use `/agents` to see available agents
    3. Start chatting with `/chat` endpoint
    
    **For Open WebUI Integration:**
    - API URL: `http://localhost:8000/v1` (or `http://host.docker.internal:8000/v1` from Docker)
    - API Key: any value (not validated)
    - See `/v1/models` to list available agents as models
    
    **Documentation:**
    - Swagger UI: `/docs` (this page)
    - ReDoc: `/redoc`
    - OpenAPI JSON: `/openapi.json`
    """,
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

# Add CORS middleware for web UI integration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure this for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============================================================================
# API Endpoints
# ============================================================================

@app.get("/", tags=["General"])
async def root():
    """Root endpoint with API information."""
    return {
        "message": "AgentFramework API",
        "version": "1.0.0",
        "docs": "/docs",
        "health": "/health",
        "agents": "/agents",
    }


@app.get("/health", response_model=HealthResponse, tags=["General"])
async def health_check():
    """
    Health check endpoint.
    
    Returns the current status of the API server and framework.
    """
    if not framework:
        raise HTTPException(status_code=503, detail="Framework not initialized")
    
    return HealthResponse(
        status="healthy",
        framework_initialized=True,
        agents_count=len(framework.list_agents()),
        llm_provider=framework.llm_config.provider.value,
    )


@app.get("/agents", response_model=AgentListResponse, tags=["Agents"])
async def list_agents():
    """
    List all available agents.
    
    Returns a list of all configured agent names and the default agent.
    """
    if not framework:
        raise HTTPException(status_code=503, detail="Framework not initialized")
    
    agents = framework.list_agents()
    return AgentListResponse(
        agents=agents,
        default_agent=framework.default_agent_name,
        total_count=len(agents),
    )


@app.get("/agents/hierarchy/tree", tags=["Agents"])
async def get_agent_hierarchy():
    """
    Get the hierarchical structure of all agents.
    
    Returns a tree structure showing supervisor-subordinate relationships.
    Returns all supervisors with their sub-agents, and standalone agents.
    """
    if not framework:
        raise HTTPException(status_code=503, detail="Framework not initialized")
    
    # Build hierarchy tree
    supervisors = []
    sub_agent_names = set()
    standalone_agents = []
    
    # First pass: identify supervisors and collect sub-agent names
    for config in framework.agent_configs:
        sub_agents = config.get('sub_agents', [])
        if sub_agents:
            supervisors.append({
                "name": config['name'],
                "description": config.get('description', ''),
                "sub_agents": sub_agents,
                "role": "supervisor"
            })
            sub_agent_names.update(sub_agents)
    
    # Second pass: identify standalone agents (neither supervisors nor sub-agents)
    for config in framework.agent_configs:
        name = config['name']
        has_sub_agents = bool(config.get('sub_agents'))
        is_sub_agent = name in sub_agent_names
        
        if not has_sub_agents and not is_sub_agent:
            standalone_agents.append({
                "name": name,
                "description": config.get('description', ''),
                "role": "agent"
            })
    
    return {
        "supervisors": supervisors,
        "standalone_agents": standalone_agents,
        "total_agents": len(framework.list_agents()),
        "supervisor_count": len(supervisors),
        "standalone_count": len(standalone_agents),
    }


@app.get("/agents/{agent_name}", response_model=AgentInfo, tags=["Agents"])
async def get_agent_info(agent_name: str):
    """
    Get detailed information about a specific agent.
    
    Returns the agent's configuration including system prompt, tools, and settings.
    """
    if not framework:
        raise HTTPException(status_code=503, detail="Framework not initialized")
    
    # Find agent config
    agent_config = None
    for config in framework.agent_configs:
        if config['name'] == agent_name:
            agent_config = config
            break
    
    if not agent_config:
        raise HTTPException(
            status_code=404,
            detail=f"Agent '{agent_name}' not found. Available agents: {framework.list_agents()}"
        )
    
    # Determine agent role
    sub_agents = agent_config.get('sub_agents')
    parent = agent_config.get('parent')
    
    if sub_agents and len(sub_agents) > 0:
        role = "supervisor"
    elif parent:
        role = "sub-agent"
    else:
        role = "agent"
    
    return AgentInfo(
        name=agent_config['name'],
        system_prompt=agent_config.get('system_prompt'),
        tools=agent_config.get('tools', []),
        temperature=agent_config.get('temperature', 0.7),
        debug=agent_config.get('debug', False),
        sub_agents=sub_agents,
        parent=parent,
        role=role,
    )


@app.post("/chat", response_model=ChatResponse, tags=["Chat"])
async def chat(request: ChatRequest):
    """
    Send a message to an agent and get a response.
    
    **📝 Quick Start:**
    1. First, call `/agents` to see available agents
    2. Use the agent name in your chat request
    3. Optionally provide a thread_id for conversation continuity
    
    **Parameters:**
    - **message**: The user's message (required)
    - **thread_id**: Conversation thread ID for context (optional, auto-generated if not provided)
    - **agent_name**: Specific agent to use (optional, uses default agent if not provided)
    
    **💡 Tip:** Call `GET /agents` first to see available agent names!
    
    **Example Request:**
    ```json
    {
        "message": "Your message here",
        "thread_id": "my_session_001",
        "agent_name": "Leave empty to use default agent"
    }
    ```
    
    **Example Response:**
    ```json
    {
        "response": "Agent's response will appear here",
        "thread_id": "my_session_001",
        "agent_name": "actual_agent_used"
    }
    ```
    """
    if not framework:
        raise HTTPException(status_code=503, detail="Framework not initialized")
    
    # Generate thread_id if not provided
    thread_id = request.thread_id or f"api_{id(request)}"
    agent_name = request.agent_name or framework.default_agent_name
    
    # Verify agent exists
    if agent_name not in framework.list_agents():
        raise HTTPException(
            status_code=404,
            detail=f"Agent '{agent_name}' not found. Available agents: {framework.list_agents()}"
        )
    
    try:
        # Run conversation
        response_text = await framework.run_conversation(
            user_message=request.message,
            session_id=thread_id,
            agent_name=agent_name,
        )
        
        return ChatResponse(
            response=response_text,
            thread_id=thread_id,
            agent_name=agent_name,
        )
        
    except Exception as e:
        logger.error(f"Chat error: {e}")
        raise HTTPException(status_code=500, detail=f"Chat failed: {str(e)}")


@app.post("/chat/stream", tags=["Chat"])
async def chat_stream(request: ChatRequest):
    """
    Send a message to an agent and stream the response in real-time.
    
    Returns a Server-Sent Events (SSE) stream of the agent's response.
    
    **📝 Quick Start:**
    1. First, call `/agents` to see available agents
    2. Use the agent name in your stream request
    3. Connect with SSE-compatible client (EventSource, curl, etc.)
    
    **💡 Tip:** Call `GET /agents` first to see available agent names!
    
    **Note:** Streaming requires the agent to have streaming enabled in the LLM configuration.
    """
    if not framework:
        raise HTTPException(status_code=503, detail="Framework not initialized")
    
    # Generate thread_id if not provided
    thread_id = request.thread_id or f"api_{id(request)}"
    agent_name = request.agent_name or framework.default_agent_name
    
    # Verify agent exists
    if agent_name not in framework.list_agents():
        raise HTTPException(
            status_code=404,
            detail=f"Agent '{agent_name}' not found. Available agents: {framework.list_agents()}"
        )
    
    async def event_generator():
        """Generate SSE events for streaming response."""
        try:
            # For now, we'll send the complete response
            # TODO: Implement true streaming with LangChain's streaming callbacks
            response_text = await framework.run_conversation(
                user_message=request.message,
                session_id=thread_id,
                agent_name=agent_name,
            )
            
            # Send response as chunks (simulate streaming)
            words = response_text.split()
            for i, word in enumerate(words):
                chunk = word + (" " if i < len(words) - 1 else "")
                yield f"data: {chunk}\n\n"
                await asyncio.sleep(0.05)  # Small delay for smoother streaming
            
            # Send done signal
            yield "data: [DONE]\n\n"
            
        except Exception as e:
            logger.error(f"Stream error: {e}")
            yield f"data: [ERROR: {str(e)}]\n\n"
    
    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        }
    )


# ============================================================================
# OpenAI-Compatible Endpoints (for Open WebUI, TypingMind, etc.)
# ============================================================================

@app.get("/v1/models", tags=["OpenAI Compatible"])
async def openai_list_models():
    """
    List available models (agents) in OpenAI-compatible format.
    
    **🔌 Compatible with:** Open WebUI, TypingMind, LibreChat, and other OpenAI-compatible UIs
    
    Each agent appears as a separate "model" that can be selected in the UI.
    
    **Configure in Open WebUI:**
    - API URL: `http://localhost:8000/v1` (or `http://host.docker.internal:8000/v1` if in Docker)
    - API Key: any value (not validated)
    """
    if not framework:
        raise HTTPException(status_code=503, detail="Framework not initialized")
    
    agents = framework.list_agents()
    models = [
        OpenAIModelInfo(
            id=agent_name,
            created=int(time.time())
        )
        for agent_name in agents
    ]
    
    return {"object": "list", "data": [m.model_dump() for m in models]}


@app.post("/v1/chat/completions", tags=["OpenAI Compatible"])
async def openai_chat_completions(request: OpenAIChatCompletionRequest):
    """
    OpenAI-compatible chat completions endpoint.
    
    **🔌 Compatible with:** Open WebUI, TypingMind, LibreChat, and other OpenAI-compatible UIs
    
    **How it works:**
    - The `model` field maps to your agent name
    - If `model` is not provided or doesn't exist, uses the default agent
    - Supports both streaming and non-streaming responses
    - Maintains conversation context using message history
    
    **Example Request (with specific agent):**
    ```json
    {
        "model": "your_agent_name",
        "messages": [
            {"role": "user", "content": "What can you help me with?"}
        ],
        "stream": false
    }
    ```
    
    **Using Default Agent (omit model field):**
    ```json
    {
        "messages": [
            {"role": "user", "content": "Hello, I need assistance"}
        ]
    }
    ```
    """
    if not framework:
        raise HTTPException(status_code=503, detail="Framework not initialized")
    
    # Extract the last user message
    user_messages = [msg for msg in request.messages if msg.role == "user"]
    if not user_messages:
        raise HTTPException(status_code=400, detail="No user message found")
    
    user_message = user_messages[-1].content
    
    # Use specified model/agent or default
    agent_name = request.model or framework.default_agent_name
    
    # Verify agent exists, fallback to default if not
    if agent_name not in framework.list_agents():
        logger.warning(f"Agent '{agent_name}' not found, using default agent '{framework.default_agent_name}'")
        agent_name = framework.default_agent_name
    
    # Generate thread_id from conversation context
    thread_id = f"openai_{hash(''.join([m.content for m in request.messages]))}"
    
    try:
        if request.stream:
            return await _openai_stream_response(request, user_message, agent_name, thread_id)
        else:
            return await _openai_complete_response(request, user_message, agent_name, thread_id)
    
    except Exception as e:
        logger.error(f"OpenAI chat completion error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


async def _openai_complete_response(request: OpenAIChatCompletionRequest, user_message: str, agent_name: str, thread_id: str):
    """Generate non-streaming OpenAI-compatible response."""
    response_text = await framework.run_conversation(
        user_message=user_message,
        session_id=thread_id,
        agent_name=agent_name
    )
    
    completion_id = f"chatcmpl-{uuid.uuid4().hex[:8]}"
    
    return JSONResponse({
        "id": completion_id,
        "object": "chat.completion",
        "created": int(time.time()),
        "model": agent_name,
        "choices": [
            {
                "index": 0,
                "message": {
                    "role": "assistant",
                    "content": response_text
                },
                "finish_reason": "stop"
            }
        ],
        "usage": {
            "prompt_tokens": len(user_message.split()),
            "completion_tokens": len(response_text.split()),
            "total_tokens": len(user_message.split()) + len(response_text.split())
        }
    })


async def _openai_stream_response(request: OpenAIChatCompletionRequest, user_message: str, agent_name: str, thread_id: str):
    """Generate streaming OpenAI-compatible response (SSE format)."""
    
    async def generate():
        completion_id = f"chatcmpl-{uuid.uuid4().hex[:8]}"
        
        # Get complete response (TODO: implement true streaming)
        response_text = await framework.run_conversation(
            user_message=user_message,
            session_id=thread_id,
            agent_name=agent_name
        )
        
        # Stream word by word in OpenAI format
        words = response_text.split()
        for i, word in enumerate(words):
            chunk = {
                "id": completion_id,
                "object": "chat.completion.chunk",
                "created": int(time.time()),
                "model": agent_name,
                "choices": [
                    {
                        "index": 0,
                        "delta": {
                            "content": word + (" " if i < len(words) - 1 else "")
                        },
                        "finish_reason": None
                    }
                ]
            }
            yield f"data: {str(chunk)}\n\n"
            await asyncio.sleep(0.05)
        
        # Final chunk
        final_chunk = {
            "id": completion_id,
            "object": "chat.completion.chunk",
            "created": int(time.time()),
            "model": agent_name,
            "choices": [
                {
                    "index": 0,
                    "delta": {},
                    "finish_reason": "stop"
                }
            ]
        }
        yield f"data: {str(final_chunk)}\n\n"
        yield "data: [DONE]\n\n"
    
    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        }
    )


# ============================================================================
# Utility Functions
# ============================================================================

def run_api_server(host: str = "0.0.0.0", port: int = 8000, reload: bool = False, config_path: str = "agents.yaml"):
    """
    Run the FastAPI server.
    
    Args:
        host: Host to bind to (default: 0.0.0.0 for all interfaces)
        port: Port to bind to (default: 8000)
        reload: Enable auto-reload for development (default: False)
        config_path: Path to agents.yaml configuration file (default: agents.yaml)
    """
    import uvicorn
    import sys
    
    # Update global config_path variable
    globals()['config_path'] = config_path
    
    # Fix for Windows event loop (must be set before creating event loop)
    if sys.platform == 'win32':
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    
    logger.info(f"Starting API server on http://{host}:{port}")
    logger.info(f"Using config: {config_path}")
    logger.info(f"Swagger UI: http://localhost:{port}/docs")
    logger.info(f"ReDoc: http://localhost:{port}/redoc")
    
    # Create and set the event loop explicitly
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    
    # Use Config to have more control over the loop
    config = uvicorn.Config(
        app,
        host=host,
        port=port,
        reload=reload,
        log_level="info",
        loop="asyncio",  # Use asyncio loop
    )
    
    server = uvicorn.Server(config)
    
    try:
        loop.run_until_complete(server.serve())
    finally:
        loop.close()


if __name__ == "__main__":
    # Run server directly
    import os
    import sys
    import argparse
    
    # Fix for Windows event loop (required for psycopg async)
    if sys.platform == 'win32':
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='AgentFramework API Server')
    parser.add_argument('--config', type=str, default='agents.yaml', help='Path to agents.yaml config file')
    parser.add_argument('--host', type=str, default=None, help='Host to bind to')
    parser.add_argument('--port', type=int, default=None, help='Port to bind to')
    parser.add_argument('--reload', action='store_true', help='Enable auto-reload')
    
    args = parser.parse_args()
    
    # Load API configuration from environment (with CLI overrides)
    api_host = args.host or os.getenv("API_HOST", "0.0.0.0")
    api_port = args.port or int(os.getenv("API_PORT", "8000"))
    api_reload = args.reload or (os.getenv("API_RELOAD", "false").lower() == "true")
    
    run_api_server(
        host=api_host,
        port=api_port,
        reload=api_reload,
        config_path=args.config
    )
