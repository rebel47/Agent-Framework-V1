"""
AgentFramework - Production-Ready AI Multi-Agent System
========================================================
A pip-installable framework for building intelligent multi-agent applications.

Built with LangChain v1 + LangGraph + Multi-LLM Support + PostgreSQL

Installation:
    pip install agentframework (future)

Usage:
    from agentframework import AgentFramework, create_cli, create_api, tool
    
    # Define tools
    @tool
    def my_tool(query: str) -> str:
        '''My custom tool'''
        return f"Result: {query}"
    
    # CLI Mode
    cli = create_cli()
    cli.run()
    
    # API Mode
    api = create_api()
    api.run()

For more info: https://github.com/yourusername/agentframework
"""

import os
import sys
import logging
import asyncio
from pathlib import Path
from typing import Dict, List, Optional, Any
from datetime import datetime
import uuid

# LangChain Core
from langchain_core.messages import HumanMessage, SystemMessage, AIMessage, ToolMessage
from langchain_core.tools import tool  # Re-export for user convenience
from langchain_core.language_models.base import BaseLanguageModel
from langchain_core.language_models.chat_models import BaseChatModel

# Export main classes and tool decorator
__all__ = ['AgentFramework', 'create_cli', 'create_api', 'tool']
import asyncio
import sys
import yaml
import logging
from typing import Dict, List, Optional, Any, Type
from typing_extensions import TypedDict
from pathlib import Path
from dataclasses import dataclass
from enum import Enum

# Fix for Windows: psycopg requires WindowsSelectorEventLoopPolicy
if sys.platform == 'win32':
    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

from dotenv import load_dotenv

# Load environment variables first
load_dotenv()

# Configure logging based on environment settings
log_level = os.getenv("LOG_LEVEL", "INFO").upper()
log_format_type = os.getenv("LOG_FORMAT", "standard").lower()

# Define log formats
LOG_FORMATS = {
    "standard": '%(levelname)s - %(name)s - %(message)s',
    "detailed": '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    "json": '{"time": "%(asctime)s", "name": "%(name)s", "level": "%(levelname)s", "message": "%(message)s"}'
}

log_format = LOG_FORMATS.get(log_format_type, LOG_FORMATS["standard"])

logging.basicConfig(
    level=getattr(logging, log_level, logging.INFO),
    format=log_format,
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

# ============================================================================
# Constants
# ============================================================================
class LLMProvider(str, Enum):
    """Supported LLM providers."""
    AZURE = "azure"
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    GEMINI = "gemini"
    OLLAMA = "ollama"
    LOCAL = "local"


class LogFormat(str, Enum):
    """Supported log formats."""
    STANDARD = "standard"
    DETAILED = "detailed"
    JSON = "json"


# Default configuration values
DEFAULT_TEMPERATURE = 0.7
DEFAULT_LLM_PROVIDER = LLMProvider.AZURE
DEFAULT_LOG_LEVEL = "INFO"
DEFAULT_LOG_FORMAT = LogFormat.STANDARD
DEFAULT_AGENTS_CONFIG_PATH = "agents_config.yaml"
DEFAULT_MCP_CONFIG_PATH = "mcp_servers.yaml"

# LangChain imports - Multi-provider support
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage
from langchain_core.tools import tool, BaseTool
from langchain_community.chat_message_histories import PostgresChatMessageHistory

# LLM Provider imports (conditional based on what's installed)
try:
    from langchain_openai import AzureChatOpenAI, ChatOpenAI
except ImportError:
    AzureChatOpenAI = None
    ChatOpenAI = None

try:
    from langchain_anthropic import ChatAnthropic
except ImportError:
    ChatAnthropic = None

try:
    from langchain_google_genai import ChatGoogleGenerativeAI
except ImportError:
    ChatGoogleGenerativeAI = None

try:
    from langchain_community.llms import Ollama
    from langchain_community.chat_models import ChatOllama
except ImportError:
    Ollama = None
    ChatOllama = None

try:
    from langchain_community.llms import HuggingFacePipeline
except ImportError:
    HuggingFacePipeline = None

# LangChain v1 imports
from langchain.agents import create_agent
from langgraph.checkpoint.postgres import PostgresSaver
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver

# Dynamic imports - Load user's tools_registry.py from current directory
def _load_tools_from_imports(tool_imports: list) -> list:
    """
    Load tools from explicit import declarations.
    
    Args:
        tool_imports: List of import strings like:
            - "tools_registry.get_current_time"
            - "tms.tools_registry.tms_analyzer"
            - "my_tools.custom_tool"
    
    Returns:
        List of loaded tool objects
    """
    import importlib
    tools = []
    
    for import_path in tool_imports:
        try:
            # Split module path and tool name
            parts = import_path.rsplit('.', 1)
            if len(parts) != 2:
                logger.warning(f"Invalid tool import format: {import_path}. Use 'module.tool_name'")
                continue
            
            module_name, tool_name = parts
            
            # Import the module
            module = importlib.import_module(module_name)
            
            # Get the tool
            if hasattr(module, tool_name):
                tool = getattr(module, tool_name)
                tools.append(tool)
                logger.debug(f"Loaded tool: {tool_name} from {module_name}")
            else:
                logger.warning(f"Tool '{tool_name}' not found in module '{module_name}'")
                
        except ImportError as e:
            logger.error(f"Failed to import tool '{import_path}': {e}")
        except Exception as e:
            logger.error(f"Error loading tool '{import_path}': {e}")
    
    return tools


# ============================================================================
# Configuration Dataclasses
# ============================================================================
@dataclass
class LLMProviderConfig:
    """Configuration for LLM providers."""
    provider: LLMProvider
    temperature: float = DEFAULT_TEMPERATURE
    streaming: bool = True
    
    # Azure OpenAI
    azure_endpoint: Optional[str] = None
    azure_api_key: Optional[str] = None
    azure_deployment: Optional[str] = None
    azure_api_version: str = "2024-06-01"
    
    # OpenAI
    openai_api_key: Optional[str] = None
    openai_model: Optional[str] = None
    openai_base_url: str = "https://api.openai.com/v1"
    
    # Anthropic
    anthropic_api_key: Optional[str] = None
    anthropic_model: Optional[str] = None
    
    # Google Gemini
    google_api_key: Optional[str] = None
    gemini_model: Optional[str] = None
    
    # Ollama
    ollama_base_url: str = "http://localhost:11434"
    ollama_model: Optional[str] = None
    
    # Local
    local_model_path: Optional[str] = None
    local_model_device: str = "cuda"
    
    @classmethod
    def from_env(cls) -> 'LLMProviderConfig':
        """Load configuration from environment variables."""
        provider_str = os.getenv("LLM_PROVIDER", DEFAULT_LLM_PROVIDER.value).lower()
        provider = LLMProvider(provider_str)
        
        return cls(
            provider=provider,
            temperature=float(os.getenv("LLM_TEMPERATURE", str(DEFAULT_TEMPERATURE))),
            streaming=os.getenv("LLM_STREAMING", "true").lower() == "true",
            # Azure
            azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
            azure_api_key=os.getenv("AZURE_OPENAI_API_KEY"),
            azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
            azure_api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-06-01"),
            # OpenAI
            openai_api_key=os.getenv("OPENAI_API_KEY"),
            openai_model=os.getenv("OPENAI_MODEL"),
            openai_base_url=os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1"),
            # Anthropic
            anthropic_api_key=os.getenv("ANTHROPIC_API_KEY"),
            anthropic_model=os.getenv("ANTHROPIC_MODEL"),
            # Google
            google_api_key=os.getenv("GOOGLE_API_KEY"),
            gemini_model=os.getenv("GEMINI_MODEL"),
            # Ollama
            ollama_base_url=os.getenv("OLLAMA_BASE_URL", "http://localhost:11434"),
            ollama_model=os.getenv("OLLAMA_MODEL"),
            # Local
            local_model_path=os.getenv("LOCAL_MODEL_PATH"),
            local_model_device=os.getenv("LOCAL_MODEL_DEVICE", "cuda"),
        )
    
    def validate(self) -> None:
        """Validate that required configuration is present for the selected provider."""
        validations = {
            LLMProvider.AZURE: (self.azure_deployment, "AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o"),
            LLMProvider.OPENAI: (self.openai_model, "OPENAI_MODEL", "gpt-4o"),
            LLMProvider.ANTHROPIC: (self.anthropic_model, "ANTHROPIC_MODEL", "claude-3-5-sonnet-20241022"),
            LLMProvider.GEMINI: (self.gemini_model, "GEMINI_MODEL", "gemini-1.5-pro"),
            LLMProvider.OLLAMA: (self.ollama_model, "OLLAMA_MODEL", "llama3.2"),
            LLMProvider.LOCAL: (self.local_model_path, "LOCAL_MODEL_PATH", "meta-llama/Llama-2-7b-chat-hf"),
        }
        
        if self.provider in validations:
            value, env_var, example = validations[self.provider]
            if not value:
                raise ValueError(
                    f"{env_var} not set in .env file. "
                    f"Please set your {self.provider.value} configuration (e.g., {example})."
                )


# ============================================================================
# 1. MCP (Model Context Protocol) - Dynamic Multi-Server Support
# ============================================================================
class MCPContextProvider:
    """
    Dynamic MCP integration supporting multiple MCP servers.
    Configuration loaded from mcp_servers.yaml
    """
    
    def __init__(self, config_path: str = "mcp_servers.yaml"):
        self.logger = logging.getLogger(f"{__name__}.MCPContextProvider")
        self.mcp_enabled = os.getenv("MCP_ENABLED", "false").lower() == "true"
        self.servers = []
        self.config = {}
        
        if self.mcp_enabled:
            self._load_config(config_path)
        
        self.logger.info(f"Initialized (enabled={self.mcp_enabled}, servers={len(self.servers)})")
    
    def _load_config(self, config_path: str):
        """Load MCP server configuration from YAML file."""
        try:
            config_file = Path(config_path)
            if config_file.exists():
                with open(config_file, 'r', encoding='utf-8') as f:
                    self.config = yaml.safe_load(f)
                    
                # Load enabled servers
                for server_config in self.config.get('mcp_servers', []):
                    if server_config.get('enabled', False):
                        self.servers.append(server_config)
                        self.logger.info(f"Loaded server: {server_config['name']} - {server_config['description']}")
            else:
                self.logger.warning(f"Config file not found: {config_path}, using defaults")
        except Exception as e:
            self.logger.error(f"Error loading config: {e}", exc_info=True)
    
    async def get_context(self, query: str) -> str:
        """
        Fetch context from all enabled MCP servers.
        In production, this would connect to actual MCP servers.
        """
        if not self.mcp_enabled or not self.servers:
            return ""
        
        contexts = []
        for server in self.servers:
            # TODO: Implement actual MCP protocol client here
            # This is where you'd connect to each MCP server and query it
            context = f"[{server['name']}: Context for '{query}']"
            contexts.append(context)
        
        return "\n".join(contexts) if contexts else ""


# ============================================================================
# 2. Human-in-the-Loop (HITL) Middleware
# ============================================================================
class HumanInTheLoopMiddleware:
    """
    HITL Middleware for agent supervision.
    Allows human approval/rejection of agent actions before execution.
    """
    
    def __init__(self, require_approval: bool = True):
        self.logger = logging.getLogger(f"{__name__}.HumanInTheLoopMiddleware")
        self.require_approval = require_approval
        self.logger.info(f"Initialized (require_approval={require_approval})")
    
    async def should_proceed(self, action: str, tool_name: str = None) -> bool:
        """
        Ask human for approval before proceeding with action.
        In production, this could integrate with a queue/UI system.
        """
        if not self.require_approval:
            return True
        
        self.logger.warning(f"Agent wants to: {action}")
        if tool_name:
            self.logger.warning(f"Using tool: {tool_name}")
        
        # Simple terminal-based approval (replace with API/UI in production)
        response = input("[HITL] Approve? (y/n): ").strip().lower()
        approved = response == 'y'
        
        log_method = self.logger.info if approved else self.logger.warning
        log_method(f"Decision: {'APPROVED' if approved else 'REJECTED'}")
        return approved


# ============================================================================
# 3. Tools are now loaded dynamically from tools_registry.py
# No need to define tools here - add them to tools_registry.py instead!
# ============================================================================


# ============================================================================
# 4. Agent Configuration & Initialization - Dynamic Multi-Agent Support
# ============================================================================
class AgentFramework:
    """
    Main AI Runtime Framework with dynamic multi-agent support.
    Agents configured via agents_config.yaml, tools via tools_registry.py,
    MCP servers via mcp_servers.yaml.
    
    Supports multiple LLM providers: Azure OpenAI, OpenAI, Anthropic, Ollama, Local models
    """
    
    def __init__(self, agents_config_path: str = DEFAULT_AGENTS_CONFIG_PATH, tools_loader=None):
        """
        Initialize AgentFramework.
        
        Args:
            agents_config_path: Path to agents.yaml configuration file
            tools_loader: Optional custom tool loader function. If None, uses get_all_tools from tools_registry.py
        """
        self.logger = logging.getLogger(f"{__name__}.AgentFramework")
        
        # Load LLM configuration from environment
        self.llm_config = LLMProviderConfig.from_env()
        
        # PostgreSQL config
        self.postgres_url = os.getenv("POSTGRES_URL")
        
        # Debug mode (can be overridden per agent in config)
        self.debug_mode = os.getenv("DEBUG_MODE", "false").lower() == "true"
        
        # Initialize components
        self.mcp = MCPContextProvider()
        self.hitl = HumanInTheLoopMiddleware(
            require_approval=os.getenv("HITL_ENABLED", "false").lower() == "true"
        )
        
        self.logger.info(f"LLM Provider: {self.llm_config.provider.value}")
        if self.debug_mode:
            self.logger.info("Global debug mode enabled")

        
        # Load agent configurations from user's directory
        self.agent_configs = self._load_agent_configs(agents_config_path)
        self.default_agent_name = None
        
        # Multiple agents support
        self.agents: Dict[str, any] = {}
        self.checkpointer = None
        self.checkpointer_cm = None  # Store the context manager
        
        # Load all available tools (from user's tools_registry.py or custom loader)
        # Note: With explicit tool_imports in agents.yaml, all_tools may be empty
        if tools_loader:
            self.all_tools = tools_loader()
        else:
            self.all_tools = []  # Empty by default, agents specify their own tools
        self.logger.info(f"Default tools available: {len(self.all_tools)}")
    
    def _load_agent_configs(self, config_path: str) -> List[Dict]:
        """Load agent configurations from YAML file."""
        try:
            config_file = Path(config_path)
            if config_file.exists():
                with open(config_file, 'r', encoding='utf-8') as f:
                    config = yaml.safe_load(f)
                    agents = config.get('agents', [])
                    self.default_agent_name = config.get('default_agent', None)
                    
                    # Filter to enabled agents only
                    enabled_agents = [a for a in agents if a.get('enabled', True)]
                    self.logger.info(f"Loaded {len(enabled_agents)} agent configurations")
                    return enabled_agents
            else:
                self.logger.warning(f"Agent config not found: {config_path}, using defaults")
                return self._get_default_agent_config()
        except Exception as e:
            self.logger.error(f"Error loading agent config: {e}", exc_info=True)
            return self._get_default_agent_config()
    
    def _get_default_agent_config(self) -> List[Dict]:
        """Fallback default agent configuration."""
        # Only include tools if they've been loaded
        tool_names = [tool.name for tool in self.all_tools] if hasattr(self, 'all_tools') and self.all_tools else []
        return [{
            'name': 'general_assistant',
            'description': 'General purpose AI assistant',
            'tools': tool_names,
            'temperature': 0.7,
            'enabled': True,
            'sub_agents': [],  # Support for hierarchical agents
            'parent': None
        }]
    
    def _initialize_llm(self, temperature: float = None) -> BaseChatModel:
        """
        Initialize LLM based on configured provider.
        Supports: azure, openai, anthropic, gemini, ollama, local
        """
        if temperature is None:
            temperature = self.llm_config.temperature
        
        # Validate configuration
        self.llm_config.validate()
        
        provider = self.llm_config.provider
        
        try:
            if provider == LLMProvider.AZURE:
                return self._init_azure_llm(temperature)
            elif provider == LLMProvider.OPENAI:
                return self._init_openai_llm(temperature)
            elif provider == LLMProvider.ANTHROPIC:
                return self._init_anthropic_llm(temperature)
            elif provider == LLMProvider.GEMINI:
                return self._init_gemini_llm(temperature)
            elif provider == LLMProvider.OLLAMA:
                return self._init_ollama_llm(temperature)
            elif provider == LLMProvider.LOCAL:
                return self._init_local_llm(temperature)
            else:
                raise ValueError(f"Unsupported LLM provider: {provider.value}")
        except Exception as e:
            self.logger.error(f"Failed to initialize {provider.value} LLM: {e}")
            raise
    
    def _init_azure_llm(self, temperature: float) -> BaseChatModel:
        """Initialize Azure OpenAI LLM."""
        if AzureChatOpenAI is None:
            raise ImportError("langchain-openai not installed. Run: pip install langchain-openai")
        
        self.logger.info(f"Using Azure OpenAI - {self.llm_config.azure_deployment}")
        return AzureChatOpenAI(
            azure_endpoint=self.llm_config.azure_endpoint,
            api_key=self.llm_config.azure_api_key,
            azure_deployment=self.llm_config.azure_deployment,
            api_version=self.llm_config.azure_api_version,
            temperature=temperature,
            streaming=self.llm_config.streaming,
        )
    
    def _init_openai_llm(self, temperature: float) -> BaseChatModel:
        """Initialize OpenAI LLM."""
        if ChatOpenAI is None:
            raise ImportError("langchain-openai not installed. Run: pip install langchain-openai")
        
        self.logger.info(f"Using OpenAI - {self.llm_config.openai_model}")
        return ChatOpenAI(
            api_key=self.llm_config.openai_api_key,
            model=self.llm_config.openai_model,
            base_url=self.llm_config.openai_base_url,
            temperature=temperature,
            streaming=self.llm_config.streaming,
        )
    
    def _init_anthropic_llm(self, temperature: float) -> BaseChatModel:
        """Initialize Anthropic LLM."""
        if ChatAnthropic is None:
            raise ImportError("langchain-anthropic not installed. Run: pip install langchain-anthropic")
        
        self.logger.info(f"Using Anthropic - {self.llm_config.anthropic_model}")
        return ChatAnthropic(
            api_key=self.llm_config.anthropic_api_key,
            model=self.llm_config.anthropic_model,
            temperature=temperature,
            streaming=self.llm_config.streaming,
        )
    
    def _init_gemini_llm(self, temperature: float) -> BaseChatModel:
        """Initialize Google Gemini LLM."""
        if ChatGoogleGenerativeAI is None:
            raise ImportError("langchain-google-genai not installed. Run: pip install langchain-google-genai")
        
        self.logger.info(f"Using Google Gemini - {self.llm_config.gemini_model}")
        return ChatGoogleGenerativeAI(
            model=self.llm_config.gemini_model,
            google_api_key=self.llm_config.google_api_key,
            temperature=temperature,
            streaming=self.llm_config.streaming,
        )
    
    def _init_ollama_llm(self, temperature: float) -> BaseChatModel:
        """Initialize Ollama LLM."""
        if ChatOllama is None:
            raise ImportError("langchain-community not installed. Run: pip install langchain-community")
        
        self.logger.info(f"Using Ollama - {self.llm_config.ollama_model}")
        return ChatOllama(
            base_url=self.llm_config.ollama_base_url,
            model=self.llm_config.ollama_model,
            temperature=temperature,
        )
    
    def _init_local_llm(self, temperature: float) -> BaseChatModel:
        """Initialize local Hugging Face LLM."""
        if HuggingFacePipeline is None:
            raise ImportError("transformers not installed. Run: pip install transformers torch")
        
        self.logger.info(f"Using Local Model - {self.llm_config.local_model_path}")
        from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline
        
        tokenizer = AutoTokenizer.from_pretrained(self.llm_config.local_model_path)
        model = AutoModelForCausalLM.from_pretrained(
            self.llm_config.local_model_path,
            device_map=self.llm_config.local_model_device,
        )
        
        pipe = pipeline(
            "text-generation",
            model=model,
            tokenizer=tokenizer,
            max_new_tokens=512,
            temperature=temperature,
        )
        
        return HuggingFacePipeline(pipeline=pipe)
    
    def _create_delegation_tool(self, supervisor_name: str, sub_agents: List[str]):
        """
        Create a delegation tool for a supervisor agent.
        This tool allows the supervisor to delegate tasks to its sub-agents.
        """
        framework = self  # Capture framework instance for tool closure
        
        # Build the sub-agents description for the docstring
        sub_agents_desc = "\n".join([
            f"  - {name}: {framework.agents.get(name, {}).get('config', {}).get('description', 'No description')}" 
            for name in sub_agents
        ])
        
        @tool
        async def delegate_task(task: str, agent_name: str) -> str:
            """Delegate a task to a specialist sub-agent.
            
            Use this when you need specialized expertise that one of your sub-agents provides.
            
            Args:
                task: Clear description of what the sub-agent should do
                agent_name: Name of the sub-agent to delegate to
            
            Returns:
                The sub-agent's response/result
            """
            # Use a unique session ID for the delegation
            # In production, this could be derived from parent session
            session_id = "delegation_session0"
            
            result = await framework.delegate_to_agent(
                task=task,
                target_agent=agent_name,
                session_id=session_id,
                supervisor_agent=supervisor_name
            )
            
            return result
        
        # Set a descriptive name for the tool
        delegate_task.name = f"delegate_to_sub_agent"
        
        return delegate_task
    
    async def initialize_async(self):
        """Initialize async components and create all configured agents."""
        self.logger.info("Initializing PostgreSQL checkpointer...")
        
        # Create async PostgreSQL checkpointer for conversation persistence
        # Store the context manager and enter it
        self.checkpointer_cm = AsyncPostgresSaver.from_conn_string(self.postgres_url)
        self.checkpointer = await self.checkpointer_cm.__aenter__()
        
        # Setup database schema
        await self.checkpointer.setup()
        
        self.logger.info("✓ PostgreSQL checkpointer ready")
        
        # Create all configured agents
        self.logger.info(f"Creating {len(self.agent_configs)} agent(s)...")
        
        for agent_config in self.agent_configs:
            agent_name = agent_config['name']
            temperature = agent_config.get('temperature', 0.7)
            tool_names = agent_config.get('tools', [])  # Legacy: tool names
            tool_imports = agent_config.get('tool_imports', [])  # New: explicit imports
            system_prompt = agent_config.get('system_prompt', None)
            # Use per-agent debug setting if specified, otherwise use global setting
            debug = agent_config.get('debug', self.debug_mode)
            # Use per-agent HITL setting
            hitl_enabled = agent_config.get('hitl', False)
            # Get sub-agents list (for hierarchical support)
            sub_agents = agent_config.get('sub_agents', [])
            parent_agent = agent_config.get('parent', None)
            
            # Get tools for this agent
            # Priority: tool_imports (new explicit way) > tools (legacy)
            if tool_imports:
                agent_tools = _load_tools_from_imports(tool_imports)
            elif tool_names:
                # Legacy support: load from all_tools by name
                agent_tools = [t for t in self.all_tools if t.name in tool_names]
            else:
                agent_tools = self.all_tools
            
            # If this agent has sub-agents, create a delegation tool for it
            if sub_agents:
                delegation_tool = self._create_delegation_tool(agent_name, sub_agents)
                agent_tools.append(delegation_tool)
                self.logger.info(f"Agent '{agent_name}' can delegate to: {', '.join(sub_agents)}")
            
            self.logger.info(f"Agent '{agent_name}' loaded {len(agent_tools)} tool(s)")
            
            # Create LLM instance for this agent
            llm = self._initialize_llm(temperature=temperature)
            
            # Create agent using LangChain v1's create_agent
            agent = create_agent(
                model=llm,
                tools=agent_tools,
                system_prompt=system_prompt,
                checkpointer=self.checkpointer,
                debug=debug,
            )
            
            hitl_info = " [HITL ENABLED]" if hitl_enabled else ""
            hierarchy_info = ""
            if sub_agents:
                hierarchy_info = f" [SUPERVISOR: {len(sub_agents)} sub-agents]"
            elif parent_agent:
                hierarchy_info = f" [SUB-AGENT of {parent_agent}]"
                
            self.agents[agent_name] = {
                'agent': agent,
                'config': agent_config,
                'tools': agent_tools,
                'system_prompt': system_prompt,
                'debug': debug,
                'hitl': hitl_enabled,
                'sub_agents': sub_agents,
                'parent': parent_agent
            }
            
            persona_info = f" with custom persona" if system_prompt else ""
            debug_info = " [DEBUG]" if debug else ""
            self.logger.info(f"✓ Created '{agent_name}' with {len(agent_tools)} tools{persona_info}{debug_info}{hitl_info}{hierarchy_info}")
        
        # Set default agent
        if not self.default_agent_name and self.agents:
            self.default_agent_name = list(self.agents.keys())[0]
        
        self.logger.info(f"✓ Default agent: {self.default_agent_name}")
    
    async def get_chat_history(self, session_id: str) -> PostgresChatMessageHistory:
        """Get chat history for a specific session from PostgreSQL."""
        return PostgresChatMessageHistory(
            connection_string=self.postgres_url,
            session_id=session_id,
        )
    
    def get_agent(self, agent_name: Optional[str] = None):
        """Get a specific agent or the default agent."""
        if agent_name is None:
            agent_name = self.default_agent_name
        
        if agent_name not in self.agents:
            available = ', '.join(self.agents.keys())
            raise ValueError(f"Agent '{agent_name}' not found. Available: {available}")
        
        return self.agents[agent_name]
    
    def list_agents(self) -> List[str]:
        """List all available agent names."""
        return list(self.agents.keys())
    
    def get_sub_agents(self, agent_name: str) -> List[str]:
        """Get list of sub-agents for a given agent."""
        agent_data = self.get_agent(agent_name)
        return agent_data['config'].get('sub_agents', [])
    
    def get_parent_agent(self, agent_name: str) -> Optional[str]:
        """Get parent agent for a given agent."""
        agent_data = self.get_agent(agent_name)
        return agent_data['config'].get('parent', None)
    
    async def delegate_to_agent(
        self,
        task: str,
        target_agent: str,
        session_id: str,
        supervisor_agent: Optional[str] = None
    ) -> str:
        """
        Delegate a task to a sub-agent.
        
        Args:
            task: Task description for the sub-agent
            target_agent: Name of the agent to delegate to
            session_id: Current session ID
            supervisor_agent: Name of the supervising agent (for validation)
        
        Returns:
            Sub-agent's response
        """
        # Validate that target agent exists
        if target_agent not in self.agents:
            available = ', '.join(self.agents.keys())
            raise ValueError(f"Target agent '{target_agent}' not found. Available: {available}")
        
        # Validate delegation authority if supervisor is specified
        if supervisor_agent:
            sub_agents = self.get_sub_agents(supervisor_agent)
            if target_agent not in sub_agents:
                raise ValueError(
                    f"Agent '{supervisor_agent}' cannot delegate to '{target_agent}'. "
                    f"Allowed sub-agents: {', '.join(sub_agents) if sub_agents else 'none'}"
                )
        
        # Create a sub-session ID to maintain context hierarchy
        sub_session_id = f"{session_id}_delegated_{target_agent}"
        
        self.logger.info(f"🔀 Delegating to sub-agent '{target_agent}': {task}")
        
        # Run the sub-agent
        response = await self.run_conversation(
            user_message=task,
            session_id=sub_session_id,
            agent_name=target_agent
        )
        
        self.logger.info(f"✅ Sub-agent '{target_agent}' completed task")
        
        return response
    
    async def run_conversation(
        self, 
        user_message: str, 
        session_id: str = "default",
        agent_name: Optional[str] = None
    ):
        """
        Run a conversation turn with HITL supervision.
        Can specify which agent to use, or uses default.
        """
        # Get the agent to use
        agent_data = self.get_agent(agent_name)
        agent = agent_data['agent']
        agent_config = agent_data['config']
        
        self.logger.info("="*60)
        self.logger.info(f"Agent: {agent_config['name']} - {agent_config['description']}")
        self.logger.info(f"Session: {session_id} | User: {user_message}")
        self.logger.info("="*60)
        
        # Optional: Get MCP context from all servers
        mcp_context = await self.mcp.get_context(user_message)
        if mcp_context:
            self.logger.debug(f"MCP Context:\n{mcp_context}")
        
        # HITL: Check if we should proceed (per-agent HITL control)
        # Check if this specific agent has HITL enabled
        agent_hitl_enabled = agent_data.get('hitl', False)
        if agent_hitl_enabled:
            if not await self.hitl.should_proceed(
                f"Process message: '{user_message}'",
                tool_name=f"Agent: {agent_config['name']}"
            ):
                self.logger.warning("Request rejected by human supervisor")
                return "Request rejected by human supervisor."
        
        # Prepare config with session ID for conversation persistence
        # SHARED THREAD: All agents see same conversation history for context flow
        config = {
            "configurable": {
                "thread_id": f"{session_id}",  # Shared thread across all agents
            },
            "recursion_limit": 100  # Increased to allow complex agent interactions and tool chaining
        }
        
        # Process agent response
        self.logger.info(f"[{agent_config['name']}] Processing...")
        
        try:
            # Run the agent (debug output controlled by debug=True/False in agent creation)
            # HITL middleware will automatically prompt for approval if configured
            async for event in agent.astream_events(
                {"messages": [HumanMessage(content=user_message)]},
                config=config,
                version="v2",
            ):
                # No print statements - debug output is controlled by the agent's debug parameter
                pass
            
            # Get final state to retrieve the response
            final_state = await agent.aget_state(config)
            response_content = None
            if final_state.values.get("messages"):
                last_message = final_state.values["messages"][-1]
                response_content = last_message.content
                # Only log final response if debug mode is enabled
                if agent_data['debug']:
                    self.logger.info(f"[{agent_config['name']}] Final response: {response_content}")
            
            return response_content
            
        except Exception as e:
            error_msg = str(e)
            # Check if it's a tool_call mismatch error (corrupted conversation state)
            if "tool_call_id" in error_msg and "did not have response messages" in error_msg:
                self.logger.warning(f"Corrupted conversation state detected. Clearing thread: {config['configurable']['thread_id']}")
                # Clear the conversation by creating a new thread with a timestamp suffix
                import time
                new_thread_id = f"{session_id}_{int(time.time())}"
                config["configurable"]["thread_id"] = new_thread_id
                self.logger.info(f"Retrying with new thread: {new_thread_id}")
                
                # Retry with clean state
                async for event in agent.astream_events(
                    {"messages": [HumanMessage(content=user_message)]},
                    config=config,
                    version="v2",
                ):
                    pass
                
                final_state = await agent.aget_state(config)
                response_content = None
                if final_state.values.get("messages"):
                    last_message = final_state.values["messages"][-1]
                    response_content = last_message.content
                    if agent_data['debug']:
                        self.logger.info(f"[{agent_config['name']}] Final response: {response_content}")
                
                return response_content
            else:
                # Re-raise other exceptions
                raise
    
    async def cleanup(self):
        """Cleanup resources."""
        if self.checkpointer and self.checkpointer_cm:
            # Properly exit the context manager to close database connections
            await self.checkpointer_cm.__aexit__(None, None, None)
        self.logger.info("Resources released")


# ============================================================================
# 6. Helper Functions for User Applications
# ============================================================================

def create_cli(agents_config_path: str = "agents.yaml"):
    """
    Create a CLI chat interface for user's agents.
    
    Usage in user's agents.py:
        from agentframework import create_cli
        
        if __name__ == "__main__":
            cli = create_cli()
            cli.run()
    
    Args:
        agents_config_path: Path to user's agents.yaml file
    
    Returns:
        CLI instance with run() method
    """
    from types import SimpleNamespace
    import re
    
    class SmartRouter:
        """Auto-route queries to appropriate agents using LLM-based analysis."""
        
        def __init__(self, framework):
            """Initialize router with framework reference to access agents and LLM."""
            self.framework = framework
        
        def route(self, query: str, available_agents: List[str]) -> str:
            """
            Determine which agent should handle the query.
            Uses agent descriptions and tools to make intelligent routing decisions.
            """
            # If only one agent, use it
            if len(available_agents) == 1:
                return available_agents[0]
            
            # Get agent descriptions and tools
            agent_info = []
            for agent_name in available_agents:
                agent_data = self.framework.get_agent(agent_name)
                config = agent_data['config']
                tools = [t.name for t in agent_data['tools']]
                
                agent_info.append({
                    'name': agent_name,
                    'description': config.get('description', ''),
                    'tools': tools
                })
            
            # Build routing prompt
            agent_descriptions = "\n".join([
                f"- {a['name']}: {a['description']} (tools: {', '.join(a['tools'])})"
                for a in agent_info
            ])
            
            routing_prompt = f"""You are a routing assistant. Given a user query, select the most appropriate agent.

Available agents:
{agent_descriptions}

User query: "{query}"

Respond with ONLY the agent name, nothing else."""

            # Use the framework's LLM to make routing decision
            try:
                llm = self.framework._initialize_llm(temperature=0.0)
                response = llm.invoke(routing_prompt)
                selected = response.content.strip()
                
                # Validate the response is a valid agent name
                if selected in available_agents:
                    return selected
            except Exception:
                pass  # Fall back to default if LLM routing fails
            
            # Fallback: use default agent
            return self.framework.default_agent_name or available_agents[0]
    
    class CLIChat:
        """Simple CLI chat interface."""
        
        def __init__(self, config_path: str):
            self.config_path = config_path
            self.framework = None
            self.router = None
        
        async def initialize(self):
            """Initialize the framework."""
            print("\n" + "="*70)
            print("🤖 AgentFramework - Smart Multi-Agent Chat")
            print("="*70)
            print("\nInitializing...")
            
            self.framework = AgentFramework(agents_config_path=self.config_path)
            await self.framework.initialize_async()
            
            # Initialize smart router with framework reference
            self.router = SmartRouter(self.framework)
            
            agents = self.framework.list_agents()
            print(f"\n✅ Ready! Loaded {len(agents)} agent(s): {', '.join(agents)}")
            print("="*70)
        
        async def chat_loop(self):
            """Main chat loop."""
            print("\n💬 Chat - Ask me anything! (type 'quit' to exit, 'help' for commands)\n")
            
            session_id = "user_session"
            
            while True:
                try:
                    user_input = input("👤 You: ").strip()
                    
                    if not user_input:
                        continue
                    
                    if user_input.lower() in ['quit', 'exit', 'q', 'bye']:
                        print("\n👋 Goodbye!\n")
                        break
                    
                    if user_input.lower() in ['help', 'h', '?']:
                        print("\n📖 Commands:")
                        print("  • Type your question to chat")
                        print("  • 'agents' - List available agents")
                        print("  • 'quit' or 'exit' - Exit chat")
                        print()
                        continue
                    
                    if user_input.lower() == 'agents':
                        agents = self.framework.list_agents()
                        print(f"\n📋 Available agents: {', '.join(agents)}")
                        print(f"   Default: {self.framework.default_agent_name}\n")
                        continue
                    
                    # Smart routing - LLM-based agent selection using descriptions and tools
                    available_agents = self.framework.list_agents()
                    selected_agent = self.router.route(user_input, available_agents)
                    
                    response = await self.framework.run_conversation(
                        user_message=user_input,
                        session_id=session_id,
                        agent_name=selected_agent
                    )
                    
                    # Show which agent responded
                    print(f"\n🤖 [{selected_agent}]: {response}\n")
                
                except KeyboardInterrupt:
                    print("\n\n👋 Goodbye!\n")
                    break
                except Exception as e:
                    print(f"\n❌ Error: {e}\n")
        
        async def run_async(self):
            """Run the CLI chat."""
            try:
                await self.initialize()
                await self.chat_loop()
            finally:
                if self.framework:
                    await self.framework.cleanup()
        
        def run(self):
            """Run the CLI (synchronous entry point)."""
            asyncio.run(self.run_async())
    
    return CLIChat(agents_config_path)


def create_api(agents_config_path: str = "agents.yaml", host: str = "0.0.0.0", port: int = 8000):
    """
    Create a FastAPI web server for user's agents.
    
    Usage in user's agents.py:
        from agentframework import create_api
        
        if __name__ == "__main__":
            api = create_api()
            api.run()
    
    Args:
        agents_config_path: Path to user's agents.yaml file
        host: Host to bind to (default: 0.0.0.0)
        port: Port to bind to (default: 8000)
    
    Returns:
        API instance with run() method
    """
    class APIServer:
        def __init__(self, config_path: str, host: str, port: int):
            self.config_path = config_path
            self.host = host
            self.port = port
        
        def run(self):
            """Run the API server."""
            import sys
            import os
            from pathlib import Path
            
            print(f"\n🚀 Starting API server on http://{self.host}:{self.port}")
            print(f"📖 Swagger UI: http://localhost:{self.port}/docs\n")
            
            # Try to find api_server.py
            # First check if it's in the same directory as main.py
            main_dir = Path(__file__).parent
            api_server_path = main_dir / "api_server.py"
            
            if not api_server_path.exists():
                print(f"❌ Error: api_server.py not found at {api_server_path}")
                print("Make sure api_server.py is in the agentframework directory.")
                sys.exit(1)
            
            # Add the directory containing api_server to path
            if str(main_dir) not in sys.path:
                sys.path.insert(0, str(main_dir))
            
            try:
                # Import and run the API server
                from api_server import run_api_server
                run_api_server(host=self.host, port=self.port, config_path=self.config_path)
            except ImportError as e:
                print(f"❌ Error importing api_server: {e}")
                print(f"Tried to import from: {main_dir}")
                sys.exit(1)
            except Exception as e:
                print(f"❌ Error starting API server: {e}")
                import traceback
                traceback.print_exc()
                sys.exit(1)
    
    return APIServer(agents_config_path, host, port)


# ============================================================================
# 7. Public API - Export for pip module
# ============================================================================
__all__ = [
    'AgentFramework',
    'MCPContextProvider', 
    'HumanInTheLoopMiddleware',
    'create_cli',
    'create_api',
    'LLMProvider',
    'LLMProviderConfig',
]


# ============================================================================
# Main entry point - Show usage info
# ============================================================================
if __name__ == "__main__":
    print("\n" + "="*70)
    print("🤖 AgentFramework - Multi-Agent AI System")
    print("="*70)
    print("\n⚠️  This is a framework library, not a standalone application.")
    print("\n📖 To use AgentFramework:")
    print("\n1️⃣  Create your agents.yaml:")
    print("    Define your agents and their tools")
    print("\n2️⃣  Create your agents.py:")
    print("    from agentframework import create_cli")
    print("    ")
    print("    if __name__ == '__main__':")
    print("        cli = create_cli()")
    print("        cli.run()")
    print("\n3️⃣  Run your application:")
    print("    python agents.py         # CLI mode")
    print("    python agents.py --api   # API mode")
    print("\n📚 Examples: See multiagent/ folder")
    print("📘 Documentation: README.md")
    print("="*70 + "\n")
